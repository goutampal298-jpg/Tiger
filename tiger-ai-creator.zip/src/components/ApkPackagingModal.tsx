import React, { useState } from 'react';
import {
  X,
  Package,
  Download,
  Smartphone,
  CheckCircle2,
  Copy,
  Terminal,
  FileCode,
  Sparkles,
  ExternalLink,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface ApkPackagingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApkPackagingModal: React.FC<ApkPackagingModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { isInstallable, install } = usePWAInstall();
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showInstallTip, setShowInstallTip] = useState(false);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const downloadFile = (content: string, filename: string, type: string) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const androidManifestXml = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.tiger.aicreator">

    <!-- Samsung Android Smartphone Optimizations & Permissions -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />
    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />
    <uses-permission android:name="android.permission.VIBRATE" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="TIGER AI CREATOR"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:hardwareAccelerated="true"
        android:theme="@style/Theme.TigerAiCreator">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode"
            android:screenOrientation="portrait"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;

  const twaManifestJson = JSON.stringify(
    {
      packageId: 'com.tiger.aicreator',
      host: window.location.host,
      name: 'TIGER AI CREATOR',
      launcherName: 'Tiger AI',
      themeColor: '#FF9900',
      navigationColor: '#05070A',
      backgroundColor: '#05070A',
      startUrl: '/',
      iconUrl: '/icon.svg',
      maskableIconUrl: '/icon-512.png',
      appVersionName: '1.0.0',
      appVersionCode: 1,
      shortcuts: [],
      generatorApp: 'bubblewrap-cli',
      webManifestUrl: '/manifest.webmanifest',
      fallbackType: 'customtabs',
      enableNotifications: true,
      features: {
        playBilling: { enabled: false },
      },
      alphaDependencies: { enabled: false },
    },
    null,
    2
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-5 overflow-y-auto">
      <div className="w-full max-w-2xl bg-[#0E121C] border border-amber-500/30 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-emerald-950/40 via-[#131926] to-[#0E121C] border-b border-emerald-500/20 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-400 to-teal-600 flex items-center justify-center text-black font-extrabold shadow">
              <Package className="w-5 h-5 text-black" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-white flex items-center gap-2">
                Android APK Packaging Hub
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-mono">
                  v1.0.0
                </span>
              </h2>
              <p className="text-xs text-emerald-400 font-mono">
                Package: com.tiger.aicreator
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-gray-800 text-gray-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 space-y-5 overflow-y-auto flex-1">
          {/* Samsung Smartphone Optimization Specs Banner */}
          <div className="bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-red-500/10 border border-amber-500/30 rounded-2xl p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5 uppercase tracking-wider">
                <Smartphone className="w-4 h-4 text-amber-400" />
                Samsung Galaxy & Android Optimizations Active
              </span>
              <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-500/40">
                120Hz Smooth UI
              </span>
            </div>
            <ul className="text-xs text-gray-300 space-y-1">
              <li>• One UI thumb-accessible bottom navigation & touch targets</li>
              <li>• Native haptic vibration feedback on tap</li>
              <li>• Hardware-accelerated HTML5 Canvas video compositor</li>
              <li>• True OLED Pure Black (#05070A) battery-saving theme</li>
              <li>• Full PWA Standalone & TWA APK ready</li>
            </ul>
          </div>

          {/* Quick 1-Tap Home Screen Install (Instant APK Feel) */}
          <div className="bg-[#141926] border border-gray-800 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div>
              <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-blue-400" />
                Direct Samsung Install (No APK build needed)
              </h4>
              <p className="text-xs text-gray-400 mt-0.5">
                Installs as a standalone full-screen native Android app in 3 seconds.
              </p>
            </div>
            <button
              onClick={() => {
                if (isInstallable) {
                  install();
                } else {
                  setShowInstallTip((prev) => !prev);
                }
              }}
              className="w-full sm:w-auto px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span>Install to Phone</span>
            </button>
          </div>

          {/* Inline Install Guide for Mobile Browsers */}
          {showInstallTip && (
            <div className="bg-blue-950/40 border border-blue-500/30 rounded-xl p-3 text-xs text-blue-200 space-y-1">
              <div className="font-bold text-white flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-blue-400" />
                <span>How to Install on Samsung Internet or Chrome:</span>
              </div>
              <p className="text-[11px] text-gray-300">
                1. Tap the browser menu <strong>(⋮)</strong> or install icon in your URL bar.
              </p>
              <p className="text-[11px] text-gray-300">
                2. Select <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.
              </p>
              <p className="text-[11px] text-gray-300">
                3. The app will launch in full screen with native Android icon and performance.
              </p>
            </div>
          )}

          {/* Android Files Generation */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-gray-300 uppercase tracking-wider flex items-center gap-1.5">
              <FileCode className="w-4 h-4 text-amber-400" />
              Download Android APK Source Manifests
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* AndroidManifest.xml */}
              <div className="p-3.5 rounded-xl bg-[#141926] border border-gray-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">AndroidManifest.xml</span>
                  <button
                    onClick={() =>
                      downloadFile(androidManifestXml, 'AndroidManifest.xml', 'text/xml')
                    }
                    className="p-1 text-amber-400 hover:text-amber-300"
                    title="Download XML"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                </div>
                <p className="text-[11px] text-gray-400">
                  Preconfigured for <code className="text-amber-300">com.tiger.aicreator</code> with
                  camera, audio, and hardware acceleration.
                </p>
              </div>

              {/* twa-manifest.json */}
              <div className="p-3.5 rounded-xl bg-[#141926] border border-gray-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">twa-manifest.json</span>
                  <button
                    onClick={() =>
                      downloadFile(twaManifestJson, 'twa-manifest.json', 'application/json')
                    }
                    className="p-1 text-emerald-400 hover:text-emerald-300"
                    title="Download JSON"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                </div>
                <p className="text-[11px] text-gray-400">
                  Official Google Chrome Bubblewrap CLI manifest to generate signed APKs in 1
                  command.
                </p>
              </div>
            </div>
          </div>

          {/* Step-by-Step 3-Way APK Generation Guide */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-gray-300 uppercase tracking-wider flex items-center gap-1.5">
              <Terminal className="w-4 h-4 text-emerald-400" />
              How to Generate the APK File for Samsung
            </h4>

            <div className="space-y-2 text-xs text-gray-300">
              {/* Option 1 */}
              <div className="p-3 rounded-xl bg-[#121622] border border-gray-800 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white">
                    Method 1: Direct APK on Samsung Device (Fastest - 1 Min)
                  </span>
                  <span className="text-[10px] text-amber-400 font-bold">Recommended</span>
                </div>
                <p className="text-gray-400">
                  Open <strong>PWA2APK</strong> or <strong>PWABuilder.com</strong> in Samsung
                  Internet, paste this app's URL, and tap <em>"Generate Android APK"</em>. It creates
                  a ready-to-install signed <code>.apk</code> file directly into your device downloads!
                </p>
              </div>

              {/* Option 2 */}
              <div className="p-3 rounded-xl bg-[#121622] border border-gray-800 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white">
                    Method 2: Google Bubblewrap TWA (Google Play Store Ready)
                  </span>
                </div>
                <p className="text-gray-400 mb-1">
                  Run the standard Google Play Trusted Web Activity CLI:
                </p>
                <div className="bg-black/60 p-2 rounded-lg font-mono text-[11px] text-emerald-300 flex items-center justify-between">
                  <code>npx @bubblewrap/cli build</code>
                  <button
                    onClick={() =>
                      copyToClipboard('npx @bubblewrap/cli build', 'bubblewrap')
                    }
                    className="p-1 hover:text-white"
                  >
                    {copiedId === 'bubblewrap' ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* Option 3 */}
              <div className="p-3 rounded-xl bg-[#121622] border border-gray-800 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white">
                    Method 3: Capacitor Native Android Project
                  </span>
                </div>
                <div className="bg-black/60 p-2 rounded-lg font-mono text-[11px] text-amber-300 flex items-center justify-between">
                  <code>npx cap add android && npx cap run android</code>
                  <button
                    onClick={() =>
                      copyToClipboard(
                        'npx cap add android && npx cap run android',
                        'cap'
                      )
                    }
                    className="p-1 hover:text-white"
                  >
                    {copiedId === 'cap' ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#0A0D14] border-t border-gray-800 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-gray-800 hover:bg-gray-700 text-white font-semibold text-xs transition"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
