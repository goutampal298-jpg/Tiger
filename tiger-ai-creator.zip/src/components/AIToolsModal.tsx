import React, { useState } from 'react';
import {
  X,
  MessageSquare,
  Mic,
  Scissors,
  Sparkles,
  Image as ImageIcon,
  Tag,
  Upload,
  CheckCircle2,
  AlertTriangle,
  Play,
  Copy,
  Check,
  Loader2,
  RefreshCw,
  Wand2,
} from 'lucide-react';
import { AIToolId, Project } from '../types';
import {
  generateTalkingPhoto,
  cloneVoiceWithConsent,
  removeBackground,
  generateThumbnail,
  generateYouTubeMetadata,
  enhanceVideoProfile,
} from '../services/geminiService';
import { safeVibrate } from '../utils/haptics';

interface AIToolsModalProps {
  toolId: AIToolId | null;
  project: Project;
  appLanguage: 'bn' | 'en';
  onClose: () => void;
  onApplyToProject?: (partial: Partial<Project>) => void;
}

export const AIToolsModal: React.FC<AIToolsModalProps> = ({
  toolId,
  project,
  appLanguage,
  onClose,
  onApplyToProject,
}) => {
  const isBn = appLanguage === 'bn';
  const [activeTab, setActiveTab] = useState<AIToolId>(toolId || 'talking-photo');
  const [loading, setLoading] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // 1. Talking Photo state
  const [photoBase64, setPhotoBase64] = useState<string | null>(
    project.characterReference?.imageBase64 || null
  );
  const [talkingDialogue, setTalkingDialogue] = useState<string>(
    'নমস্কার, আমি টাইগার এআই ক্রিয়েটরের মাধ্যমে তৈরি একটি জীবন্ত চরিত্র।'
  );
  const [talkingResult, setTalkingResult] = useState<any | null>(null);

  // 2. Voice Clone state
  const [cloneSpeakerName, setCloneSpeakerName] = useState<string>('My Custom Voice');
  const [cloneAudioFile, setCloneAudioFile] = useState<string | null>(null);
  const [consentConfirmed, setConsentConfirmed] = useState<boolean>(false);
  const [cloneProfile, setCloneProfile] = useState<any | null>(null);

  // 3. Background Remover state
  const [bgImageBase64, setBgImageBase64] = useState<string | null>(
    project.scenes[0]?.imageUrl || null
  );
  const [bgReplacementType, setBgReplacementType] = useState<'transparent' | 'color' | 'ai-prompt'>('transparent');
  const [bgPrompt, setBgPrompt] = useState<string>('Cinematic glowing golden temple in the mountains at twilight');
  const [bgResult, setBgResult] = useState<any | null>(null);

  // 4. Video Enhancer state
  const [enhanceMode, setEnhanceMode] = useState<string>('upscale-4k');
  const [sharpnessVal, setSharpnessVal] = useState<number>(80);
  const [denoiseVal, setDenoiseVal] = useState<number>(70);
  const [enhanceResult, setEnhanceResult] = useState<any | null>(null);

  // 5. Thumbnail Maker state
  const [thumbHeadline, setThumbHeadline] = useState<string>(project.title);
  const [thumbAspectRatio, setThumbAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [thumbResult, setThumbResult] = useState<any | null>(null);

  // 6. YouTube Metadata state
  const [metaTitle, setMetaTitle] = useState<string>(project.title);
  const [metaTopic, setMetaTopic] = useState<string>(project.scenes[0]?.narration || project.title);
  const [metaResult, setMetaResult] = useState<any | null>(null);

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    safeVibrate(15);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  // Run Talking Photo
  const handleRunTalkingPhoto = async () => {
    if (!photoBase64 || !talkingDialogue.trim()) return;
    setLoading(true);
    safeVibrate(15);
    try {
      const res = await generateTalkingPhoto({
        imageBase64: photoBase64,
        dialogue: talkingDialogue,
        language: project.language,
      });
      setTalkingResult(res);
    } catch (err: any) {
      alert(err.message || 'Talking photo processing failed');
    } finally {
      setLoading(false);
    }
  };

  // Run Voice Clone
  const handleRunVoiceClone = async () => {
    if (!consentConfirmed) {
      alert('Please confirm that you have legal permission to clone this voice.');
      return;
    }
    setLoading(true);
    safeVibrate(15);
    try {
      const res = await cloneVoiceWithConsent({
        voiceSampleBase64: cloneAudioFile || 'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=',
        speakerName: cloneSpeakerName,
        consentConfirmed: true,
      });
      setCloneProfile(res.profile);
    } catch (err: any) {
      alert(err.message || 'Voice cloning failed');
    } finally {
      setLoading(false);
    }
  };

  // Run Background Remover
  const handleRunBgRemover = async () => {
    if (!bgImageBase64) return;
    setLoading(true);
    safeVibrate(15);
    try {
      const res = await removeBackground({
        imageBase64: bgImageBase64,
        replacementType: bgReplacementType,
        aiPrompt: bgPrompt,
      });
      setBgResult(res);
    } catch (err: any) {
      alert(err.message || 'Background removal failed');
    } finally {
      setLoading(false);
    }
  };

  // Run Video Enhancer
  const handleRunEnhancer = async () => {
    setLoading(true);
    safeVibrate(15);
    try {
      const res = await enhanceVideoProfile({
        mode: enhanceMode,
        sharpness: sharpnessVal,
        denoise: denoiseVal,
      });
      setEnhanceResult(res);
    } catch (err: any) {
      alert(err.message || 'Enhancement failed');
    } finally {
      setLoading(false);
    }
  };

  // Run Thumbnail
  const handleRunThumbnail = async () => {
    setLoading(true);
    safeVibrate(15);
    try {
      const res = await generateThumbnail({
        title: thumbHeadline,
        topic: project.scenes[0]?.narration || thumbHeadline,
        aspectRatio: thumbAspectRatio,
        language: project.language,
      });
      setThumbResult(res.thumbnail);
    } catch (err: any) {
      alert(err.message || 'Thumbnail generation failed');
    } finally {
      setLoading(false);
    }
  };

  // Run YouTube Metadata
  const handleRunMetadata = async () => {
    setLoading(true);
    safeVibrate(15);
    try {
      const res = await generateYouTubeMetadata({
        title: metaTitle,
        topic: metaTopic,
        language: project.language,
      });
      setMetaResult(res.metadata);
    } catch (err: any) {
      alert(err.message || 'Metadata generation failed');
    } finally {
      setLoading(false);
    }
  };

  const navItems: { id: AIToolId; label: string; icon: any }[] = [
    { id: 'talking-photo', label: isBn ? 'টকিং ফটো' : 'Talking Photo', icon: MessageSquare },
    { id: 'voice-clone', label: isBn ? 'ভয়েস ক্লোন' : 'Voice Clone', icon: Mic },
    { id: 'bg-remover', label: isBn ? 'ব্যাকগ্রাউন্ড রিমুভার' : 'BG Remover', icon: Scissors },
    { id: 'video-enhancer', label: isBn ? 'ভিডিও এনহ্যান্সার' : 'Enhancer', icon: Sparkles },
    { id: 'thumbnail-maker', label: isBn ? 'থাম্বনেইল মেকার' : 'Thumbnail', icon: ImageIcon },
    { id: 'youtube-metadata', label: isBn ? 'ইউটিউব এসইও' : 'YouTube SEO', icon: Tag },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 animate-in fade-in duration-200">
      <div className="bg-[#0E121C] border border-gray-800 rounded-3xl w-full max-w-4xl h-[90vh] max-h-[800px] flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-gray-800 flex items-center justify-between bg-[#121724]">
          <div className="flex items-center gap-2.5">
            <span className="text-2xl">🧰</span>
            <div>
              <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                <span>TIGER AI PRO TOOLS</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  SUITE
                </span>
              </h3>
              <p className="text-[11px] text-gray-400">
                {isBn ? 'আধুনিক ক্রিয়েটরদের জন্য বিশেষায়িত AI পাওয়ার টুলস' : 'Advanced utility suite for video creators'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-gray-800/80 hover:bg-gray-700 text-gray-300 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex items-center gap-1.5 p-2.5 border-b border-gray-800 bg-[#0B0E16] overflow-x-auto scrollbar-none">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isSelected = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  safeVibrate(10);
                  setActiveTab(item.id);
                }}
                className={`px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-1.5 transition flex-shrink-0 ${
                  isSelected
                    ? 'bg-amber-500 text-black shadow-md font-extrabold'
                    : 'bg-[#141A28] text-gray-400 hover:text-white border border-gray-800'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* 1. Talking Photo */}
          {activeTab === 'talking-photo' && (
            <div className="space-y-4 max-w-2xl mx-auto">
              <div className="space-y-1">
                <h4 className="text-base font-bold text-white flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-amber-400" />
                  <span>{isBn ? 'টকিং ফটো (ছবি থেকে কথা বলা চরিত্র)' : 'Talking Photo Animator'}</span>
                </h4>
                <p className="text-xs text-gray-400">
                  {isBn
                    ? 'একটি ছবি আপলোড করুন এবং সংলাপে ক্লিক করলেই চরিত্রটি স্বতঃস্ফূর্তভাবে কথা বলবে।'
                    : 'Upload any portrait photo to animate realistic mouth flapping, lip sync, and micro-expressions.'}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-300 block">
                    {isBn ? 'চরিত্রের ছবি' : 'Character Portrait Photo'}
                  </label>
                  <div className="relative aspect-[3/4] rounded-2xl bg-[#141A28] border-2 border-dashed border-gray-700 hover:border-amber-500/60 overflow-hidden flex flex-col items-center justify-center p-3 text-center cursor-pointer group">
                    {photoBase64 ? (
                      <img
                        src={photoBase64}
                        alt="Character"
                        className="w-full h-full object-cover rounded-xl"
                      />
                    ) : (
                      <div className="space-y-2">
                        <Upload className="w-8 h-8 text-amber-400 mx-auto group-hover:scale-110 transition-transform" />
                        <span className="text-xs text-gray-300 font-semibold block">
                          Upload Portrait
                        </span>
                      </div>
                    )}
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onload = () => setPhotoBase64(reader.result as string);
                          reader.readAsDataURL(file);
                        }
                      }}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="text-xs font-bold text-gray-300 block mb-1">
                      {isBn ? 'বক্তব্য বা সংলাপ (বাংলা / English)' : 'Dialogue / Speech Text'}
                    </label>
                    <textarea
                      value={talkingDialogue}
                      onChange={(e) => setTalkingDialogue(e.target.value)}
                      rows={4}
                      className="w-full bg-[#141A28] border border-gray-700 focus:border-amber-500 rounded-2xl p-3 text-xs text-white outline-none resize-none"
                    />
                  </div>

                  <button
                    onClick={handleRunTalkingPhoto}
                    disabled={loading || !photoBase64}
                    className="w-full py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg transition active:scale-95 disabled:opacity-40"
                  >
                    {loading ? (
                      <Loader2 className="w-4 h-4 animate-spin text-black" />
                    ) : (
                      <Wand2 className="w-4 h-4 text-black" />
                    )}
                    <span>{isBn ? 'টকিং ফটো অ্যানিমেশন তৈরি করুন' : 'GENERATE TALKING PHOTO'}</span>
                  </button>

                  {talkingResult && (
                    <div className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs space-y-1.5 animate-in fade-in">
                      <div className="flex items-center gap-1.5 font-bold">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span>Facial Dynamics Analyzed & Lip-Sync Calibrated</span>
                      </div>
                      <p className="text-[11px] text-gray-300">
                        Phonemes mapped: {talkingResult.facialDynamics?.mouthOpeningSequence?.length || 10} keyframes.
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* 2. Voice Clone */}
          {activeTab === 'voice-clone' && (
            <div className="space-y-5 max-w-2xl mx-auto">
              <div className="space-y-1">
                <h4 className="text-base font-bold text-white flex items-center gap-2">
                  <Mic className="w-4 h-4 text-rose-500" />
                  <span>{isBn ? 'এআই ভয়েস ক্লোন ও কাস্টম স্পিকার' : 'AI Voice Clone Studio'}</span>
                </h4>
                <p className="text-xs text-gray-400">
                  {isBn
                    ? 'আপনার নিজের কণ্ঠের অডিও রেকর্ড বা ফাইল দিন। আইনি অনুমতি নিশ্চিত করা বাধ্যতামূলক।'
                    : 'Clone your unique vocal timbre for custom voiceovers with mandatory legal consent.'}
                </p>
              </div>

              <div className="bg-[#141A28] border border-gray-800 rounded-3xl p-5 space-y-4">
                <div>
                  <label className="text-xs font-bold text-gray-300 block mb-1">
                    {isBn ? 'স্পিকার বা ভয়েসের নাম' : 'Speaker Persona Name'}
                  </label>
                  <input
                    type="text"
                    value={cloneSpeakerName}
                    onChange={(e) => setCloneSpeakerName(e.target.value)}
                    className="w-full bg-[#0E121C] border border-gray-700 rounded-xl px-3 py-2 text-xs text-white outline-none"
                  />
                </div>

                <div className="border-2 border-dashed border-gray-700 hover:border-amber-500/60 rounded-2xl p-4 text-center space-y-2 cursor-pointer relative">
                  <Upload className="w-6 h-6 text-amber-400 mx-auto" />
                  <div className="text-xs font-bold text-white">
                    {cloneAudioFile ? 'Audio Sample Attached (Ready)' : 'Upload Voice Sample (WAV / MP3 / M4A)'}
                  </div>
                  <p className="text-[10px] text-gray-400">
                    A clear 10-30 second spoken audio sample yields best acoustic accuracy.
                  </p>
                  <input
                    type="file"
                    accept="audio/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onload = () => setCloneAudioFile(reader.result as string);
                        reader.readAsDataURL(file);
                      }
                    }}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />
                </div>

                {/* Mandatory Consent Checkbox */}
                <div className="p-3.5 rounded-2xl bg-amber-950/30 border border-amber-500/40 space-y-2">
                  <label className="flex items-start gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={consentConfirmed}
                      onChange={(e) => setConsentConfirmed(e.target.checked)}
                      className="mt-0.5 w-4 h-4 rounded text-amber-500 focus:ring-0 cursor-pointer accent-amber-500"
                    />
                    <span className="text-xs text-amber-200/90 leading-relaxed font-semibold">
                      {isBn
                        ? 'আমি নিশ্চিত করছি যে এই অডিও কণ্ঠের বৈধ স্বত্বাধিকার বা অনুমতি আমার রয়েছে এবং এটি প্রতারণা বা অনৈতিক কাজে ব্যবহার করা হবে না।'
                        : 'I certify that I hold full legal rights and explicit consent to clone this voice, and it will not be used for impersonation or deception.'}
                    </span>
                  </label>
                </div>

                <button
                  onClick={handleRunVoiceClone}
                  disabled={loading || !consentConfirmed}
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-red-500 to-amber-500 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg active:scale-95 disabled:opacity-40 transition"
                >
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Mic className="w-4 h-4" />}
                  <span>{isBn ? 'ভয়েস মডেল তৈরি করুন' : 'TRAIN & CALIBRATE CLONED VOICE'}</span>
                </button>

                {cloneProfile && (
                  <div className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs space-y-1">
                    <div className="flex items-center gap-1.5 font-bold">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <span>Cloned Voice Profile Ready: {cloneProfile.name}</span>
                    </div>
                    <p className="text-[11px] text-gray-300">{cloneProfile.timbre}</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 3. AI Background Remover */}
          {activeTab === 'bg-remover' && (
            <div className="space-y-4 max-w-2xl mx-auto">
              <div className="space-y-1">
                <h4 className="text-base font-bold text-white flex items-center gap-2">
                  <Scissors className="w-4 h-4 text-cyan-400" />
                  <span>{isBn ? 'এআই ব্যাকগ্রাউন্ড রিমুভার ও রিপ্লেসার' : 'AI Background Remover & Replacer'}</span>
                </h4>
                <p className="text-xs text-gray-400">
                  {isBn
                    ? 'ছবির ব্যাকগ্রাউন্ড সরান অথবা নতুন AI প্রম্পটের মাধ্যমে দৃষ্টিনন্দন সিনারি তৈরি করুন।'
                    : 'Remove background or replace it with custom AI-generated 3D environments.'}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-300 block">
                    {isBn ? 'মূল ছবি' : 'Source Image'}
                  </label>
                  <div className="relative aspect-[3/4] rounded-2xl bg-[#141A28] border-2 border-dashed border-gray-700 overflow-hidden flex flex-col items-center justify-center p-3 text-center cursor-pointer">
                    {bgImageBase64 ? (
                      <img
                        src={bgImageBase64}
                        alt="Source"
                        className="w-full h-full object-cover rounded-xl"
                      />
                    ) : (
                      <Upload className="w-8 h-8 text-cyan-400" />
                    )}
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onload = () => setBgImageBase64(reader.result as string);
                          reader.readAsDataURL(file);
                        }
                      }}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="text-xs font-bold text-gray-300 block mb-1">
                      {isBn ? 'রিপ্লেসমেন্ট মোড' : 'Replacement Mode'}
                    </label>
                    <div className="grid grid-cols-3 gap-1.5">
                      {(['transparent', 'color', 'ai-prompt'] as const).map((mode) => (
                        <button
                          key={mode}
                          onClick={() => setBgReplacementType(mode)}
                          className={`py-1.5 rounded-xl text-[11px] font-bold border capitalize ${
                            bgReplacementType === mode
                              ? 'bg-cyan-500 text-black border-cyan-400'
                              : 'bg-[#141A28] border-gray-800 text-gray-400'
                          }`}
                        >
                          {mode === 'ai-prompt' ? 'AI Scenery' : mode}
                        </button>
                      ))}
                    </div>
                  </div>

                  {bgReplacementType === 'ai-prompt' && (
                    <div>
                      <label className="text-xs font-bold text-gray-300 block mb-1">
                        {isBn ? 'নতুন ব্যাকগ্রাউন্ড প্রম্পট' : 'New Environment Prompt'}
                      </label>
                      <textarea
                        value={bgPrompt}
                        onChange={(e) => setBgPrompt(e.target.value)}
                        rows={3}
                        className="w-full bg-[#141A28] border border-gray-700 rounded-xl p-2.5 text-xs text-white outline-none resize-none"
                      />
                    </div>
                  )}

                  <button
                    onClick={handleRunBgRemover}
                    disabled={loading || !bgImageBase64}
                    className="w-full py-3 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-black font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg active:scale-95 disabled:opacity-40 transition"
                  >
                    {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Scissors className="w-4 h-4" />}
                    <span>{isBn ? 'ব্যাকগ্রাউন্ড পরিবর্তন করুন' : 'ISOLATE & REPLACE BACKGROUND'}</span>
                  </button>

                  {bgResult && (
                    <div className="p-3 rounded-2xl bg-cyan-950/40 border border-cyan-500/40 text-cyan-300 text-xs space-y-1">
                      <div className="flex items-center gap-1.5 font-bold">
                        <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                        <span>Subject Segmented & Feathered</span>
                      </div>
                      <p className="text-[11px] text-gray-300">
                        {bgResult.segmentation?.composedDescription || 'Processed cleanly'}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* 4. AI Video Enhancer */}
          {activeTab === 'video-enhancer' && (
            <div className="space-y-4 max-w-xl mx-auto">
              <div className="space-y-1">
                <h4 className="text-base font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>{isBn ? 'ভিডিও এনহ্যান্সার (আপস্কেলিং ও ডি-নয়েজিং)' : 'AI Video Enhancer'}</span>
                </h4>
                <p className="text-xs text-gray-400">
                  {isBn
                    ? 'ভিডিওর রেজোলিউশন 4K/8K তে আপস্কেল, ডি-নয়েজিং এবং শার্পনেস বৃদ্ধি করুন।'
                    : 'Super-resolution neural upscaler with edge enhancement and noise suppression.'}
                </p>
              </div>

              <div className="bg-[#141A28] border border-gray-800 rounded-3xl p-5 space-y-4">
                <div>
                  <label className="text-xs font-bold text-gray-300 block mb-1.5">
                    {isBn ? 'এনহ্যান্সমেন্ট মোড' : 'Enhancement Preset'}
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: 'upscale-4k', label: '4K SuperRes' },
                      { id: 'detail-enhance', label: 'Detail Pop' },
                      { id: 'denoise', label: 'Clean Denoise' },
                    ].map((m) => (
                      <button
                        key={m.id}
                        onClick={() => setEnhanceMode(m.id)}
                        className={`py-2 rounded-xl text-xs font-bold border transition ${
                          enhanceMode === m.id
                            ? 'bg-amber-500 text-black border-amber-400'
                            : 'bg-[#0E121C] border-gray-700 text-gray-400'
                        }`}
                      >
                        {m.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3 pt-2">
                  <div>
                    <div className="flex justify-between text-xs text-gray-300 font-semibold mb-1">
                      <span>Edge Sharpness</span>
                      <span className="font-mono text-amber-400">{sharpnessVal}%</span>
                    </div>
                    <input
                      type="range"
                      min={10}
                      max={100}
                      value={sharpnessVal}
                      onChange={(e) => setSharpnessVal(Number(e.target.value))}
                      className="w-full accent-amber-500"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs text-gray-300 font-semibold mb-1">
                      <span>Neural Denoise</span>
                      <span className="font-mono text-amber-400">{denoiseVal}%</span>
                    </div>
                    <input
                      type="range"
                      min={10}
                      max={100}
                      value={denoiseVal}
                      onChange={(e) => setDenoiseVal(Number(e.target.value))}
                      className="w-full accent-amber-500"
                    />
                  </div>
                </div>

                <button
                  onClick={handleRunEnhancer}
                  disabled={loading}
                  className="w-full py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg active:scale-95 transition"
                >
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                  <span>{isBn ? 'ভিডিও ফিল্টার প্রসেস করুন' : 'APPLY VIDEO ENHANCEMENT'}</span>
                </button>

                {enhanceResult && (
                  <div className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>{enhanceResult.message}</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 5. AI Thumbnail Maker */}
          {activeTab === 'thumbnail-maker' && (
            <div className="space-y-4 max-w-xl mx-auto">
              <div className="space-y-1">
                <h4 className="text-base font-bold text-white flex items-center gap-2">
                  <ImageIcon className="w-4 h-4 text-orange-400" />
                  <span>{isBn ? 'এআই থাম্বনেইল মেকার (ইউটিউব ও শর্টস)' : 'AI Thumbnail Maker'}</span>
                </h4>
                <p className="text-xs text-gray-400">
                  {isBn
                    ? 'উচ্চ ক্লিক-থ্রু রেটের (CTR) থাম্বনেইল ডিজাইন ও বাংলা আকর্ষণীয় হেডলাইন তৈরি করুন।'
                    : 'Generate high CTR YouTube & Shorts thumbnail concepts and viral typography.'}
                </p>
              </div>

              <div className="bg-[#141A28] border border-gray-800 rounded-3xl p-5 space-y-4">
                <div>
                  <label className="text-xs font-bold text-gray-300 block mb-1">
                    {isBn ? 'ভিডিওর টাইটেল / টপিক' : 'Video Title or Topic'}
                  </label>
                  <input
                    type="text"
                    value={thumbHeadline}
                    onChange={(e) => setThumbHeadline(e.target.value)}
                    className="w-full bg-[#0E121C] border border-gray-700 rounded-xl px-3 py-2 text-xs text-white outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-gray-300 block mb-1.5">
                    {isBn ? 'থাম্বনেইল ফরম্যাট' : 'Thumbnail Format'}
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setThumbAspectRatio('16:9')}
                      className={`py-2 rounded-xl text-xs font-bold border ${
                        thumbAspectRatio === '16:9'
                          ? 'bg-amber-500 text-black border-amber-400'
                          : 'bg-[#0E121C] border-gray-700 text-gray-400'
                      }`}
                    >
                      16:9 YouTube Landscape
                    </button>
                    <button
                      onClick={() => setThumbAspectRatio('9:16')}
                      className={`py-2 rounded-xl text-xs font-bold border ${
                        thumbAspectRatio === '9:16'
                          ? 'bg-amber-500 text-black border-amber-400'
                          : 'bg-[#0E121C] border-gray-700 text-gray-400'
                      }`}
                    >
                      9:16 Shorts Cover
                    </button>
                  </div>
                </div>

                <button
                  onClick={handleRunThumbnail}
                  disabled={loading}
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-orange-500 to-amber-500 text-black font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg active:scale-95 transition"
                >
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
                  <span>{isBn ? 'থাম্বনেইল কনসেপ্ট জেনারেট করুন' : 'GENERATE VIRAL THUMBNAIL'}</span>
                </button>

                {thumbResult && (
                  <div className="p-4 rounded-2xl bg-[#0E121C] border border-amber-500/40 space-y-2.5 text-xs">
                    <div>
                      <span className="text-[10px] text-gray-400 uppercase font-bold">Catchy Bengali Headline</span>
                      <div className="text-sm font-black text-amber-300 font-tiro">
                        {thumbResult.catchyHeadlineBengali}
                      </div>
                    </div>
                    <div>
                      <span className="text-[10px] text-gray-400 uppercase font-bold">English Headline</span>
                      <div className="text-xs font-bold text-white">
                        {thumbResult.catchyHeadlineEnglish}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 pt-1 text-[11px] text-gray-300">
                      <span className="px-2 py-0.5 rounded bg-red-500/20 text-red-300 font-bold">
                        {thumbResult.badgeText}
                      </span>
                      <span>Color: {thumbResult.recommendedTextColor}</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 6. YouTube Metadata */}
          {activeTab === 'youtube-metadata' && (
            <div className="space-y-4 max-w-xl mx-auto">
              <div className="space-y-1">
                <h4 className="text-base font-bold text-white flex items-center gap-2">
                  <Tag className="w-4 h-4 text-emerald-400" />
                  <span>{isBn ? 'ইউটিউব এসইও ও মেটাডাটা জেনারেটর' : 'YouTube Metadata & SEO Generator'}</span>
                </h4>
                <p className="text-xs text-gray-400">
                  {isBn
                    ? 'ভাইরাল টাইটেল, বাংলা ডেসক্রিপশন, হ্যাশট্যাগ ও ট্যাগ জেনারেট করুন।'
                    : 'Generate optimized SEO titles, descriptions, hashtags, and keywords.'}
                </p>
              </div>

              <div className="bg-[#141A28] border border-gray-800 rounded-3xl p-5 space-y-4">
                <div>
                  <label className="text-xs font-bold text-gray-300 block mb-1">
                    {isBn ? 'ভিডিও টাইটেল বা টপিক' : 'Video Title / Topic'}
                  </label>
                  <input
                    type="text"
                    value={metaTitle}
                    onChange={(e) => setMetaTitle(e.target.value)}
                    className="w-full bg-[#0E121C] border border-gray-700 rounded-xl px-3 py-2 text-xs text-white outline-none"
                  />
                </div>

                <button
                  onClick={handleRunMetadata}
                  disabled={loading}
                  className="w-full py-3 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg active:scale-95 transition"
                >
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                  <span>{isBn ? 'এসইও মেটাডাটা তৈরি করুন' : 'GENERATE YOUTUBE METADATA'}</span>
                </button>

                {metaResult && (
                  <div className="space-y-3 pt-2">
                    {/* Title */}
                    <div className="p-3 rounded-2xl bg-[#0E121C] border border-gray-800 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] text-gray-400 uppercase font-bold">SEO Title (Bengali)</span>
                        <button
                          onClick={() => handleCopy(metaResult.seoTitleBengali, 'title')}
                          className="text-[10px] text-amber-400 flex items-center gap-1 font-bold"
                        >
                          {copiedKey === 'title' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                          <span>{copiedKey === 'title' ? 'Copied' : 'Copy'}</span>
                        </button>
                      </div>
                      <p className="text-xs font-bold text-white font-tiro">{metaResult.seoTitleBengali}</p>
                    </div>

                    {/* Hashtags */}
                    <div className="p-3 rounded-2xl bg-[#0E121C] border border-gray-800 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] text-gray-400 uppercase font-bold">Viral Hashtags</span>
                        <button
                          onClick={() => handleCopy(metaResult.hashtags.join(' '), 'hashtags')}
                          className="text-[10px] text-amber-400 flex items-center gap-1 font-bold"
                        >
                          {copiedKey === 'hashtags' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                          <span>{copiedKey === 'hashtags' ? 'Copied' : 'Copy All'}</span>
                        </button>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {metaResult.hashtags?.map((tag: string) => (
                          <span key={tag} className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-300 font-mono">
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Description */}
                    <div className="p-3 rounded-2xl bg-[#0E121C] border border-gray-800 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] text-gray-400 uppercase font-bold">Description</span>
                        <button
                          onClick={() => handleCopy(metaResult.descriptionBengali, 'desc')}
                          className="text-[10px] text-amber-400 flex items-center gap-1 font-bold"
                        >
                          {copiedKey === 'desc' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                          <span>{copiedKey === 'desc' ? 'Copied' : 'Copy'}</span>
                        </button>
                      </div>
                      <p className="text-xs text-gray-300 font-tiro line-clamp-3 whitespace-pre-line">
                        {metaResult.descriptionBengali}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
