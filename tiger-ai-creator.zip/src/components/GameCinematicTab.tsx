import React, { useState } from 'react';
import {
  Gamepad2,
  Sparkles,
  Film,
  Swords,
  Shield,
  Zap,
  Flame,
  ArrowRight,
  Loader2,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import {
  AspectRatio,
  CameraMotion,
  GameCinematicMode,
  Project,
  Scene,
  SoundEffectType,
  StoryLanguage,
} from '../types';
import { GAME_CINEMATIC_MODES } from '../utils/constants';
import { createProceduralSceneCanvas, generateImage, generateStory, generateTTS } from '../services/geminiService';
import { safeVibrate } from '../utils/haptics';

interface GameCinematicTabProps {
  project: Project;
  onApplyGameProject: (newProject: Partial<Project>) => void;
  onSwitchToStudio: () => void;
}

const GAME_HEROES = [
  { id: 'cyber_warrior', name: 'Kage Cyber Operative', icon: '🥷', desc: 'Sleek matte-black nano armor, neon cyan glowing katana, holographic visor' },
  { id: 'vedic_knight', name: 'Arjun Sun Champion', icon: '🏹', desc: 'Golden solar plate armor, celestial bow with radiant plasma arrows' },
  { id: 'rpg_sorceress', name: 'Aria Runic Sorceress', icon: '🔮', desc: 'Floating velvet spellbook, amethyst rune orbs, arcane cloak' },
  { id: 'apex_pilot', name: 'Nitro Apex Racer', icon: '🏎️', desc: 'Carbon fiber fireproof suit, aero helmet with tinted prism visor' },
  { id: 'void_marine', name: 'Titan Orbital Commando', icon: '🚀', desc: 'Heavy exoskeleton armor, dual shoulder micro-missile pods' },
];

const GAME_PRESETS = [
  {
    mode: 'Battle' as GameCinematicMode,
    title: 'The Siege of Asura Fortress',
    prompt: 'Two rival futuristic armies clash before the massive obsidian fortress gates as orbital plasma strikes illuminate the stormy sky',
  },
  {
    mode: 'Racing' as GameCinematicMode,
    title: 'Tokyo Midnight Hyper-Drift',
    prompt: 'Twin custom hypercars drift through rain-soaked neon cyberpunk avenues at 240 MPH dodging holographic traffic',
  },
  {
    mode: 'RPG fantasy' as GameCinematicMode,
    title: 'Dungeon of the Forgotten Primordial',
    prompt: 'Hero steps into a forgotten underground crystalline vault and awakens a dormant colossal stone guardian',
  },
  {
    mode: 'Sci-fi' as GameCinematicMode,
    title: 'Station Horizon Breach',
    prompt: 'Zero gravity space station combat with atmospheric decompression and breaching drones',
  },
];

export const GameCinematicTab: React.FC<GameCinematicTabProps> = ({
  project,
  onApplyGameProject,
  onSwitchToStudio,
}) => {
  const [gameMode, setGameMode] = useState<GameCinematicMode>('3D cinematic');
  const [selectedHero, setSelectedHero] = useState<string>('cyber_warrior');
  const [gameTitle, setGameTitle] = useState<string>('Apex Legends: Awakening');
  const [premisePrompt, setPremisePrompt] = useState<string>(GAME_PRESETS[0].prompt);
  const [language, setLanguage] = useState<StoryLanguage>(project.language);
  const [duration, setDuration] = useState<number>(30);
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>(project.aspectRatio);

  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [statusText, setStatusText] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleApplyPreset = (preset: typeof GAME_PRESETS[0]) => {
    safeVibrate(10);
    setGameMode(preset.mode);
    setGameTitle(preset.title);
    setPremisePrompt(preset.prompt);
  };

  const handleGenerateGameCinematic = async () => {
    if (!premisePrompt.trim()) {
      setErrorMessage('Please describe the game cinematic scene or select a preset.');
      return;
    }

    setIsGenerating(true);
    setErrorMessage(null);
    safeVibrate(25);
    setStatusText(`Directing ${gameMode} Unreal Engine 5 aesthetic in ${language}...`);

    try {
      const hero = GAME_HEROES.find((h) => h.id === selectedHero);

      // Step 1: Generate High-Octane Script
      const storyRes = await generateStory({
        language,
        storyType: 'Action',
        durationSeconds: duration,
        userStory: `Triple-A Game Cinematic Trailer: ${gameTitle}. Mode: ${gameMode}. Protagonist: ${hero?.name} (${hero?.desc}). Scenario: ${premisePrompt}. High stakes, dramatic game trailer cadence, thunderous tension, and breathtaking climax.`,
      });

      setStatusText(`Assembling connected environments and action camera sequences...`);

      const sceneCount = Math.max(3, Math.min(6, Math.round(duration / 5)));
      const rawScenes = storyRes.fullScript.split(/\n\n+/).filter((s) => s.trim().length > 10);

      const motions: CameraMotion[] = ['cinematic-push', 'camera-shake', 'slow-motion', 'zoom-in', 'pan-left'];
      const sfxList: SoundEffectType[] = ['cinematic_hit', 'thunder', 'whoosh', 'magic_sparkle'];

      const generatedScenes: Scene[] = [];

      for (let i = 0; i < sceneCount; i++) {
        const sceneNum = i + 1;
        setStatusText(`Rendering cinematic game shot ${sceneNum}/${sceneCount}...`);

        const narrationText = rawScenes[i] || `${gameTitle}: Scene ${sceneNum} reaches fever pitch intensity.`;
        const visualDesc = `Unreal Engine 5 game cinematic still, ${gameMode} genre, protagonist ${hero?.name}, ${hero?.desc}, environment: ${premisePrompt}, raytraced volumetric fog, octane render, blockbuster cinematography, 8k textures`;

        let imageUrl = '';
        try {
          const img = await generateImage({
            prompt: visualDesc,
            aspectRatio,
            visualStyle: '3D',
          });
          imageUrl = img.imageUrl || '';
        } catch {}

        if (!imageUrl) {
          imageUrl = await createProceduralSceneCanvas(
            aspectRatio === '9:16' ? 720 : 1280,
            aspectRatio === '9:16' ? 1280 : 720,
            '3D',
            sceneNum,
            undefined,
            visualDesc
          );
        }

        let audioBase64: string | undefined;
        try {
          const tts = await generateTTS({
            text: narrationText,
            voice: 'Fenrir', // Deep resonant dramatic voice
          });
          if (tts.audioBase64) audioBase64 = tts.audioBase64;
        } catch {}

        generatedScenes.push({
          id: `sc_game_${Date.now()}_${sceneNum}`,
          sceneNumber: sceneNum,
          duration: Math.round(duration / sceneCount),
          narration: narrationText,
          englishNarration: narrationText,
          visualPrompt: visualDesc,
          imageUrl,
          cameraMotion: motions[i % motions.length],
          motionStrength: 8,
          soundEffect: sfxList[i % sfxList.length],
          subtitles: [],
          audioBase64,
        });

        safeVibrate(15);
      }

      // Step 2: Apply to project
      onApplyGameProject({
        title: gameTitle || storyRes.title || 'Game Cinematic Masterpiece',
        language,
        storyType: 'Action',
        visualStyle: '3D',
        aspectRatio,
        targetDuration: duration,
        bgmGenre: 'Game Synthwave Battle',
        subtitlePreset: 'neon-cyber',
        ttsVoice: 'Fenrir',
        scenes: generatedScenes,
        characterReference: {
          id: `char_hero_${Date.now()}`,
          name: hero?.name || 'Hero Champion',
          imageBase64: generatedScenes[0]?.imageUrl || '',
          genderOrForm: hero?.name,
          clothing: hero?.desc,
          keyIdentifiers: hero?.desc,
          locked: true,
        },
        updatedAt: Date.now(),
      });

      safeVibrate([30, 50, 40]);
      onSwitchToStudio();
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || 'Game cinematic generation failed.');
    } finally {
      setIsGenerating(false);
      setStatusText('');
    }
  };

  return (
    <div className="bg-[#0E121C] border border-gray-800 rounded-3xl p-4 sm:p-6 space-y-6 shadow-xl max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-gray-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-gradient-to-br from-cyan-500 via-blue-600 to-indigo-700 text-white shadow-lg shadow-cyan-500/20">
            <Gamepad2 className="w-5 h-5 font-black" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base sm:text-lg font-bold text-white">
                Game Cinematic Video Studio
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                Unreal Engine 5 Fidelity
              </span>
            </div>
            <p className="text-xs text-gray-400">
              Create connected 3D cinematic game trailers, RPG fantasy, battle sequences, racing chases, and sci-fi epics with character continuity.
            </p>
          </div>
        </div>
      </div>

      {/* Game Mode Grid */}
      <div className="space-y-2">
        <label className="text-xs font-bold text-gray-300 uppercase tracking-wider">
          1. Select Game Cinematic Genre
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
          {GAME_CINEMATIC_MODES.map((gm) => (
            <button
              key={gm.id}
              type="button"
              onClick={() => {
                safeVibrate(10);
                setGameMode(gm.id as GameCinematicMode);
              }}
              className={`p-2.5 rounded-xl border text-left transition ${
                gameMode === gm.id
                  ? 'bg-gradient-to-b from-cyan-500/20 to-blue-500/10 border-cyan-400 text-white shadow-md'
                  : 'bg-[#121622] border-gray-800 text-gray-400 hover:border-gray-700'
              }`}
            >
              <div className="text-lg mb-1">{gm.icon}</div>
              <div className="text-xs font-bold text-white truncate">{gm.label}</div>
              <div className="text-[10px] text-gray-400 line-clamp-1 mt-0.5">{gm.desc}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Lead Hero Selection */}
      <div className="space-y-2">
        <label className="text-xs font-bold text-gray-300 uppercase tracking-wider">
          2. Select Lead Hero / Avatar
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2">
          {GAME_HEROES.map((hero) => (
            <button
              key={hero.id}
              type="button"
              onClick={() => {
                safeVibrate(10);
                setSelectedHero(hero.id);
              }}
              className={`p-2.5 rounded-xl border text-left transition flex items-center gap-2.5 ${
                selectedHero === hero.id
                  ? 'bg-cyan-500/15 border-cyan-400 text-white shadow-md'
                  : 'bg-[#121622] border-gray-800 text-gray-400 hover:border-gray-700'
              }`}
            >
              <span className="text-2xl">{hero.icon}</span>
              <div className="min-w-0">
                <div className="text-xs font-bold text-white truncate">{hero.name}</div>
                <div className="text-[10px] text-gray-400 truncate">{hero.desc}</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Cinematic Premise */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-gray-300 uppercase tracking-wider">
            3. Cinematic Scenario & Action Arc
          </label>
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[11px] text-gray-400">Presets:</span>
            {GAME_PRESETS.map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleApplyPreset(p)}
                className="px-2 py-0.5 rounded-md bg-gray-800 hover:bg-gray-700 text-cyan-300 text-[10px] font-semibold transition"
              >
                {p.mode}
              </button>
            ))}
          </div>
        </div>
        <textarea
          rows={3}
          value={premisePrompt}
          onChange={(e) => setPremisePrompt(e.target.value)}
          placeholder="Describe the action sequence, battle environment, camera movement, or trailer climax..."
          className="w-full bg-[#121622] border border-gray-700 focus:border-cyan-500 rounded-2xl p-3 text-xs sm:text-sm text-white outline-none resize-none"
        />
      </div>

      {/* Settings Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Language */}
        <div className="space-y-1">
          <label className="text-xs font-bold text-gray-300">Voiceover Language</label>
          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value as StoryLanguage)}
            className="w-full bg-[#121622] border border-gray-700 focus:border-cyan-500 rounded-xl px-3 py-2 text-xs text-white outline-none"
          >
            <option value="English">English</option>
            <option value="Hindi">Hindi (हिंदी)</option>
            <option value="Bengali">Bengali (বাংলা)</option>
          </select>
        </div>

        {/* Duration */}
        <div className="space-y-1">
          <label className="text-xs font-bold text-gray-300">Trailer Duration</label>
          <select
            value={duration}
            onChange={(e) => setDuration(parseInt(e.target.value))}
            className="w-full bg-[#121622] border border-gray-700 focus:border-cyan-500 rounded-xl px-3 py-2 text-xs text-white outline-none"
          >
            <option value={10}>10 Seconds (Teaser)</option>
            <option value={20}>20 Seconds (Combat Cut)</option>
            <option value={30}>30 Seconds (Game Trailer)</option>
            <option value={60}>60 Seconds (Epic Cinematic Arc)</option>
          </select>
        </div>

        {/* Aspect Ratio */}
        <div className="space-y-1">
          <label className="text-xs font-bold text-gray-300">Aspect Ratio</label>
          <select
            value={aspectRatio}
            onChange={(e) => setAspectRatio(e.target.value as AspectRatio)}
            className="w-full bg-[#121622] border border-gray-700 focus:border-cyan-500 rounded-xl px-3 py-2 text-xs text-white outline-none"
          >
            <option value="16:9">16:9 Cinema / PC / Console</option>
            <option value="9:16">9:16 Mobile Gaming Shorts</option>
            <option value="1:1">1:1 Square Feed</option>
          </select>
        </div>
      </div>

      {/* Error Notice */}
      {errorMessage && (
        <div className="bg-red-950/40 border border-red-500/40 rounded-xl p-3 text-xs text-red-300 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Submit Button */}
      <div>
        <button
          onClick={handleGenerateGameCinematic}
          disabled={isGenerating}
          className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-black text-sm shadow-xl shadow-cyan-500/20 transition active:scale-98 flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {isGenerating ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-white" />
              <span>{statusText || 'Rendering 3D Game Cinematic...'}</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 text-cyan-300" />
              <span>Generate {gameMode} Cinematic & Open Studio</span>
              <ArrowRight className="w-4 h-4 text-white ml-1" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};
