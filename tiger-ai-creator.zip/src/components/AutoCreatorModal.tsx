import React, { useState, useRef } from 'react';
import {
  X,
  Upload,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Layers,
  Music,
  Mic,
  Camera,
  Film,
  Subtitles,
  Volume2,
  RefreshCw,
  Image as ImageIcon,
} from 'lucide-react';
import {
  AspectRatio,
  BgmGenre,
  Project,
  Scene,
  StoryLanguage,
  StoryType,
  SubtitlePreset,
  VisualStyle,
} from '../types';
import {
  ASPECT_RATIOS,
  BGM_GENRES,
  STORY_LANGUAGES,
  STORY_TYPES,
  VISUAL_STYLES,
} from '../utils/constants';
import {
  analyzeImage,
  breakScenes,
  createProceduralSceneCanvas,
  generateImage,
  generateStory,
  generateTTS,
  ImageAnalysisResult,
} from '../services/geminiService';

interface AutoCreatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onProjectCreated: (project: Project) => void;
}

const STEPS_LIST = [
  { step: 1, name: 'Analyze uploaded image', icon: Upload },
  { step: 2, name: 'Understand subject, environment & characters', icon: Layers },
  { step: 3, name: 'Generate AI story in chosen language', icon: Film },
  { step: 4, name: 'Break story into multiple scenes', icon: Film },
  { step: 5, name: 'Generate scene descriptions & prompts', icon: Sparkles },
  { step: 6, name: 'Generate AI images for each scene', icon: ImageIcon },
  { step: 7, name: 'Generate AI video clips with camera motion', icon: Camera },
  { step: 8, name: 'Generate AI voice narration (TTS)', icon: Mic },
  { step: 9, name: 'Add background music', icon: Music },
  { step: 10, name: 'Add suitable sound effects (SFX)', icon: Volume2 },
  { step: 11, name: 'Generate synchronized subtitles', icon: Subtitles },
  { step: 12, name: 'Automatically combine into complete video', icon: CheckCircle2 },
];

export const AutoCreatorModal: React.FC<AutoCreatorModalProps> = ({
  isOpen,
  onClose,
  onProjectCreated,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Form State
  const [uploadedPhotos, setUploadedPhotos] = useState<string[]>([]);
  const [language, setLanguage] = useState<StoryLanguage>('English');
  const [storyType, setStoryType] = useState<StoryType>('Devotional');
  const [visualStyle, setVisualStyle] = useState<VisualStyle>('Devotional');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('9:16');
  const [duration, setDuration] = useState<number>(30);
  const [customDuration, setCustomDuration] = useState<string>('');
  const [customNotes, setCustomNotes] = useState<string>('');

  // Processing State
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [stepDetail, setStepDetail] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setUploadedPhotos((prev) => [...prev, event.target!.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const removePhoto = (index: number) => {
    setUploadedPhotos((prev) => prev.filter((_, i) => i !== index));
  };

  const execute12StepCreation = async () => {
    if (uploadedPhotos.length === 0 && !customNotes.trim()) {
      setErrorMsg('Please upload a photo OR enter your story/prompt idea below.');
      return;
    }

    setIsProcessing(true);
    setErrorMsg(null);
    const targetDuration = customDuration ? parseInt(customDuration) || 30 : duration;

    try {
      // STEP 1: Analyze uploaded image or prompt
      setCurrentStep(1);
      setStepDetail(uploadedPhotos.length > 0 ? 'Scanning image pixels and visual composition...' : 'Analyzing story prompt and visual cues...');
      const primaryPhoto = uploadedPhotos[0] || null;
      let analysis: ImageAnalysisResult;
      
      if (primaryPhoto) {
        analysis = await analyzeImage(primaryPhoto).catch(() => ({
          subjectType: 'Subject',
          title: 'Divine Vision',
          summary: 'Beautiful vibrant scene with profound spiritual atmosphere',
          character: {
            isHumanoid: true,
            genderOrForm: 'Divine Figure',
            skinTone: 'Luminous glowing radiance',
            hair: 'Dark flowing locks adorned with ornaments',
            clothingAndAttire: 'Traditional celestial garments',
            keyIdentifiers: 'Distinctive divine smile, peaceful countenance',
          },
          environment: {
            setting: 'Vrindavan celestial grove',
            mood: 'Devotional & Serene',
          },
          recommendedStoryTypes: ['Krishna story', 'Devotional', 'Bhagavad Gita'],
          recommendedStyles: ['Devotional', 'Indian mythology'],
        }));
      } else {
        analysis = {
          subjectType: 'Narrative Subject',
          title: customNotes.slice(0, 30) || 'AI Vision',
          summary: customNotes || 'Cinematic video narrative',
          character: {
            isHumanoid: true,
            genderOrForm: 'Protagonist',
            skinTone: 'Natural glowing complexion',
            hair: 'Detailed natural styled hair',
            clothingAndAttire: 'Heroic cinematic attire',
            keyIdentifiers: 'Expressive eyes, distinctive cinematic presence',
          },
          environment: {
            setting: 'Atmospheric cinematic world',
            mood: 'Inspiring and Dramatic',
          },
          recommendedStoryTypes: [storyType],
          recommendedStyles: [visualStyle],
        };
      }

      // STEP 2: Understand subject, environment and characters
      setCurrentStep(2);
      setStepDetail(
        `Subject: ${analysis.subjectType || 'Subject'} | Setting: ${analysis.environment?.setting || 'Atmospheric setting'}`
      );
      await new Promise((r) => setTimeout(r, 600));

      // Auto-tune style or story if user selected generic
      if (analysis.recommendedStoryTypes && analysis.recommendedStoryTypes.length > 0) {
        // Optional suggestion
      }

      // STEP 3: Generate suitable story based on image
      setCurrentStep(3);
      setStepDetail(`Writing narrative in ${language} for ${targetDuration}s duration...`);
      const storyData = await generateStory({
        language,
        storyType,
        durationSeconds: targetDuration,
        imageAnalysis: analysis,
        customNotes,
      });

      // STEP 4: Break story into multiple scenes
      setCurrentStep(4);
      setStepDetail('Dividing storyline into timed visual scenes...');
      const sceneBreakdown = await breakScenes({
        story: {
          title: storyData.title || 'Divine Journey',
          fullScript: storyData.fullScript,
        },
        language,
        storyType,
        durationSeconds: targetDuration,
        visualStyle,
        characterReference: analysis.character
          ? {
              id: 'char_ref_1',
              name: analysis.character.genderOrForm || 'Main Subject',
              imageBase64: primaryPhoto || '',
              skinTone: analysis.character.skinTone,
              hairStyle: analysis.character.hair,
              facialHair: analysis.character.facialHair,
              clothing: analysis.character.clothingAndAttire,
              keyIdentifiers: analysis.character.keyIdentifiers,
              locked: true,
            }
          : null,
      });

      // STEP 5: Generate scene descriptions/prompts
      setCurrentStep(5);
      setStepDetail(`Refining ${sceneBreakdown.scenes.length} camera directions and visual prompts...`);
      await new Promise((r) => setTimeout(r, 500));

      // STEP 6: Generate AI images for each scene
      setCurrentStep(6);
      setStepDetail(`Synthesizing consistent high-res visual frames for all scenes...`);
      const processedScenes: Scene[] = [];

      for (let i = 0; i < sceneBreakdown.scenes.length; i++) {
        const rawScene = sceneBreakdown.scenes[i];
        setStepDetail(`Generating scene ${i + 1}/${sceneBreakdown.scenes.length}: ${rawScene.visualPrompt.slice(0, 45)}...`);

        // Use uploaded photo for scene 1 if available or attempt AI image generation
        let sceneImgUrl = '';
        if (i < uploadedPhotos.length) {
          // Direct uploaded photo graded with cinematic renderer
          sceneImgUrl = await createProceduralSceneCanvas(
            aspectRatio === '9:16' ? 720 : 1280,
            aspectRatio === '9:16' ? 1280 : 720,
            visualStyle,
            i + 1,
            uploadedPhotos[i],
            rawScene.visualPrompt
          );
        } else {
          // Attempt AI image generation with fallback to procedural visual canvas
          const imgGenResult = await generateImage({
            prompt: rawScene.visualPrompt,
            aspectRatio,
            visualStyle,
            characterReferenceBase64: primaryPhoto || undefined,
          });

          if (imgGenResult.imageUrl) {
            sceneImgUrl = imgGenResult.imageUrl;
          } else {
            sceneImgUrl = await createProceduralSceneCanvas(
              aspectRatio === '9:16' ? 720 : 1280,
              aspectRatio === '9:16' ? 1280 : 720,
              visualStyle,
              i + 1,
              primaryPhoto || undefined,
              rawScene.visualPrompt
            );
          }
        }

        // STEP 8: Generate AI voice narration for this scene
        let audioBase64: string | undefined = undefined;
        try {
          const ttsRes = await generateTTS({
            text: rawScene.narration,
            voice: 'Kore',
          });
          if (ttsRes.audioBase64) {
            audioBase64 = ttsRes.audioBase64;
          }
        } catch {}

        processedScenes.push({
          id: `sc_auto_${Date.now()}_${i + 1}`,
          sceneNumber: i + 1,
          duration: rawScene.duration || Math.round(targetDuration / sceneBreakdown.scenes.length),
          narration: rawScene.narration,
          englishNarration: rawScene.englishNarration,
          visualPrompt: rawScene.visualPrompt,
          imageUrl: sceneImgUrl,
          cameraMotion: rawScene.cameraMotion || 'zoom-in',
          motionStrength: rawScene.motionStrength || 7,
          soundEffect: rawScene.soundEffect || (i === 0 ? 'temple_bell' : 'whoosh'),
          subtitles: rawScene.subtitles && rawScene.subtitles.length > 0 ? rawScene.subtitles : [],
          audioBase64,
        });
      }

      // STEP 7: Generate AI video clips from the scenes (camera motion already calibrated)
      setCurrentStep(7);
      setStepDetail('Applying pan, zoom, tilt, and cinematic motion strength...');
      await new Promise((r) => setTimeout(r, 600));

      // STEP 8: Voice Narration Confirmation
      setCurrentStep(8);
      setStepDetail('Calibrating speech rhythm and vocal inflections...');
      await new Promise((r) => setTimeout(r, 400));

      // STEP 9: Add background music
      setCurrentStep(9);
      const bgmChoice: BgmGenre =
        storyType === 'Devotional' || storyType === 'Krishna story' || storyType === 'Radha Krishna'
          ? 'Devotional (Flute & Sitar)'
          : storyType === 'Horror' || storyType === 'Mystery'
          ? 'Horror Ambient Drone'
          : storyType === 'Motivational'
          ? 'Motivational Epic'
          : storyType === 'Action'
          ? 'Action Beats'
          : 'Cinematic Orchestral';
      setStepDetail(`Adding royalty-free music: ${bgmChoice}...`);
      await new Promise((r) => setTimeout(r, 400));

      // STEP 10: Add suitable sound effects
      setCurrentStep(10);
      setStepDetail('Aligning temple bells, cinematic hits, and atmospheric cues...');
      await new Promise((r) => setTimeout(r, 400));

      // STEP 11: Generate synchronized subtitles
      setCurrentStep(11);
      const subPreset: SubtitlePreset =
        storyType === 'Devotional' || storyType === 'Krishna story' || storyType === 'Radha Krishna'
          ? 'devotional-gold'
          : 'viral-yellow';
      setStepDetail(`Formatting dynamic subtitles: ${subPreset}...`);
      await new Promise((r) => setTimeout(r, 400));

      // STEP 12: Combine everything into a complete video!
      setCurrentStep(12);
      setStepDetail('Assembling master project timeline and finalizing video!');
      await new Promise((r) => setTimeout(r, 600));

      const newProject: Project = {
        id: `proj_${Date.now()}`,
        title: storyData.title || `${storyType} Video`,
        language,
        storyType,
        visualStyle,
        aspectRatio,
        targetDuration,
        bgmGenre: bgmChoice,
        bgmVolume: 0.35,
        voiceVolume: 1.0,
        ttsVoice: 'Kore',
        subtitlePreset: subPreset,
        characterReference: analysis.character
          ? {
              id: `char_${Date.now()}`,
              name: analysis.character.genderOrForm || 'Character',
              imageBase64: primaryPhoto || '',
              genderOrForm: analysis.character.genderOrForm,
              skinTone: analysis.character.skinTone,
              hairStyle: analysis.character.hair,
              facialHair: analysis.character.facialHair,
              clothing: analysis.character.clothingAndAttire,
              keyIdentifiers: analysis.character.keyIdentifiers,
              locked: true,
            }
          : undefined,
        scenes: processedScenes,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };

      onProjectCreated(newProject);
      onClose();
    } catch (err: any) {
      console.error('Auto creation failed:', err);
      setErrorMsg(err.message || 'An unexpected error occurred during automatic video creation.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-5 overflow-y-auto">
      <div className="w-full max-w-2xl bg-[#0E121C] border border-amber-500/30 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-amber-950/40 via-[#131926] to-[#0E121C] border-b border-amber-500/20 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 to-orange-600 flex items-center justify-center text-black font-extrabold shadow-md">
              🐅
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-white flex items-center gap-1.5">
                CREATE VIDEO AUTOMATICALLY
              </h2>
              <p className="text-xs text-amber-400/90">
                1-Tap 12-Step AI Short Video Pipeline
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isProcessing}
            className="p-1.5 rounded-lg bg-gray-800/80 text-gray-400 hover:text-white transition disabled:opacity-50"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 space-y-5 overflow-y-auto flex-1">
          {/* Step Progress Tracker if processing */}
          {isProcessing ? (
            <div className="space-y-4 py-3">
              <div className="text-center space-y-1">
                <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 mb-2">
                  <Loader2 className="w-7 h-7 animate-spin" />
                </div>
                <h3 className="text-base font-bold text-white">
                  Step {currentStep} of 12: {STEPS_LIST[currentStep - 1]?.name || 'Processing...'}
                </h3>
                <p className="text-xs text-amber-400 font-medium animate-pulse">{stepDetail}</p>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-gray-800/80 rounded-full h-2.5 overflow-hidden border border-gray-700">
                <div
                  className="bg-gradient-to-r from-amber-500 via-orange-500 to-yellow-400 h-full transition-all duration-300 rounded-full"
                  style={{ width: `${(currentStep / 12) * 100}%` }}
                />
              </div>

              {/* Steps Checklist */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-4 max-h-60 overflow-y-auto pr-1">
                {STEPS_LIST.map((s) => {
                  const Icon = s.icon;
                  const isDone = s.step < currentStep;
                  const isCurrent = s.step === currentStep;
                  return (
                    <div
                      key={s.step}
                      className={`flex items-center gap-2 p-2 rounded-xl text-xs transition ${
                        isDone
                          ? 'bg-emerald-950/30 border border-emerald-500/30 text-emerald-300'
                          : isCurrent
                          ? 'bg-amber-500/15 border border-amber-500/50 text-amber-200 font-semibold'
                          : 'bg-gray-900/40 border border-gray-800 text-gray-500'
                      }`}
                    >
                      {isDone ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                      ) : isCurrent ? (
                        <Loader2 className="w-4 h-4 text-amber-400 animate-spin flex-shrink-0" />
                      ) : (
                        <Icon className="w-4 h-4 text-gray-500 flex-shrink-0" />
                      )}
                      <span className="truncate">
                        {s.step}. {s.name}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <>
              {/* Photo Upload Zone */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider">
                  Upload Photo(s) / Character Reference <span className="text-red-400">*</span>
                </label>
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-amber-500/40 hover:border-amber-400/80 bg-amber-500/5 hover:bg-amber-500/10 rounded-2xl p-4 sm:p-6 text-center cursor-pointer transition flex flex-col items-center justify-center gap-2"
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handlePhotoUpload}
                    className="hidden"
                  />
                  <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center shadow-inner">
                    <Upload className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-white">
                      Tap to select or take photos with camera
                    </p>
                    <p className="text-xs text-gray-400 mt-0.5">
                      Upload person, deity (Krishna, Radha), scenery, or product
                    </p>
                  </div>
                </div>

                {/* Uploaded Thumbnails Preview */}
                {uploadedPhotos.length > 0 && (
                  <div className="flex items-center gap-2 pt-2 overflow-x-auto pb-1">
                    {uploadedPhotos.map((photo, idx) => (
                      <div
                        key={idx}
                        className="relative w-16 h-16 sm:w-20 sm:h-20 rounded-xl overflow-hidden border border-amber-500/50 flex-shrink-0 group"
                      >
                        <img
                          src={photo}
                          alt={`Upload ${idx + 1}`}
                          className="w-full h-full object-cover"
                        />
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            removePhoto(idx);
                          }}
                          className="absolute top-1 right-1 w-5 h-5 rounded-full bg-red-600 text-white flex items-center justify-center text-[10px] shadow"
                        >
                          ✕
                        </button>
                        <span className="absolute bottom-0 inset-x-0 bg-black/70 text-[9px] text-amber-300 font-semibold text-center py-0.5">
                          Photo {idx + 1}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Story Language & Story Type Selectors */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Language */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider">
                    Story Language
                  </label>
                  <select
                    value={language}
                    onChange={(e) => setLanguage(e.target.value as StoryLanguage)}
                    className="w-full bg-[#151A26] border border-gray-700 focus:border-amber-500 rounded-xl p-2.5 text-xs sm:text-sm text-white font-medium outline-none"
                  >
                    {STORY_LANGUAGES.map((lang) => (
                      <option key={lang.value} value={lang.value}>
                        {lang.label} ({lang.nativeLabel})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Story Type */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider">
                    Story Type / Genre
                  </label>
                  <select
                    value={storyType}
                    onChange={(e) => setStoryType(e.target.value as StoryType)}
                    className="w-full bg-[#151A26] border border-gray-700 focus:border-amber-500 rounded-xl p-2.5 text-xs sm:text-sm text-white font-medium outline-none"
                  >
                    {STORY_TYPES.map((t) => (
                      <option key={t.value} value={t.value}>
                        {t.icon} {t.value}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Visual Style & Aspect Ratio */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Style */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider">
                    Visual Style
                  </label>
                  <select
                    value={visualStyle}
                    onChange={(e) => setVisualStyle(e.target.value as VisualStyle)}
                    className="w-full bg-[#151A26] border border-gray-700 focus:border-amber-500 rounded-xl p-2.5 text-xs sm:text-sm text-white font-medium outline-none"
                  >
                    {VISUAL_STYLES.map((st) => (
                      <option key={st.value} value={st.value}>
                        {st.value}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Aspect Ratio */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider">
                    Format / Aspect Ratio
                  </label>
                  <div className="grid grid-cols-4 gap-1.5">
                    {ASPECT_RATIOS.map((ar) => (
                      <button
                        key={ar.value}
                        type="button"
                        onClick={() => setAspectRatio(ar.value)}
                        className={`p-2 rounded-xl text-center border text-xs font-bold transition flex flex-col items-center justify-center ${
                          aspectRatio === ar.value
                            ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-sm'
                            : 'bg-[#151A26] border-gray-700 text-gray-400 hover:text-gray-200'
                        }`}
                      >
                        <span className="text-sm mb-0.5">{ar.icon}</span>
                        <span className="text-[10px]">{ar.value}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Duration Buttons */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider">
                  Target Duration
                </label>
                <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5">
                  {[5, 10, 20, 30, 40, 50, 60].map((dur) => (
                    <button
                      key={dur}
                      type="button"
                      onClick={() => {
                        setDuration(dur);
                        setCustomDuration('');
                      }}
                      className={`py-2 rounded-xl text-xs font-bold border transition ${
                        duration === dur && !customDuration
                          ? 'bg-amber-500 text-black border-amber-400 shadow-md'
                          : 'bg-[#151A26] border-gray-700 text-gray-300 hover:text-white'
                      }`}
                    >
                      {dur}s
                    </button>
                  ))}
                  <div className="relative">
                    <input
                      type="number"
                      placeholder="Custom"
                      min={5}
                      max={120}
                      value={customDuration}
                      onChange={(e) => setCustomDuration(e.target.value)}
                      className={`w-full py-2 px-1 text-center rounded-xl text-xs font-bold border outline-none bg-[#151A26] ${
                        customDuration
                          ? 'border-amber-500 text-amber-300'
                          : 'border-gray-700 text-gray-400'
                      }`}
                    />
                  </div>
                </div>
              </div>

              {/* Optional Prompt/Notes */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider">
                  Custom Story Notes / Message (Optional)
                </label>
                <textarea
                  value={customNotes}
                  onChange={(e) => setCustomNotes(e.target.value)}
                  placeholder="e.g. Highlight Krishna's compassion and Radha's smile, or write your own specific plot..."
                  rows={2}
                  className="w-full bg-[#151A26] border border-gray-700 focus:border-amber-500 rounded-xl p-2.5 text-xs sm:text-sm text-gray-200 outline-none resize-none"
                />
              </div>

              {/* Error Message */}
              {errorMsg && (
                <div className="flex items-center gap-2 p-3 rounded-xl bg-red-950/40 border border-red-500/40 text-red-300 text-xs">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer Actions */}
        {!isProcessing && (
          <div className="p-4 bg-[#0A0D14] border-t border-gray-800 flex items-center justify-between gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-gray-800 text-gray-300 font-semibold text-xs sm:text-sm hover:text-white transition"
            >
              Cancel
            </button>

            <button
              onClick={execute12StepCreation}
              className="flex-1 max-w-sm py-3 px-4 rounded-xl bg-gradient-to-r from-amber-400 via-orange-500 to-red-500 hover:from-amber-300 hover:to-orange-400 text-black font-extrabold text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg shadow-orange-500/30 active:scale-95 transition-transform"
            >
              <Sparkles className="w-4 h-4 text-black" />
              CREATE VIDEO AUTOMATICALLY
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
