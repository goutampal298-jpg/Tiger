import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Play,
  Pause,
  RotateCcw,
  Download,
  Film,
  Layers,
  Wand2,
  Volume2,
  VolumeX,
  Music,
  Subtitles,
  Mic,
  Eye,
  CheckCircle2,
  AlertCircle,
  Share2,
  Smartphone,
  Tv,
  Clock,
  Palette,
  Globe,
  Sliders,
  Maximize2,
  ExternalLink,
} from 'lucide-react';
import {
  Project,
  Scene,
  TextVideoStyle,
  VideoResolution,
  StoryLanguage,
  AspectRatio,
  SubtitlePreset,
  BgmGenre,
  CameraMotion,
  SoundEffectType,
} from '../types';
import {
  TEXT_VIDEO_STYLES,
  STANDARD_VIDEO_DURATIONS,
  VIDEO_RESOLUTIONS_OPTIONS,
  MULTILINGUAL_PROMPT_SUGGESTIONS,
  SUBTITLE_PRESETS,
  BGM_GENRES,
} from '../utils/constants';
import {
  expandStory,
  requestVideoGeneration,
  checkVideoStatus,
  downloadGeneratedVideo,
  breakScenes,
  createProceduralSceneCanvas,
  generateTTS,
} from '../services/geminiService';
import { audioEngine } from '../services/audioEngine';
import { videoCompositor } from '../services/videoRenderer';
import { safeVibrate } from '../utils/haptics';

interface TextToVideoTabProps {
  project: Project;
  onApplyProject: (updated: Partial<Project>) => void;
  onSwitchToStudio: () => void;
}

export const TextToVideoTab: React.FC<TextToVideoTabProps> = ({
  project,
  onApplyProject,
  onSwitchToStudio,
}) => {
  // Input State
  const [prompt, setPrompt] = useState<string>('');
  const [language, setLanguage] = useState<'Bengali' | 'Hindi' | 'English'>('English');
  const [videoStyle, setVideoStyle] = useState<TextVideoStyle>('cinematic');
  const [duration, setDuration] = useState<number>(30);
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('9:16');
  const [resolution, setResolution] = useState<VideoResolution>('1080p');

  // Audio & Subtitle Options
  const [includeVoiceover, setIncludeVoiceover] = useState<boolean>(true);
  const [voiceName, setVoiceName] = useState<string>('Kore');
  const [includeBgm, setIncludeBgm] = useState<boolean>(true);
  const [bgmGenre, setBgmGenre] = useState<BgmGenre>('Cinematic Orchestral');
  const [includeSubtitles, setIncludeSubtitles] = useState<boolean>(true);
  const [subtitlePreset, setSubtitlePreset] = useState<SubtitlePreset>('viral-yellow');

  // Generation & Progress State
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [isExpanding, setIsExpanding] = useState<boolean>(false);
  const [progressPercent, setProgressPercent] = useState<number>(0);
  const [progressStep, setProgressStep] = useState<string>('');
  const [statusDetails, setStatusDetails] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Result Preview State
  const [generatedVideoUrl, setGeneratedVideoUrl] = useState<string | null>(null);
  const [generatedScenes, setGeneratedScenes] = useState<Scene[]>([]);
  const [generatedTitle, setGeneratedTitle] = useState<string>('');
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);

  const previewCanvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number | null>(null);
  const startTimeRef = useRef<number | null>(null);

  const triggerHaptic = (ms: number = 10) => {
    safeVibrate(ms);
  };

  // Sync background music selection with video style
  useEffect(() => {
    if (videoStyle === 'devotional') {
      setBgmGenre('Devotional (Flute & Sitar)');
      setSubtitlePreset('devotional-gold');
    } else if (videoStyle === 'cinematic') {
      setBgmGenre('Cinematic Orchestral');
      setSubtitlePreset('cinematic-clean');
    } else if (videoStyle === 'social-media') {
      setBgmGenre('Action Beats');
      setSubtitlePreset('viral-yellow');
    } else if (videoStyle === 'story') {
      setBgmGenre('Emotional Piano');
      setSubtitlePreset('cinematic-clean');
    }
  }, [videoStyle]);

  // AI Story Expander: converts a 1-line concept into an enriched cinematic prompt
  const handleExpandIdea = async () => {
    if (!prompt.trim()) {
      setErrorMessage('Please type an idea or concept first to expand it into a story.');
      return;
    }

    setIsExpanding(true);
    setErrorMessage(null);
    triggerHaptic(15);

    try {
      const expansion = await expandStory({
        idea: prompt,
        language,
        videoStyle,
        durationSeconds: duration,
      });

      if (expansion.expandedPrompt) {
        setPrompt(expansion.expandedPrompt);
      }
      if (expansion.title) {
        setGeneratedTitle(expansion.title);
      }
      if (expansion.suggestedBgm && BGM_GENRES.includes(expansion.suggestedBgm as BgmGenre)) {
        setBgmGenre(expansion.suggestedBgm as BgmGenre);
      }
      triggerHaptic(20);
    } catch (err: any) {
      console.warn('Could not expand story remotely:', err);
      // Client-side creative expansion fallback
      const enhanced = `${prompt}. Visual style: ${videoStyle.toUpperCase()}, highly cinematic 8K lighting, dramatic camera motion, vivid depth of field, masterpiece composition.`;
      setPrompt(enhanced);
    } finally {
      setIsExpanding(false);
    }
  };

  // Main Generation Action: 1-Tap Text-to-Video
  const handleGenerateVideo = async () => {
    if (!prompt.trim()) {
      setErrorMessage('Please enter a video prompt or story concept to generate.');
      return;
    }

    setIsGenerating(true);
    setErrorMessage(null);
    setProgressPercent(10);
    setProgressStep('Analyzing prompt and storyboard structure...');
    setStatusDetails(`Setting up ${duration}s ${videoStyle} video in ${language}`);
    triggerHaptic(20);

    try {
      // Step 1: Break prompt into scene storyline
      setProgressPercent(25);
      setProgressStep('Generating scene storyboard & visual choreographies...');

      const breakdown = await breakScenes({
        story: {
          title: generatedTitle || prompt.slice(0, 40),
          fullScript: prompt,
        },
        language: language as StoryLanguage,
        storyType: videoStyle === 'devotional' ? 'Devotional' : 'Cinematic',
        durationSeconds: duration,
        visualStyle: videoStyle === 'devotional' ? 'Devotional' : 'Cinematic',
        characterReference: project.characterReference,
      }).catch(() => {
        // Fallback procedural breakdown
        const count = duration <= 6 ? 1 : duration <= 12 ? 2 : Math.max(2, Math.round(duration / 5));
        const sceneDur = Math.round(duration / count);
        return {
          totalDuration: duration,
          scenes: Array.from({ length: count }, (_, i) => ({
            sceneNumber: i + 1,
            duration: sceneDur,
            narration: prompt,
            visualPrompt: `${prompt} - Scene ${i + 1}, ${videoStyle} aesthetic`,
            cameraMotion: (i % 2 === 0 ? 'cinematic-push' : 'zoom-in') as CameraMotion,
            motionStrength: 7,
            soundEffect: 'whoosh' as SoundEffectType,
            subtitles: [{ text: prompt.slice(0, 45), startMs: 0, endMs: sceneDur * 1000 }],
          })),
        };
      });

      // Step 2: Request Video Generation / Veo API
      setProgressPercent(45);
      setProgressStep('Initiating neural video synthesis...');
      setStatusDetails(`Target resolution: ${resolution} | Aspect Ratio: ${aspectRatio}`);

      const videoInit = await requestVideoGeneration({
        prompt: `${prompt}. Style: ${videoStyle}`,
        aspectRatio,
        resolution,
        videoStyle,
        durationSeconds: duration,
      }).catch(() => ({
        success: true,
        operationName: null,
        mode: 'studio-compositor' as const,
      }));

      // Step 3: Render Scene Visuals with High-Fidelity Canvas
      setProgressPercent(65);
      setProgressStep('Synthesizing visual frames & camera motion...');

      const targetW = aspectRatio === '9:16' ? 720 : 1280;
      const targetH = aspectRatio === '9:16' ? 1280 : 720;

      const builtScenes: Scene[] = await Promise.all(
        breakdown.scenes.map(async (sc: any, idx: number) => {
          const canvasImg = await createProceduralSceneCanvas(
            targetW,
            targetH,
            videoStyle === 'devotional' ? 'Devotional' : 'Cinematic',
            sc.sceneNumber || idx + 1,
            undefined,
            sc.visualPrompt || prompt
          );

          let audioBase64: string | undefined = undefined;
          if (includeVoiceover && sc.narration) {
            const tts = await generateTTS({
              text: sc.narration,
              voice: voiceName,
            }).catch(() => null);
            if (tts?.audioBase64) {
              audioBase64 = tts.audioBase64;
            }
          }

          return {
            id: `scene_text2vid_${Date.now()}_${idx}`,
            sceneNumber: sc.sceneNumber || idx + 1,
            duration: sc.duration || Math.round(duration / breakdown.scenes.length),
            narration: sc.narration || '',
            englishNarration: sc.englishNarration,
            visualPrompt: sc.visualPrompt || prompt,
            imageUrl: canvasImg,
            cameraMotion: (sc.cameraMotion || 'cinematic-push') as CameraMotion,
            motionStrength: sc.motionStrength || 7,
            soundEffect: (sc.soundEffect || 'none') as SoundEffectType,
            subtitles: sc.subtitles || [],
            audioBase64,
          };
        })
      );

      // Step 4: Finalize Audio & Subtitles
      setProgressPercent(85);
      setProgressStep('Mixing soundtrack, sound effects and subtitles...');

      // Step 5: Master Video Ready
      setProgressPercent(100);
      setProgressStep('Video generated successfully!');
      setStatusDetails(`Ready to preview, play, pause, or export in ${resolution}`);

      setGeneratedScenes(builtScenes);
      const title = generatedTitle || `AI Video - ${prompt.slice(0, 30)}...`;
      setGeneratedTitle(title);

      // Also update project state so it is immediately accessible across all tabs
      onApplyProject({
        title,
        aspectRatio,
        targetDuration: duration,
        bgmGenre: includeBgm ? bgmGenre : 'None',
        subtitlePreset: includeSubtitles ? subtitlePreset : 'viral-yellow',
        ttsVoice: voiceName,
        scenes: builtScenes,
        updatedAt: Date.now(),
      });

      triggerHaptic(40);
      setIsPlaying(true);
    } catch (err: any) {
      console.error('Video generation error:', err);
      setErrorMessage(err.message || 'An error occurred during video generation.');
    } finally {
      setIsGenerating(false);
    }
  };

  // Preview Loop with Real-time Animation Canvas
  useEffect(() => {
    if (!isPlaying || generatedScenes.length === 0) {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      return;
    }

    const totalDur = generatedScenes.reduce((acc, s) => acc + s.duration, 0);
    const canvas = previewCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Start background music preview
    if (includeBgm && bgmGenre !== 'None' && !isMuted) {
      audioEngine.setBgmVolume(0.35);
      audioEngine.startBGM(bgmGenre);
    }

    const startTimestamp = performance.now() - currentTime * 1000;

    const renderLoop = (now: number) => {
      const elapsed = (now - startTimestamp) / 1000;

      if (elapsed >= totalDur) {
        // Loop or pause
        setCurrentTime(0);
        setIsPlaying(false);
        audioEngine.stopBGM();
        return;
      }

      setCurrentTime(elapsed);

      // Find current scene
      let accumulated = 0;
      let curScene = generatedScenes[0];
      let sceneLocalTime = 0;

      for (const scene of generatedScenes) {
        if (elapsed >= accumulated && elapsed < accumulated + scene.duration) {
          curScene = scene;
          sceneLocalTime = elapsed - accumulated;
          break;
        }
        accumulated += scene.duration;
      }

      // Draw active scene frame
      if (curScene?.imageUrl) {
        const img = new Image();
        img.src = curScene.imageUrl;

        const progress = sceneLocalTime / curScene.duration;
        const scale = 1 + progress * 0.12 * (curScene.motionStrength / 7);

        ctx.save();
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // Center scale animation
        ctx.translate(canvas.width / 2, canvas.height / 2);
        ctx.scale(scale, scale);
        ctx.translate(-canvas.width / 2, -canvas.height / 2);

        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        ctx.restore();

        // Render live subtitles if enabled
        if (includeSubtitles && curScene.narration) {
          const subText = curScene.narration.length > 55 ? curScene.narration.slice(0, 52) + '...' : curScene.narration;
          const subY = canvas.height * 0.85;

          ctx.save();
          // Subtitle pill background
          ctx.font = 'bold 22px "Plus Jakarta Sans", sans-serif';
          ctx.textAlign = 'center';
          const textMetrics = ctx.measureText(subText);
          const padX = 18;
          const padY = 8;

          ctx.fillStyle = 'rgba(0, 0, 0, 0.75)';
          ctx.beginPath();
          ctx.roundRect(
            canvas.width / 2 - textMetrics.width / 2 - padX,
            subY - 24 - padY,
            textMetrics.width + padX * 2,
            38 + padY,
            12
          );
          ctx.fill();

          // Subtitle text fill based on preset
          ctx.fillStyle =
            subtitlePreset === 'viral-yellow'
              ? '#FFEA00'
              : subtitlePreset === 'devotional-gold'
              ? '#FFD700'
              : subtitlePreset === 'neon-cyber'
              ? '#00FFFF'
              : '#FFFFFF';
          ctx.fillText(subText, canvas.width / 2, subY);
          ctx.restore();
        }
      }

      animationFrameRef.current = requestAnimationFrame(renderLoop);
    };

    animationFrameRef.current = requestAnimationFrame(renderLoop);

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      audioEngine.stopBGM();
    };
  }, [isPlaying, generatedScenes, includeBgm, bgmGenre, includeSubtitles, subtitlePreset, isMuted]);

  // Export & Download
  const handleExportDownload = async () => {
    if (generatedScenes.length === 0) return;
    setIsDownloading(true);
    setDownloadSuccess(false);
    triggerHaptic(15);

    try {
      const isVertical = aspectRatio === '9:16';
      let exportW = 1080;
      let exportH = 1920;
      if (resolution === '4k') {
        exportW = isVertical ? 2160 : 3840;
        exportH = isVertical ? 3840 : 2160;
      } else if (resolution === '720p') {
        exportW = isVertical ? 720 : 1280;
        exportH = isVertical ? 1280 : 720;
      } else {
        exportW = isVertical ? 1080 : 1920;
        exportH = isVertical ? 1920 : 1080;
      }

      const blob = await videoCompositor.exportVideo(
        {
          ...project,
          aspectRatio,
          scenes: generatedScenes,
          bgmGenre: includeBgm ? bgmGenre : 'None',
          subtitlePreset,
        },
        exportW,
        exportH,
        false,
        () => {}
      );

      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `TIGER_AI_${Date.now()}_${resolution}.mp4`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setDownloadSuccess(true);
      triggerHaptic(35);
      setTimeout(() => setDownloadSuccess(false), 4000);
    } catch (err: any) {
      console.error('Download error:', err);
      setErrorMessage(err.message || 'Export rendering failed');
    } finally {
      setIsDownloading(false);
    }
  };

  const totalDuration = generatedScenes.length > 0
    ? generatedScenes.reduce((acc, s) => acc + s.duration, 0)
    : duration;

  return (
    <div className="flex-1 overflow-y-auto px-3 sm:px-6 py-4 pb-28 space-y-5 max-w-4xl mx-auto">
      {/* Feature Header Card */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#121624] via-[#0E121C] to-[#0A0D14] border border-amber-500/30 p-4 sm:p-5 shadow-xl">
        <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 text-black text-[11px] font-black uppercase tracking-wider shadow">
                Text to Video AI
              </span>
              <span className="text-[11px] text-amber-400/90 font-semibold flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" />
                Veo & Neural Synthesis
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Create AI Videos From Text Prompt
            </h2>
            <p className="text-xs text-gray-400 max-w-xl">
              Type any story or prompt in Bengali, Hindi, or English. Select 5s to 60s duration, choose your visual style, and generate an AI short video complete with voiceover, BGM, and synchronized subtitles.
            </p>
          </div>

          <button
            onClick={() => {
              triggerHaptic(10);
              const suggestions = MULTILINGUAL_PROMPT_SUGGESTIONS[language];
              const random = suggestions[Math.floor(Math.random() * suggestions.length)];
              setPrompt(random.prompt);
              if (random.style && ['cinematic', 'realistic', 'animation', 'devotional', 'story', 'social-media'].includes(random.style)) {
                setVideoStyle(random.style as TextVideoStyle);
              }
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#1A2234] hover:bg-[#232D45] text-amber-300 border border-amber-500/30 text-xs font-bold transition active:scale-95 whitespace-nowrap"
          >
            <span>🎲</span>
            <span>Surprise Me</span>
          </button>
        </div>
      </div>

      {/* Language Selector Chips */}
      <div className="space-y-2">
        <label className="text-xs font-bold text-gray-300 flex items-center gap-1.5 uppercase tracking-wider">
          <Globe className="w-3.5 h-3.5 text-amber-400" />
          <span>Prompt & Story Language</span>
        </label>
        <div className="grid grid-cols-3 gap-2">
          {(['English', 'Bengali', 'Hindi'] as const).map((lang) => {
            const labels = {
              English: 'English',
              Bengali: 'বাংলা (Bengali)',
              Hindi: 'हिन्दी (Hindi)',
            };
            const isSel = language === lang;
            return (
              <button
                key={lang}
                onClick={() => {
                  triggerHaptic();
                  setLanguage(lang);
                }}
                className={`px-3 py-2 rounded-xl text-xs font-bold transition border text-center ${
                  isSel
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500 shadow-md shadow-amber-500/10'
                    : 'bg-[#121624] text-gray-400 border-gray-800 hover:border-gray-700'
                }`}
              >
                {labels[lang]}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Text Prompt Input Box */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-gray-300 flex items-center gap-1.5 uppercase tracking-wider">
            <Film className="w-3.5 h-3.5 text-amber-400" />
            <span>Type Your Video Prompt or Story Concept</span>
          </label>
          <span className="text-[11px] text-gray-500">{prompt.length} chars</span>
        </div>

        <div className="relative">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={
              language === 'Bengali'
                ? 'এখানে আপনার ভিডিওর প্রম্পট বা গল্পের ধারণা লিখুন (যেমন: যমুনার তীরে বাঁশি বাজাচ্ছেন শ্রীকৃষ্ণ, গভীর অরণ্যে রয়েল বেঙ্গল টাইগার...)'
                : language === 'Hindi'
                ? 'यहाँ अपना वीडियो प्रॉम्ट या कहानी का विचार लिखें (जैसे: वृन्दावन में बांसुरी बजाते हुए श्री कृष्ण, हिमालय पर ध्यानमग्न साधु...)'
                : 'Describe any scene, character or story (e.g. A glowing neon tiger sprinting across a rain-slicked futuristic metropolis, 4k cinematic lighting...)'
            }
            rows={4}
            className="w-full bg-[#0E121C] border border-gray-800 focus:border-amber-500 rounded-xl p-3.5 text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-amber-500 transition resize-none leading-relaxed"
          />

          {/* AI Story Expander Button */}
          <div className="absolute right-2.5 bottom-3 flex items-center gap-2">
            <button
              onClick={handleExpandIdea}
              disabled={isExpanding || !prompt.trim()}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-orange-500 text-black font-extrabold text-xs shadow-md active:scale-95 transition disabled:opacity-50"
              title="Expand a 1-line concept into a rich cinematic storyboard"
            >
              <Wand2 className={`w-3.5 h-3.5 ${isExpanding ? 'animate-spin' : ''}`} />
              <span>{isExpanding ? 'Expanding...' : '✨ AI Story Expander'}</span>
            </button>
          </div>
        </div>

        {/* Quick Suggestion Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto py-1 scrollbar-none">
          <span className="text-[11px] text-gray-500 font-medium whitespace-nowrap">Examples:</span>
          {MULTILINGUAL_PROMPT_SUGGESTIONS[language].map((sug, i) => (
            <button
              key={i}
              onClick={() => {
                triggerHaptic();
                setPrompt(sug.prompt);
                if (sug.style && ['cinematic', 'realistic', 'animation', 'devotional', 'story', 'social-media'].includes(sug.style)) {
                  setVideoStyle(sug.style as TextVideoStyle);
                }
              }}
              className="px-2.5 py-1 rounded-lg bg-[#141A29] hover:bg-[#1C253B] text-[11px] text-gray-300 hover:text-amber-300 border border-gray-800 whitespace-nowrap transition active:scale-95"
            >
              {sug.title}
            </button>
          ))}
        </div>
      </div>

      {/* Video Duration Selector (5s, 10s, 20s, 30s, 40s, 50s, 60s) */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-gray-300 flex items-center gap-1.5 uppercase tracking-wider">
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span>Select Video Duration</span>
          </label>
          <span className="text-xs font-bold text-amber-400">
            {duration} seconds ({duration <= 6 ? '1 Scene' : duration <= 12 ? '2 Scenes' : `${Math.round(duration / 5)} Scenes`})
          </span>
        </div>

        <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
          {STANDARD_VIDEO_DURATIONS.map((dur) => {
            const isSel = duration === dur;
            return (
              <button
                key={dur}
                onClick={() => {
                  triggerHaptic();
                  setDuration(dur);
                }}
                className={`py-2.5 rounded-xl font-extrabold text-xs sm:text-sm transition flex flex-col items-center justify-center border ${
                  isSel
                    ? 'bg-gradient-to-b from-amber-500 to-orange-600 text-black border-amber-400 shadow-lg shadow-orange-500/20'
                    : 'bg-[#0E121C] text-gray-300 border-gray-800 hover:border-gray-700'
                }`}
              >
                <span>{dur}s</span>
                <span className={`text-[9px] ${isSel ? 'text-black/80 font-bold' : 'text-gray-500'}`}>
                  {dur <= 10 ? 'Quick' : dur >= 50 ? 'Full' : 'Standard'}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Video Styles (Cinematic, Realistic, Animation, Devotional, Story, Social-Media) */}
      <div className="space-y-2">
        <label className="text-xs font-bold text-gray-300 flex items-center gap-1.5 uppercase tracking-wider">
          <Palette className="w-3.5 h-3.5 text-amber-400" />
          <span>Select Video Style</span>
        </label>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          {TEXT_VIDEO_STYLES.map((st) => {
            const isSel = videoStyle === st.id;
            return (
              <button
                key={st.id}
                onClick={() => {
                  triggerHaptic();
                  setVideoStyle(st.id as TextVideoStyle);
                }}
                className={`p-3 rounded-xl border text-left transition relative overflow-hidden active:scale-95 ${
                  isSel
                    ? 'bg-[#182033] border-amber-500 shadow-md shadow-amber-500/15'
                    : 'bg-[#0E121C] border-gray-800 hover:border-gray-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xl">{st.icon}</span>
                  <span
                    className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${
                      isSel
                        ? 'bg-amber-500 text-black border-amber-400'
                        : 'bg-gray-800 text-gray-400 border-gray-700'
                    }`}
                  >
                    {st.badge}
                  </span>
                </div>
                <h4 className="text-xs font-bold text-white">{st.label}</h4>
                <p className="text-[10px] text-gray-400 line-clamp-2 mt-0.5">{st.desc}</p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Aspect Ratio & Resolution Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* Aspect Ratio */}
        <div className="space-y-2 bg-[#0E121C] border border-gray-800 rounded-xl p-3">
          <label className="text-xs font-bold text-gray-300 flex items-center gap-1.5 uppercase tracking-wider">
            <Smartphone className="w-3.5 h-3.5 text-amber-400" />
            <span>Format & Platform</span>
          </label>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                triggerHaptic();
                setAspectRatio('9:16');
              }}
              className={`p-2 rounded-lg border text-center transition ${
                aspectRatio === '9:16'
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500 font-bold'
                  : 'bg-[#141A29] text-gray-400 border-gray-800'
              }`}
            >
              <div className="text-xs font-bold">9:16 Vertical</div>
              <div className="text-[10px] text-gray-400">Shorts & Reels</div>
            </button>
            <button
              onClick={() => {
                triggerHaptic();
                setAspectRatio('16:9');
              }}
              className={`p-2 rounded-lg border text-center transition ${
                aspectRatio === '16:9'
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500 font-bold'
                  : 'bg-[#141A29] text-gray-400 border-gray-800'
              }`}
            >
              <div className="text-xs font-bold">16:9 Landscape</div>
              <div className="text-[10px] text-gray-400">YouTube & TV</div>
            </button>
          </div>
        </div>

        {/* Resolution */}
        <div className="space-y-2 bg-[#0E121C] border border-gray-800 rounded-xl p-3">
          <label className="text-xs font-bold text-gray-300 flex items-center gap-1.5 uppercase tracking-wider">
            <Tv className="w-3.5 h-3.5 text-amber-400" />
            <span>Output Resolution</span>
          </label>
          <div className="grid grid-cols-3 gap-1.5">
            {VIDEO_RESOLUTIONS_OPTIONS.map((res) => {
              const isSel = resolution === res.id;
              return (
                <button
                  key={res.id}
                  onClick={() => {
                    triggerHaptic();
                    setResolution(res.id as VideoResolution);
                  }}
                  className={`p-2 rounded-lg border text-center transition ${
                    isSel
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500 font-bold'
                      : 'bg-[#141A29] text-gray-400 border-gray-800'
                  }`}
                >
                  <div className="text-xs font-bold">{res.id.toUpperCase()}</div>
                  <div className="text-[9px] text-gray-500">
                    {res.id === '4k' ? 'Ultra' : res.id === '1080p' ? 'Full HD' : 'Fast'}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Audio, BGM & Subtitle Toggles */}
      <div className="bg-[#0E121C] border border-gray-800 rounded-xl p-3.5 space-y-3">
        <label className="text-xs font-bold text-gray-300 flex items-center gap-1.5 uppercase tracking-wider">
          <Sliders className="w-3.5 h-3.5 text-amber-400" />
          <span>Audio & Subtitle Settings</span>
        </label>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          {/* AI Voiceover */}
          <div className="bg-[#141A29] border border-gray-800/80 rounded-lg p-2.5 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Mic className="w-3.5 h-3.5 text-blue-400" />
                <span>AI Voiceover</span>
              </span>
              <input
                type="checkbox"
                checked={includeVoiceover}
                onChange={(e) => setIncludeVoiceover(e.target.checked)}
                className="accent-amber-500 w-4 h-4 cursor-pointer"
              />
            </div>
            {includeVoiceover && (
              <select
                value={voiceName}
                onChange={(e) => setVoiceName(e.target.value)}
                className="w-full bg-[#0A0D14] border border-gray-700 text-xs text-gray-200 rounded px-2 py-1 focus:outline-none"
              >
                <option value="Kore">Kore (Warm Storyteller)</option>
                <option value="Fenrir">Fenrir (Deep & Epic)</option>
                <option value="Puck">Puck (Energetic & Vivid)</option>
                <option value="Zephyr">Zephyr (Serene & Divine)</option>
              </select>
            )}
          </div>

          {/* Background Music */}
          <div className="bg-[#141A29] border border-gray-800/80 rounded-lg p-2.5 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Music className="w-3.5 h-3.5 text-amber-400" />
                <span>Royalty-Free BGM</span>
              </span>
              <input
                type="checkbox"
                checked={includeBgm}
                onChange={(e) => setIncludeBgm(e.target.checked)}
                className="accent-amber-500 w-4 h-4 cursor-pointer"
              />
            </div>
            {includeBgm && (
              <select
                value={bgmGenre}
                onChange={(e) => setBgmGenre(e.target.value as BgmGenre)}
                className="w-full bg-[#0A0D14] border border-gray-700 text-xs text-gray-200 rounded px-2 py-1 focus:outline-none"
              >
                {BGM_GENRES.filter((g) => g !== 'None').map((genre) => (
                  <option key={genre} value={genre}>
                    {genre}
                  </option>
                ))}
              </select>
            )}
          </div>

          {/* Subtitles */}
          <div className="bg-[#141A29] border border-gray-800/80 rounded-lg p-2.5 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Subtitles className="w-3.5 h-3.5 text-emerald-400" />
                <span>Auto Subtitles</span>
              </span>
              <input
                type="checkbox"
                checked={includeSubtitles}
                onChange={(e) => setIncludeSubtitles(e.target.checked)}
                className="accent-amber-500 w-4 h-4 cursor-pointer"
              />
            </div>
            {includeSubtitles && (
              <select
                value={subtitlePreset}
                onChange={(e) => setSubtitlePreset(e.target.value as SubtitlePreset)}
                className="w-full bg-[#0A0D14] border border-gray-700 text-xs text-gray-200 rounded px-2 py-1 focus:outline-none"
              >
                {SUBTITLE_PRESETS.map((sub) => (
                  <option key={sub.value} value={sub.value}>
                    {sub.label}
                  </option>
                ))}
              </select>
            )}
          </div>
        </div>
      </div>

      {/* Primary Generate Button */}
      <button
        onClick={handleGenerateVideo}
        disabled={isGenerating || !prompt.trim()}
        className="w-full py-3.5 sm:py-4 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-red-600 hover:from-amber-400 hover:via-orange-400 hover:to-red-500 text-black font-black text-sm sm:text-base tracking-wider uppercase shadow-xl shadow-orange-500/25 transition active:scale-[0.99] disabled:opacity-50 flex items-center justify-center gap-2"
      >
        <Sparkles className={`w-5 h-5 ${isGenerating ? 'animate-spin' : ''}`} />
        <span>{isGenerating ? 'Synthesizing AI Video...' : '🚀 Generate AI Video From Prompt'}</span>
      </button>

      {/* Progress & Loading Indicator */}
      {isGenerating && (
        <div className="bg-[#121624] border border-amber-500/40 rounded-xl p-4 space-y-3 animate-in fade-in duration-300">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-amber-300 flex items-center gap-1.5">
              <span className="animate-spin">🐅</span>
              <span>{progressStep}</span>
            </span>
            <span className="font-black text-amber-400">{progressPercent}%</span>
          </div>

          <div className="w-full bg-gray-800 h-2.5 rounded-full overflow-hidden">
            <div
              className="bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 h-full rounded-full transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          <p className="text-[11px] text-gray-400">{statusDetails}</p>
        </div>
      )}

      {/* Error Notice */}
      {errorMessage && (
        <div className="bg-red-950/40 border border-red-500/30 rounded-xl p-3 flex items-start gap-2 text-xs text-red-200">
          <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <div className="font-bold">Notice:</div>
            <div>{errorMessage}</div>
          </div>
        </div>
      )}

      {/* Video Preview & Controls Card */}
      {generatedScenes.length > 0 && (
        <div className="bg-[#0E121C] border border-amber-500/30 rounded-2xl p-4 sm:p-5 space-y-4 shadow-2xl">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">
                Video Preview Player
              </span>
              <h3 className="text-base font-black text-white truncate max-w-sm">
                {generatedTitle}
              </h3>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsMuted((prev) => !prev)}
                className="p-2 rounded-lg bg-gray-800 text-gray-300 hover:text-white transition"
                title={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Interactive Player Container */}
          <div className="relative mx-auto flex items-center justify-center bg-black rounded-xl overflow-hidden shadow-inner border border-gray-800">
            <canvas
              ref={previewCanvasRef}
              width={aspectRatio === '9:16' ? 720 : 1280}
              height={aspectRatio === '9:16' ? 1280 : 720}
              className={`max-h-[460px] object-contain rounded-lg ${
                aspectRatio === '9:16' ? 'aspect-[9/16]' : 'aspect-[16/9]'
              }`}
            />

            {/* Center Play Overlay when Paused */}
            {!isPlaying && (
              <button
                onClick={() => setIsPlaying(true)}
                className="absolute inset-0 m-auto w-16 h-16 rounded-full bg-amber-500/90 text-black flex items-center justify-center shadow-2xl hover:scale-105 active:scale-95 transition"
              >
                <Play className="w-7 h-7 fill-black ml-1" />
              </button>
            )}
          </div>

          {/* Player Progress Scrubber */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-[11px] font-mono text-gray-400">
              <span>{Math.floor(currentTime)}s</span>
              <span>{totalDuration}s</span>
            </div>
            <div className="w-full bg-gray-800 h-1.5 rounded-full overflow-hidden cursor-pointer">
              <div
                className="bg-amber-500 h-full transition-all duration-100"
                style={{ width: `${(currentTime / totalDuration) * 100}%` }}
              />
            </div>
          </div>

          {/* Playback Controls & Action Buttons */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
            <div className="flex items-center gap-2">
              {/* Play / Pause */}
              <button
                onClick={() => setIsPlaying((prev) => !prev)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-500 text-black font-extrabold text-xs shadow transition active:scale-95"
              >
                {isPlaying ? <Pause className="w-4 h-4 fill-black" /> : <Play className="w-4 h-4 fill-black" />}
                <span>{isPlaying ? 'Pause' : 'Play'}</span>
              </button>

              {/* Regenerate */}
              <button
                onClick={handleGenerateVideo}
                disabled={isGenerating}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#141A29] hover:bg-[#1C253B] text-gray-200 border border-gray-700 font-bold text-xs transition active:scale-95"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Regenerate</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              {/* Export / Download MP4 */}
              <button
                onClick={handleExportDownload}
                disabled={isDownloading}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs shadow-md active:scale-95 transition"
              >
                <Download className={`w-4 h-4 ${isDownloading ? 'animate-bounce' : ''}`} />
                <span>{isDownloading ? 'Exporting MP4...' : `Download ${resolution.toUpperCase()}`}</span>
              </button>

              {/* Edit in Studio Timeline */}
              <button
                onClick={() => {
                  triggerHaptic();
                  onSwitchToStudio();
                }}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs shadow-md active:scale-95 transition"
              >
                <ExternalLink className="w-4 h-4" />
                <span>Edit in Timeline</span>
              </button>
            </div>
          </div>

          {downloadSuccess && (
            <div className="bg-emerald-950/40 border border-emerald-500/30 rounded-xl p-2.5 text-xs text-emerald-300 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Video exported and saved to your device in {resolution.toUpperCase()}!</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
