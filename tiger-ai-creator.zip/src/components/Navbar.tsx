import React from 'react';
import {
  Sparkles,
  Download,
  Smartphone,
  PlusCircle,
  Package,
  CheckCircle2,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { safeVibrate } from '../utils/haptics';

interface NavbarProps {
  onOpenAutoCreator: () => void;
  onOpenApkModal: () => void;
  onNewProject: () => void;
  onExport: () => void;
  projectTitle: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenAutoCreator,
  onOpenApkModal,
  onNewProject,
  onExport,
  projectTitle,
}) => {
  const { isInstallable, isInstalled, install, isSamsungAndroid } = usePWAInstall();

  const handleVibrate = () => {
    safeVibrate(15);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#0A0D14]/90 backdrop-blur-md border-b border-amber-500/20 px-3 py-2.5 sm:px-6">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2">
        {/* Brand Logo & Title */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="relative flex-shrink-0 w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 via-orange-500 to-red-600 p-[1.5px] shadow-lg shadow-orange-500/20">
            <div className="w-full h-full bg-[#0E121C] rounded-[10px] flex items-center justify-center overflow-hidden">
              <span className="text-lg">🐅</span>
            </div>
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <h1 className="text-sm sm:text-base font-extrabold tracking-wider text-white uppercase truncate">
                TIGER <span className="bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">AI CREATOR</span>
              </h1>
              <span className="hidden md:inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold bg-amber-500/15 text-amber-300 border border-amber-500/30">
                Samsung Ready
              </span>
            </div>
            <p className="text-[11px] text-gray-400 truncate max-w-[160px] sm:max-w-[280px]">
              {projectTitle || 'com.tiger.aicreator'}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* 1-Tap Auto Create Video Button */}
          <button
            onClick={() => {
              handleVibrate();
              onOpenAutoCreator();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 sm:px-4 sm:py-2 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 text-black font-extrabold text-xs sm:text-sm shadow-md shadow-orange-500/25 active:scale-95 transition-transform"
          >
            <Sparkles className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-black animate-pulse" />
            <span className="hidden xs:inline">AUTO</span> CREATE
          </button>

          {/* New Project */}
          <button
            onClick={() => {
              handleVibrate();
              onNewProject();
            }}
            title="Create New Project"
            className="p-2 sm:px-3 sm:py-2 rounded-xl bg-[#151A26] border border-gray-700/60 text-gray-300 hover:text-white hover:bg-gray-800 text-xs font-semibold flex items-center gap-1.5 transition"
          >
            <PlusCircle className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">New</span>
          </button>

          {/* Android APK Spec / Packaging */}
          <button
            onClick={() => {
              handleVibrate();
              onOpenApkModal();
            }}
            title="Android APK Packaging (com.tiger.aicreator)"
            className="p-2 sm:px-3 sm:py-2 rounded-xl bg-[#151A26] border border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/10 text-xs font-semibold flex items-center gap-1.5 transition"
          >
            <Package className="w-4 h-4 text-emerald-400" />
            <span className="hidden md:inline">APK</span>
          </button>

          {/* PWA Install Button */}
          {isInstallable && (
            <button
              onClick={() => {
                handleVibrate();
                install();
              }}
              className="p-2 sm:px-3 sm:py-2 rounded-xl bg-blue-600/20 border border-blue-500/40 text-blue-300 hover:bg-blue-600/30 text-xs font-semibold flex items-center gap-1.5 transition animate-pulse"
              title="Install on Samsung / Android"
            >
              <Smartphone className="w-4 h-4 text-blue-400" />
              <span className="hidden sm:inline">Install</span>
            </button>
          )}

          {/* Export Video */}
          <button
            onClick={() => {
              handleVibrate();
              onExport();
            }}
            className="px-3 py-1.5 sm:px-4 sm:py-2 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-black font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow-md active:scale-95 transition"
          >
            <Download className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-black" />
            <span>Export</span>
          </button>
        </div>
      </div>
    </header>
  );
};
