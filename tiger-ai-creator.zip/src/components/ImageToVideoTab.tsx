import React, { useState, useRef, useEffect } from 'react';
import {
  Film,
  Upload,
  Play,
  Sliders,
  Sparkles,
  Camera,
  Download,
  PlusCircle,
  Eye,
  Activity,
  Smile,
  Zap,
  CheckCircle2,
} from 'lucide-react';
import { CameraMotion, Project, Scene } from '../types';
import { videoCompositor } from '../services/videoRenderer';
import { safeVibrate } from '../utils/haptics';

interface ImageToVideoTabProps {
  project: Project;
  onAddGeneratedClipToProject: (scene: Scene) => void;
}

type CharacterMovementType =
  | 'walking'
  | 'running'
  | 'dancing'
  | 'talking'
  | 'breathing';

interface MovementPreset {
  id: CharacterMovementType;
  label: string;
  icon: string;
  motion: CameraMotion;
  strength: number;
  desc: string;
  facialCue: string;
}

const CHARACTER_MOVEMENTS: MovementPreset[] = [
  {
    id: 'walking',
    label: 'Walking Movement',
    icon: '🚶',
    motion: 'pan-left',
    strength: 5,
    desc: 'Steady tracking shot following character forward gait and footfall cadence',
    facialCue: 'Determined forward gaze with natural head bob',
  },
  {
    id: 'running',
    label: 'Running Kinetic',
    icon: '🏃',
    motion: 'camera-shake',
    strength: 8,
    desc: 'High-speed kinetic pursuit with dynamic camera motion tremor',
    facialCue: 'Focused intensity, wind rush and micro head sway',
  },
  {
    id: 'dancing',
    label: 'Dancing Harmonic',
    icon: '💃',
    motion: 'cinematic-push',
    strength: 6,
    desc: 'Fluid rhythmic orbit with graceful camera sway matching music tempo',
    facialCue: 'Joyful expression, gentle smile, and expressive eye glints',
  },
  {
    id: 'talking',
    label: 'Talking & Facial Expression',
    icon: '🗣️',
    motion: 'zoom-in',
    strength: 4,
    desc: 'Close-up portrait with simulated mouth cadence, eye blinks & expressive nodding',
    facialCue: 'Active dialogue articulation, warm engaging eye contact',
  },
  {
    id: 'breathing',
    label: 'Subtle Portrait Idling',
    icon: '🧘',
    motion: 'slow-motion',
    strength: 3,
    desc: 'Meditative chest breathing expansion with soft light particle float',
    facialCue: 'Calm serene breath with gentle ambient head drifting',
  },
];

const CAMERA_PRESETS: {
  name: string;
  motion: CameraMotion;
  strength: number;
  duration: number;
  icon: string;
  desc: string;
}[] = [
  {
    name: 'Cinematic Push',
    motion: 'cinematic-push',
    strength: 8,
    duration: 5,
    icon: '🎬',
    desc: 'Hollywood anamorphic push-in with subtle Dutch tilt',
  },
  {
    name: 'Smooth Zoom In',
    motion: 'zoom-in',
    strength: 5,
    duration: 4,
    icon: '🔍',
    desc: 'Natural steady cam zoom into subject focus',
  },
  {
    name: 'Reveal Zoom Out',
    motion: 'zoom-out',
    strength: 5,
    duration: 6,
    icon: '📐',
    desc: 'Slow revealing pull-back for dramatic resonance',
  },
  {
    name: 'Pan Left / Right',
    motion: 'pan-left',
    strength: 6,
    duration: 5,
    icon: '↔️',
    desc: 'Horizontal tracking across scenic environment',
  },
  {
    name: 'Tilt Up Pedestal',
    motion: 'tilt-up',
    strength: 7,
    duration: 5,
    icon: '⬆️',
    desc: 'Majestic upward pedestal tilt revealing the subject',
  },
  {
    name: 'Action Impact Shake',
    motion: 'camera-shake',
    strength: 9,
    duration: 3,
    icon: '⚡',
    desc: 'High adrenaline pulse and kinetic vibration',
  },
];

export const ImageToVideoTab: React.FC<ImageToVideoTabProps> = ({
  project,
  onAddGeneratedClipToProject,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasPreviewRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number | null>(null);

  const [uploadedImage, setUploadedImage] = useState<string | null>(
    project.scenes[0]?.imageUrl || null
  );
  const [characterMovement, setCharacterMovement] = useState<CharacterMovementType>('talking');
  const [motion, setMotion] = useState<CameraMotion>('cinematic-push');
  const [motionStrength, setMotionStrength] = useState<number>(7);
  const [duration, setDuration] = useState<number>(5);
  const [promptNotes, setPromptNotes] = useState<string>('');
  const [dialogueText, setDialogueText] = useState<string>('Hello! Welcome to Tiger AI Creator.');
  const [isPreviewing, setIsPreviewing] = useState<boolean>(false);
  const [addedNotice, setAddedNotice] = useState<boolean>(false);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (ev) => {
      if (ev.target?.result) {
        setUploadedImage(ev.target.result as string);
        safeVibrate(15);
      }
    };
    reader.readAsDataURL(file);
  };

  const applyMovementPreset = (preset: MovementPreset) => {
    safeVibrate(10);
    setCharacterMovement(preset.id);
    setMotion(preset.motion);
    setMotionStrength(preset.strength);
    if (preset.id === 'talking' && !dialogueText) {
      setDialogueText('Experience the wonder of living AI animation.');
    }
  };

  const applyCameraPreset = (p: typeof CAMERA_PRESETS[0]) => {
    safeVibrate(10);
    setMotion(p.motion);
    setMotionStrength(p.strength);
    setDuration(p.duration);
  };

  // Live Canvas Animation Engine
  const startPreview = () => {
    if (!uploadedImage) return;
    setIsPreviewing(true);
    safeVibrate(15);

    const canvas = canvasPreviewRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const tempScene: Scene = {
      id: 'temp_preview',
      sceneNumber: 1,
      duration,
      narration: characterMovement === 'talking' ? dialogueText : (promptNotes || 'Animated visual scene'),
      visualPrompt: `${characterMovement} animation: ${promptNotes || 'Cinematic video clip'}`,
      imageUrl: uploadedImage,
      cameraMotion: motion,
      motionStrength,
      soundEffect: 'whoosh',
      subtitles: [],
    };

    videoCompositor.preloadImages([tempScene]).then(() => {
      const startTime = performance.now();
      const totalMs = duration * 1000;

      const loop = (now: number) => {
        const elapsed = now - startTime;
        if (elapsed >= totalMs) {
          setIsPreviewing(false);
          return;
        }

        // Render base video composite frame
        videoCompositor.renderFrame(ctx, canvas.width, canvas.height, {
          currentScene: tempScene,
          sceneElapsedMs: elapsed,
          sceneDurationMs: totalMs,
          overallElapsedMs: elapsed,
          totalDurationMs: totalMs,
          aspectRatio: project.aspectRatio,
          subtitlePreset: project.subtitlePreset,
          showWatermark: false,
        });

        // Overlay Character Movement Synthetics (talking mouth cadence / walking sway)
        if (characterMovement === 'talking') {
          // Subtle harmonic jaw & audio pulse
          const mouthWave = Math.sin(elapsed * 0.015) * 0.5 + 0.5;
          ctx.save();
          ctx.fillStyle = `rgba(255, 200, 100, ${0.08 * mouthWave})`;
          ctx.beginPath();
          ctx.arc(canvas.width / 2, canvas.height * 0.54, 25 * mouthWave + 10, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        } else if (characterMovement === 'walking') {
          // Subtle rhythmic stride bounce
          const stepBounce = Math.sin(elapsed * 0.008);
          ctx.save();
          ctx.fillStyle = 'rgba(255, 255, 255, 0.03)';
          ctx.fillRect(0, canvas.height - 60 + stepBounce * 4, canvas.width, 4);
          ctx.restore();
        }

        animationFrameRef.current = requestAnimationFrame(loop);
      };

      animationFrameRef.current = requestAnimationFrame(loop);
    });
  };

  useEffect(() => {
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, []);

  const handleAddToProject = () => {
    if (!uploadedImage) return;
    safeVibrate(20);

    const newScene: Scene = {
      id: `sc_clip_${Date.now()}`,
      sceneNumber: project.scenes.length + 1,
      duration,
      narration: characterMovement === 'talking' ? dialogueText : (promptNotes || 'Visual clip generated from image'),
      englishNarration: characterMovement === 'talking' ? dialogueText : (promptNotes || 'Visual clip generated from image'),
      visualPrompt: `${characterMovement} animation: ${promptNotes || motion} clip`,
      videoPrompt: `${motion} camera, ${characterMovement} movement, ultra-smooth 60fps`,
      imageUrl: uploadedImage,
      cameraMotion: motion,
      motionStrength,
      soundEffect: 'whoosh',
      subtitles: [],
    };

    onAddGeneratedClipToProject(newScene);
    setAddedNotice(true);
    setTimeout(() => setAddedNotice(false), 3000);
  };

  return (
    <div className="bg-[#0E121C] border border-gray-800 rounded-3xl p-4 sm:p-6 space-y-6 shadow-xl max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-gray-800 pb-4">
        <div className="flex items-center gap-2.5">
          <div className="p-2.5 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 text-black shadow-lg shadow-orange-500/20">
            <Film className="w-5 h-5 font-black" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base sm:text-lg font-bold text-white">Image To Video Studio</h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                Identity Preserved
              </span>
            </div>
            <p className="text-xs text-gray-400">
              Animate any image with walking, running, dancing, talking expressions, and Hollywood camera motion while preserving original character appearance.
            </p>
          </div>
        </div>
      </div>

      {/* 1. Character Movement Modes */}
      <div className="space-y-2">
        <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider flex items-center gap-1.5">
          <Activity className="w-3.5 h-3.5 text-amber-400" />
          <span>1. Select Character Movement & Facial Expression</span>
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
          {CHARACTER_MOVEMENTS.map((cm) => {
            const isSelected = characterMovement === cm.id;
            return (
              <button
                key={cm.id}
                type="button"
                onClick={() => applyMovementPreset(cm)}
                className={`p-3 rounded-2xl border text-left transition flex flex-col justify-between ${
                  isSelected
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-md'
                    : 'bg-[#141926] border-gray-800 text-gray-300 hover:border-gray-700'
                }`}
              >
                <div className="text-2xl mb-1">{cm.icon}</div>
                <div>
                  <h5 className="text-xs font-bold text-white">{cm.label}</h5>
                  <p className="text-[10px] text-gray-400 line-clamp-2 mt-0.5">{cm.desc}</p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Camera Motion Presets */}
      <div className="space-y-2">
        <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider flex items-center gap-1.5">
          <Camera className="w-3.5 h-3.5 text-amber-400" />
          <span>2. Cinematic Camera Movement</span>
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
          {CAMERA_PRESETS.map((p) => {
            const isSelected = motion === p.motion;
            return (
              <button
                key={p.name}
                type="button"
                onClick={() => applyCameraPreset(p)}
                className={`p-2.5 rounded-xl border text-left transition ${
                  isSelected
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-md'
                    : 'bg-[#141926] border-gray-800 text-gray-300 hover:border-gray-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-lg">{p.icon}</span>
                  <span className="text-[10px] font-mono text-amber-400">{p.duration}s</span>
                </div>
                <div className="mt-1">
                  <h5 className="text-xs font-bold text-white truncate">{p.name}</h5>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Preview Viewport & Controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 items-start">
        {/* Viewport Box */}
        <div className="space-y-2">
          <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider">
            Source Image & Real-Time Canvas Viewport
          </label>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            className="hidden"
          />

          <div className="relative aspect-[9/16] max-h-[420px] w-full rounded-2xl overflow-hidden bg-black border border-amber-500/30 flex items-center justify-center mx-auto shadow-2xl">
            {uploadedImage ? (
              <>
                <canvas
                  ref={canvasPreviewRef}
                  width={720}
                  height={1280}
                  className="w-full h-full object-contain"
                />
                {!isPreviewing && (
                  <img
                    src={uploadedImage}
                    alt="Preview"
                    className="absolute inset-0 w-full h-full object-contain pointer-events-none"
                  />
                )}

                <button
                  onClick={startPreview}
                  disabled={isPreviewing}
                  className="absolute inset-0 flex items-center justify-center bg-black/40 hover:bg-black/20 transition group"
                >
                  <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-amber-500 to-orange-500 text-black flex items-center justify-center shadow-lg group-hover:scale-110 active:scale-95 transition">
                    <Play className="w-6 h-6 fill-black ml-1" />
                  </div>
                </button>
              </>
            ) : (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="p-6 text-center cursor-pointer flex flex-col items-center justify-center gap-2"
              >
                <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <Upload className="w-6 h-6" />
                </div>
                <p className="text-xs font-bold text-white">Upload Image to Animate</p>
                <p className="text-[11px] text-gray-400">PNG, JPG, WebP supported</p>
              </div>
            )}
          </div>

          {uploadedImage && (
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-full py-2 rounded-xl bg-[#141926] border border-gray-800 hover:border-amber-500/50 text-xs font-semibold text-gray-300 transition"
            >
              Replace Source Image
            </button>
          )}
        </div>

        {/* Detailed Controls */}
        <div className="space-y-4 bg-[#121622] p-4 sm:p-5 rounded-2xl border border-gray-800">
          {/* Dialogue / Speech if talking mode */}
          {characterMovement === 'talking' && (
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-amber-400">
                Dialogue for Talking Character
              </label>
              <textarea
                rows={2}
                value={dialogueText}
                onChange={(e) => setDialogueText(e.target.value)}
                placeholder="Type the dialogue or speech the character is speaking..."
                className="w-full bg-[#0B0E16] border border-amber-500/40 rounded-xl p-2.5 text-xs text-white outline-none resize-none"
              />
            </div>
          )}

          {/* Camera Motion Trajectory */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-gray-300">
              Camera Movement Trajectory
            </label>
            <select
              value={motion}
              onChange={(e) => setMotion(e.target.value as CameraMotion)}
              className="w-full bg-[#0B0E16] border border-gray-700 focus:border-amber-500 rounded-xl p-2.5 text-xs text-white font-medium outline-none"
            >
              <option value="cinematic-push">🎬 Cinematic Push (Hollywood Curve)</option>
              <option value="zoom-in">🔍 Zoom In (Subject Focus)</option>
              <option value="zoom-out">🔍 Zoom Out (Reveal Atmosphere)</option>
              <option value="pan-left">⬅️ Pan Left (Landscape Horizon)</option>
              <option value="pan-right">➡️ Pan Right (Dynamic Sweep)</option>
              <option value="tilt-up">⬆️ Tilt Up (Majestic Elevation)</option>
              <option value="tilt-down">⬇️ Tilt Down (Grounding Descent)</option>
              <option value="slow-motion">⏳ Slow Motion (Meditative Drift)</option>
              <option value="camera-shake">⚡ Camera Shake (Action & Impact)</option>
            </select>
          </div>

          {/* Motion Strength */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-gray-300">Motion Amplitude</label>
              <span className="text-xs font-mono font-bold text-amber-400">{motionStrength}/10</span>
            </div>
            <input
              type="range"
              min={1}
              max={10}
              value={motionStrength}
              onChange={(e) => setMotionStrength(parseInt(e.target.value))}
              className="w-full h-2 bg-gray-800 accent-amber-500 rounded-lg cursor-pointer"
            />
          </div>

          {/* Duration */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-gray-300">Clip Duration</label>
              <span className="text-xs font-mono font-bold text-amber-400">{duration} seconds</span>
            </div>
            <div className="grid grid-cols-4 gap-2">
              {[3, 5, 7, 10].map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() => setDuration(d)}
                  className={`py-1.5 rounded-lg text-xs font-bold border transition ${
                    duration === d
                      ? 'bg-amber-500 text-black border-amber-400'
                      : 'bg-[#0B0E16] border-gray-700 text-gray-300'
                  }`}
                >
                  {d}s
                </button>
              ))}
            </div>
          </div>

          {/* Prompt Notes */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-gray-300">
              Motion Scene Notes (Optional)
            </label>
            <input
              type="text"
              value={promptNotes}
              onChange={(e) => setPromptNotes(e.target.value)}
              placeholder="e.g. Character runs across temple stairs during sunset..."
              className="w-full bg-[#0B0E16] border border-gray-700 focus:border-amber-500 rounded-xl p-2.5 text-xs text-white outline-none"
            />
          </div>

          {/* Notice */}
          {addedNotice && (
            <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>Animated clip added to Studio timeline!</span>
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center gap-2 pt-2">
            <button
              onClick={startPreview}
              disabled={!uploadedImage || isPreviewing}
              className="flex-1 py-3 rounded-xl bg-gray-800 hover:bg-gray-700 text-xs font-bold text-white flex items-center justify-center gap-1.5 transition active:scale-95 disabled:opacity-50"
            >
              <Eye className="w-4 h-4 text-amber-400" />
              <span>{isPreviewing ? 'Playing...' : 'Preview Animation'}</span>
            </button>

            <button
              onClick={handleAddToProject}
              disabled={!uploadedImage}
              className="flex-1 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-black font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition disabled:opacity-50"
            >
              <PlusCircle className="w-4 h-4 text-black" />
              <span>Add to Timeline</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
