import React, { useState, useRef, useEffect } from 'react';
import {
  UserCheck,
  Upload,
  Lock,
  Unlock,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Bookmark,
  Trash2,
  Layers,
  FolderHeart,
  Plus,
} from 'lucide-react';
import { CharacterReference, Project } from '../types';
import { analyzeImage } from '../services/geminiService';
import { safeVibrate } from '../utils/haptics';

interface CharacterConsistencyTabProps {
  project: Project;
  onUpdateCharacterReference: (charRef: CharacterReference | undefined) => void;
  onApplyToAllScenes: () => void;
}

const PRESET_CHARACTERS: Partial<CharacterReference>[] = [
  {
    id: 'preset_krishna',
    name: 'Shri Krishna',
    genderOrForm: 'Divine Youth',
    ageAppearance: 'Youthful 16-18 years',
    skinTone: 'Shyam / Luminous Sapphire Dark Blue',
    hairStyle: 'Soft silk dark curls adorned with radiant peacock feather (mor pankh)',
    facialHair: 'Clean shaven',
    clothing: 'Dazzling golden yellow silk Pitambari dhoti, gemstone sash, pearl necklaces',
    bodyProportions: 'Graceful, slender, divine Tribhanga stance',
    accessories: 'Golden bansuri flute, kaustubha gem garland, flower mala, mor-mukut',
    colorPalette: 'Deep sapphire blue, radiant saffron gold, emerald green',
    keyIdentifiers: 'Lotus-shaped compassionate eyes, peacock feather on crown, bansuri flute held in hands',
  },
  {
    id: 'preset_durga',
    name: 'Maa Durga',
    genderOrForm: 'Divine Warrior Goddess',
    ageAppearance: 'Eternal regal majesty',
    skinTone: 'Radiant glowing molten gold (Tapta-Kanchana)',
    hairStyle: 'Lustrous flowing midnight black hair crowned with ornate celestial mukut',
    facialHair: 'None',
    clothing: 'Rich crimson scarlet Banarasi silk sari with heavy gold zardozi borders',
    bodyProportions: 'Majestic, powerful, eight-armed divine form holding celestial weapons',
    accessories: 'Golden Trishul (trident), Sudarshana chakra, bow & arrow, conch shell, lotus',
    colorPalette: 'Crimson red, radiant sun gold, saffron',
    keyIdentifiers: 'Tri-netra (third eye of wisdom) on forehead, benevolent yet fierce gaze, riding royal lion/tiger',
  },
  {
    id: 'preset_tiger_hero',
    name: 'Sheru Sundarbans Guardian',
    genderOrForm: 'Mythic Anthropomorphic Tiger Warrior',
    ageAppearance: 'Prime athletic warrior',
    skinTone: 'Golden amber tiger fur with bold midnight black stripes and white underbelly',
    hairStyle: 'Flowing mane adorned with tribal beads and tiger claw talisman',
    facialHair: 'Bold tiger whiskers and majestic feline muzzle',
    clothing: 'Woven forest ranger vest, copper vambraces, earthen cargo pants',
    bodyProportions: 'Athletic, powerful muscular shoulders, agile posture',
    accessories: 'Bamboo bo-staff, compass pendant, leather bracers',
    colorPalette: 'Amber orange, forest green, warm earth brown, obsidian black',
    keyIdentifiers: 'Luminous piercing golden eyes, distinctive stripe pattern across brow, tiger tail',
  },
  {
    id: 'preset_cyber_ninja',
    name: 'Kage Cyberpunk Operative',
    genderOrForm: 'Futuristic Stealth Operative',
    ageAppearance: 'Late 20s agile specialist',
    skinTone: 'Pale with faint glowing circuit lines at temple',
    hairStyle: 'Undercut with silver-tipped spikes',
    facialHair: 'Stubble / Sleek lower carbon fiber respirator',
    clothing: 'Matte black nano-weave stealth suit with neon cyan optical fiber seams',
    bodyProportions: 'Lean athletic runner build, reinforced prosthetic forearm',
    accessories: 'Holographic ocular HUD visor, twin magnetic high-frequency vibro-blades',
    colorPalette: 'Matte obsidian black, electric neon cyan, carbon gray',
    keyIdentifiers: 'Single cyan glowing optic lens, high collar tactical trenchcoat, silent kinetic boots',
  },
];

const LOCAL_STORAGE_VAULT_KEY = 'tiger_ai_saved_characters_vault';

export const CharacterConsistencyTab: React.FC<CharacterConsistencyTabProps> = ({
  project,
  onUpdateCharacterReference,
  onApplyToAllScenes,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const char = project.characterReference;

  // Character Attributes
  const [name, setName] = useState<string>(char?.name || 'Main Subject');
  const [photo, setPhoto] = useState<string>(char?.imageBase64 || '');
  const [genderOrForm, setGenderOrForm] = useState<string>(char?.genderOrForm || 'Divine Youth');
  const [ageAppearance, setAgeAppearance] = useState<string>(char?.ageAppearance || 'Youthful 18-20 years');
  const [skinTone, setSkinTone] = useState<string>(char?.skinTone || 'Shyam / Luminous Dark Blue');
  const [hairStyle, setHairStyle] = useState<string>(char?.hairStyle || 'Silk dark curls with peacock feather');
  const [facialHair, setFacialHair] = useState<string>(char?.facialHair || 'Clean shaven');
  const [clothing, setClothing] = useState<string>(char?.clothing || 'Golden yellow silk Pitambari dhoti');
  const [bodyProportions, setBodyProportions] = useState<string>(char?.bodyProportions || 'Slender, athletic, graceful posture');
  const [accessories, setAccessories] = useState<string>(char?.accessories || 'Golden bansuri flute, pearl mala');
  const [colorPalette, setColorPalette] = useState<string>(char?.colorPalette || 'Sapphire blue, saffron gold');
  const [keyIdentifiers, setKeyIdentifiers] = useState<string>(
    char?.keyIdentifiers || 'Peacock feather crown, bansuri flute, compassionate divine gaze'
  );
  const [isLocked, setIsLocked] = useState<boolean>(char?.locked ?? true);

  // States
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);
  const [savedVault, setSavedVault] = useState<CharacterReference[]>([]);

  // Load saved characters from localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem(LOCAL_STORAGE_VAULT_KEY);
      if (stored) {
        setSavedVault(JSON.parse(stored));
      }
    } catch {}
  }, []);

  const saveVaultToLocalStorage = (list: CharacterReference[]) => {
    setSavedVault(list);
    try {
      localStorage.setItem(LOCAL_STORAGE_VAULT_KEY, JSON.stringify(list));
    } catch {}
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (ev) => {
      if (ev.target?.result) {
        const b64 = ev.target.result as string;
        setPhoto(b64);
        setIsAnalyzing(true);
        safeVibrate(15);
        try {
          const analysis = await analyzeImage(b64);
          if (analysis.character) {
            const c = analysis.character;
            if (c.genderOrForm) setGenderOrForm(c.genderOrForm);
            if (c.skinTone) setSkinTone(c.skinTone);
            if (c.hair) setHairStyle(c.hair);
            if (c.facialHair) setFacialHair(c.facialHair);
            if (c.clothingAndAttire) setClothing(c.clothingAndAttire);
            if (c.keyIdentifiers) setKeyIdentifiers(c.keyIdentifiers);
            setSuccessNotice('Character facial traits and attire extracted successfully!');
          }
        } catch (err) {
          console.warn('Auto character scan note:', err);
        } finally {
          setIsAnalyzing(false);
        }
      }
    };
    reader.readAsDataURL(file);
  };

  const handleApplyPreset = (preset: Partial<CharacterReference>) => {
    safeVibrate(15);
    if (preset.name) setName(preset.name);
    if (preset.genderOrForm) setGenderOrForm(preset.genderOrForm);
    if (preset.ageAppearance) setAgeAppearance(preset.ageAppearance);
    if (preset.skinTone) setSkinTone(preset.skinTone);
    if (preset.hairStyle) setHairStyle(preset.hairStyle);
    if (preset.facialHair) setFacialHair(preset.facialHair);
    if (preset.clothing) setClothing(preset.clothing);
    if (preset.bodyProportions) setBodyProportions(preset.bodyProportions);
    if (preset.accessories) setAccessories(preset.accessories);
    if (preset.colorPalette) setColorPalette(preset.colorPalette);
    if (preset.keyIdentifiers) setKeyIdentifiers(preset.keyIdentifiers);
    setSuccessNotice(`Loaded preset: ${preset.name}`);
    setTimeout(() => setSuccessNotice(null), 3000);
  };

  const handleSaveAndLock = () => {
    safeVibrate(20);
    const newChar: CharacterReference = {
      id: char?.id || `char_${Date.now()}`,
      name,
      imageBase64: photo,
      genderOrForm,
      ageAppearance,
      skinTone,
      hairStyle,
      facialHair,
      clothing,
      bodyProportions,
      accessories,
      colorPalette,
      keyIdentifiers,
      locked: isLocked,
    };
    onUpdateCharacterReference(newChar);
    setSuccessNotice('Character Identity Reference locked and applied across all scenes!');
    setTimeout(() => setSuccessNotice(null), 3500);
  };

  const handleSaveToVault = () => {
    safeVibrate(20);
    const newChar: CharacterReference = {
      id: `vault_char_${Date.now()}`,
      name: name || 'Custom Hero',
      imageBase64: photo,
      genderOrForm,
      ageAppearance,
      skinTone,
      hairStyle,
      facialHair,
      clothing,
      bodyProportions,
      accessories,
      colorPalette,
      keyIdentifiers,
      locked: true,
    };

    const updated = [newChar, ...savedVault.filter((c) => c.name !== newChar.name)];
    saveVaultToLocalStorage(updated);
    setSuccessNotice(`"${newChar.name}" saved to your Reusable Character Vault!`);
    setTimeout(() => setSuccessNotice(null), 3500);
  };

  const handleLoadFromVault = (vaultChar: CharacterReference) => {
    safeVibrate(15);
    setName(vaultChar.name);
    setPhoto(vaultChar.imageBase64);
    if (vaultChar.genderOrForm) setGenderOrForm(vaultChar.genderOrForm);
    if (vaultChar.ageAppearance) setAgeAppearance(vaultChar.ageAppearance);
    if (vaultChar.skinTone) setSkinTone(vaultChar.skinTone);
    if (vaultChar.hairStyle) setHairStyle(vaultChar.hairStyle);
    if (vaultChar.facialHair) setFacialHair(vaultChar.facialHair);
    if (vaultChar.clothing) setClothing(vaultChar.clothing);
    if (vaultChar.bodyProportions) setBodyProportions(vaultChar.bodyProportions);
    if (vaultChar.accessories) setAccessories(vaultChar.accessories);
    if (vaultChar.colorPalette) setColorPalette(vaultChar.colorPalette);
    if (vaultChar.keyIdentifiers) setKeyIdentifiers(vaultChar.keyIdentifiers);
    setIsLocked(true);

    onUpdateCharacterReference(vaultChar);
    setSuccessNotice(`Loaded character from vault: ${vaultChar.name}`);
    setTimeout(() => setSuccessNotice(null), 3000);
  };

  const handleDeleteFromVault = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    safeVibrate(10);
    const filtered = savedVault.filter((c) => c.id !== id);
    saveVaultToLocalStorage(filtered);
  };

  return (
    <div className="bg-[#0E121C] border border-gray-800 rounded-3xl p-4 sm:p-6 space-y-6 shadow-xl max-w-5xl mx-auto">
      {/* Title */}
      <div className="flex items-center justify-between border-b border-gray-800 pb-4">
        <div className="flex items-center gap-2.5">
          <div className="p-2.5 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 text-black shadow-lg shadow-orange-500/20">
            <UserCheck className="w-5 h-5 font-black" />
          </div>
          <div>
            <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
              Character Consistency Reference System
              <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 uppercase">
                Active
              </span>
            </h3>
            <p className="text-xs text-gray-400">
              Maintain Face, Hair, Clothes, Body Proportions, Colors, Accessories & Age Appearance consistently across all scenes.
            </p>
          </div>
        </div>

        {/* Lock toggle */}
        <button
          onClick={() => {
            safeVibrate(10);
            setIsLocked(!isLocked);
          }}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition ${
            isLocked
              ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300'
              : 'bg-gray-800 border-gray-700 text-gray-400'
          }`}
        >
          {isLocked ? <Lock className="w-3.5 h-3.5 text-emerald-400" /> : <Unlock className="w-3.5 h-3.5" />}
          <span>{isLocked ? 'Identity Locked' : 'Unlocked'}</span>
        </button>
      </div>

      {/* Preset Characters & Saved Vault Quick Bar */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-gray-300 uppercase tracking-wider flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Curated Character Presets</span>
          </label>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {PRESET_CHARACTERS.map((preset) => (
            <button
              key={preset.id}
              type="button"
              onClick={() => handleApplyPreset(preset)}
              className="p-2.5 rounded-xl bg-[#141926] border border-gray-800 hover:border-amber-500/50 text-left transition flex items-center gap-2"
            >
              <div className="w-8 h-8 rounded-lg bg-amber-500/15 text-amber-400 font-bold flex items-center justify-center flex-shrink-0 text-sm">
                {preset.name?.charAt(0)}
              </div>
              <div className="min-w-0">
                <div className="text-xs font-bold text-white truncate">{preset.name}</div>
                <div className="text-[10px] text-gray-400 truncate">{preset.genderOrForm}</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Reusable Character Vault (User Saved) */}
      {savedVault.length > 0 && (
        <div className="space-y-2">
          <label className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
            <FolderHeart className="w-3.5 h-3.5 text-amber-400" />
            <span>Your Saved Reusable Characters Vault ({savedVault.length})</span>
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {savedVault.map((sc) => (
              <div
                key={sc.id}
                onClick={() => handleLoadFromVault(sc)}
                className="p-2.5 rounded-xl bg-[#141926] border border-amber-500/30 hover:border-amber-400 cursor-pointer flex items-center justify-between gap-2 group transition"
              >
                <div className="flex items-center gap-2 min-w-0">
                  {sc.imageBase64 ? (
                    <img src={sc.imageBase64} alt={sc.name} className="w-8 h-8 rounded-lg object-cover flex-shrink-0" />
                  ) : (
                    <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-300 font-bold flex items-center justify-center flex-shrink-0 text-xs">
                      {sc.name.charAt(0)}
                    </div>
                  )}
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-white truncate">{sc.name}</div>
                    <div className="text-[10px] text-emerald-400 truncate">Reusable</div>
                  </div>
                </div>
                <button
                  type="button"
                  title="Remove from vault"
                  onClick={(e) => handleDeleteFromVault(sc.id, e)}
                  className="p-1 rounded-md text-gray-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Main Reference Photo & Extraction Form */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Photo Box */}
        <div className="space-y-2">
          <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider">
            Visual Face Reference Photo
          </label>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handlePhotoUpload}
            className="hidden"
          />
          <div
            onClick={() => fileInputRef.current?.click()}
            className="aspect-[3/4] w-full rounded-2xl bg-[#141926] border-2 border-dashed border-amber-500/40 hover:border-amber-400 flex flex-col items-center justify-center cursor-pointer transition overflow-hidden relative group shadow-inner"
          >
            {photo ? (
              <>
                <img src={photo} alt="Character" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition">
                  <span className="text-xs font-bold text-white bg-black/70 px-3 py-1.5 rounded-xl border border-white/20">
                    Change Photo Reference
                  </span>
                </div>
              </>
            ) : (
              <div className="p-4 text-center space-y-2">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/15 text-amber-400 flex items-center justify-center mx-auto">
                  <Upload className="w-6 h-6" />
                </div>
                <p className="text-xs font-bold text-gray-200">Upload Character Image</p>
                <p className="text-[11px] text-gray-400">
                  AI scans facial contours & anchors identity
                </p>
              </div>
            )}

            {isAnalyzing && (
              <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center gap-2">
                <RefreshCw className="w-6 h-6 text-amber-400 animate-spin" />
                <span className="text-xs text-amber-300 font-bold">Scanning facial traits...</span>
              </div>
            )}
          </div>
        </div>

        {/* Form Fields for 7 Core Consistency Pillars */}
        <div className="md:col-span-2 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Character Name */}
            <div className="space-y-1">
              <label className="block text-xs font-bold text-gray-300">1. Character / Subject Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Lord Krishna, Priya, Sheru, Cyber Ninja"
                className="w-full bg-[#151A26] border border-gray-700 focus:border-amber-500 rounded-xl p-2.5 text-xs sm:text-sm text-white outline-none font-medium"
              />
            </div>

            {/* Age Appearance */}
            <div className="space-y-1">
              <label className="block text-xs font-bold text-gray-300">2. Age Appearance</label>
              <input
                type="text"
                value={ageAppearance}
                onChange={(e) => setAgeAppearance(e.target.value)}
                placeholder="e.g. Youthful 18-20, Mid-30s Prime, Wise Elder 60+"
                className="w-full bg-[#151A26] border border-gray-700 focus:border-amber-500 rounded-xl p-2.5 text-xs sm:text-sm text-white outline-none font-medium"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Skin Tone */}
            <div className="space-y-1">
              <label className="block text-xs font-bold text-gray-300">3. Face & Skin Tone</label>
              <input
                type="text"
                value={skinTone}
                onChange={(e) => setSkinTone(e.target.value)}
                placeholder="e.g. Shyam / Dark Blue, Golden wheatish, Fair"
                className="w-full bg-[#151A26] border border-gray-700 focus:border-amber-500 rounded-xl p-2.5 text-xs sm:text-sm text-white outline-none font-medium"
              />
            </div>

            {/* Hair Style */}
            <div className="space-y-1">
              <label className="block text-xs font-bold text-gray-300">4. Hair Style & Headgear</label>
              <input
                type="text"
                value={hairStyle}
                onChange={(e) => setHairStyle(e.target.value)}
                placeholder="e.g. Long dark curls with peacock feather, silver braid"
                className="w-full bg-[#151A26] border border-gray-700 focus:border-amber-500 rounded-xl p-2.5 text-xs sm:text-sm text-white outline-none font-medium"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Clothes */}
            <div className="space-y-1">
              <label className="block text-xs font-bold text-gray-300">5. Clothes & Attire</label>
              <input
                type="text"
                value={clothing}
                onChange={(e) => setClothing(e.target.value)}
                placeholder="e.g. Yellow silk Pitambari dhoti, tactical vest, Banarasi sari"
                className="w-full bg-[#151A26] border border-gray-700 focus:border-amber-500 rounded-xl p-2.5 text-xs sm:text-sm text-white outline-none font-medium"
              />
            </div>

            {/* Body Proportions */}
            <div className="space-y-1">
              <label className="block text-xs font-bold text-gray-300">6. Body Proportions</label>
              <input
                type="text"
                value={bodyProportions}
                onChange={(e) => setBodyProportions(e.target.value)}
                placeholder="e.g. Athletic, Slender, Powerful muscular, Chibi mascot"
                className="w-full bg-[#151A26] border border-gray-700 focus:border-amber-500 rounded-xl p-2.5 text-xs sm:text-sm text-white outline-none font-medium"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Accessories & Props */}
            <div className="space-y-1">
              <label className="block text-xs font-bold text-gray-300">7. Accessories & Props</label>
              <input
                type="text"
                value={accessories}
                onChange={(e) => setAccessories(e.target.value)}
                placeholder="e.g. Golden bansuri, trishul, cyber katana, flower garland"
                className="w-full bg-[#151A26] border border-gray-700 focus:border-amber-500 rounded-xl p-2.5 text-xs sm:text-sm text-white outline-none font-medium"
              />
            </div>

            {/* Color Palette */}
            <div className="space-y-1">
              <label className="block text-xs font-bold text-gray-300">8. Signature Color Palette</label>
              <input
                type="text"
                value={colorPalette}
                onChange={(e) => setColorPalette(e.target.value)}
                placeholder="e.g. Saffron and Royal Blue, Crimson and Gold"
                className="w-full bg-[#151A26] border border-gray-700 focus:border-amber-500 rounded-xl p-2.5 text-xs sm:text-sm text-white outline-none font-medium"
              />
            </div>
          </div>

          {/* Key Identifiers to Anchor */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-gray-300">
              Key Anchor Prompt (Appended into every AI Scene Prompt)
            </label>
            <textarea
              rows={2}
              value={keyIdentifiers}
              onChange={(e) => setKeyIdentifiers(e.target.value)}
              placeholder="e.g. Same facial symmetry, distinctive eyes, peacock feather, flute, golden armlets..."
              className="w-full bg-[#151A26] border border-gray-700 focus:border-amber-500 rounded-xl p-2.5 text-xs sm:text-sm text-white outline-none resize-none font-medium"
            />
          </div>
        </div>
      </div>

      {/* Success Notice */}
      {successNotice && (
        <div className="flex items-center gap-2 p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span>{successNotice}</span>
        </div>
      )}

      {/* Action Footer */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-gray-800">
        <div className="flex items-center gap-2 text-xs text-gray-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Locks face, clothes & traits across all scenes in this project</span>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          {/* Save to Vault */}
          <button
            type="button"
            onClick={handleSaveToVault}
            className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-[#141926] border border-amber-500/40 hover:bg-amber-500/10 text-amber-300 font-bold text-xs flex items-center justify-center gap-1.5 transition"
          >
            <Bookmark className="w-4 h-4 text-amber-400" />
            <span>Save to Vault</span>
          </button>

          {/* Save & Lock to Project */}
          <button
            type="button"
            onClick={handleSaveAndLock}
            className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-black font-extrabold text-xs sm:text-sm shadow-md active:scale-95 transition"
          >
            Lock Character Identity
          </button>
        </div>
      </div>
    </div>
  );
};
