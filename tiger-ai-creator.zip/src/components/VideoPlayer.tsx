import React, { useEffect, useRef, useState } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Maximize2,
  Minimize2,
  Sparkles,
} from 'lucide-react';
import { Project, Scene } from '../types';
import { videoCompositor } from '../services/videoRenderer';
import { audioEngine } from '../services/audioEngine';
import { safeVibrate } from '../utils/haptics';

interface VideoPlayerProps {
  project: Project;
  currentSceneIndex: number;
  onSceneChange: (index: number) => void;
  onAspectRatioChange: (ar: any) => void;
}

export const VideoPlayer: React.FC<VideoPlayerProps> = ({
  project,
  currentSceneIndex,
  onSceneChange,
  onAspectRatioChange,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [elapsedMs, setElapsedMs] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  const totalDurationMs = project.scenes.reduce((acc, s) => acc + s.duration * 1000, 0);

  // Animation frame loop refs
  const animFrameIdRef = useRef<number | null>(null);
  const lastTimestampRef = useRef<number>(0);
  const activeSceneIdxRef = useRef<number>(currentSceneIndex);
  activeSceneIdxRef.current = currentSceneIndex;

  // Preload images into video compositor on project change
  useEffect(() => {
    videoCompositor.preloadImages(project.scenes);
  }, [project.scenes]);

  // Synchronize playing state with Audio Engine
  useEffect(() => {
    if (isPlaying) {
      audioEngine.init();
      audioEngine.setBgmVolume(isMuted ? 0 : project.bgmVolume);
      audioEngine.setVoiceVolume(isMuted ? 0 : project.voiceVolume);
      audioEngine.startBGM(project.bgmGenre);

      // Play current scene voice & sfx
      const scene = project.scenes[currentSceneIndex];
      if (scene) {
        audioEngine.playTTS(scene.narration, project.language, scene.audioBase64);
        audioEngine.playSFX(scene.soundEffect);
      }
    } else {
      audioEngine.stopBGM();
      audioEngine.stopTTS();
    }

    return () => {
      audioEngine.stopBGM();
      audioEngine.stopTTS();
    };
  }, [isPlaying, currentSceneIndex]);

  // Mute toggle
  useEffect(() => {
    audioEngine.setBgmVolume(isMuted ? 0 : project.bgmVolume);
    audioEngine.setVoiceVolume(isMuted ? 0 : project.voiceVolume);
  }, [isMuted, project.bgmVolume, project.voiceVolume]);

  // Compute scene at time
  const getSceneInfoAtTime = (timeMs: number) => {
    let accumulated = 0;
    for (let i = 0; i < project.scenes.length; i++) {
      const s = project.scenes[i];
      const durationMs = s.duration * 1000;
      if (timeMs >= accumulated && timeMs < accumulated + durationMs) {
        return {
          scene: s,
          sceneIndex: i,
          sceneElapsedMs: timeMs - accumulated,
          sceneDurationMs: durationMs,
        };
      }
      accumulated += durationMs;
    }
    const lastIdx = Math.max(0, project.scenes.length - 1);
    const lastScene = project.scenes[lastIdx];
    return {
      scene: lastScene,
      sceneIndex: lastIdx,
      sceneElapsedMs: lastScene ? lastScene.duration * 1000 : 0,
      sceneDurationMs: lastScene ? lastScene.duration * 1000 : 1,
    };
  };

  // Main Canvas Render Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let localElapsed = elapsedMs;

    const loop = (timestamp: number) => {
      if (!lastTimestampRef.current) lastTimestampRef.current = timestamp;
      const delta = timestamp - lastTimestampRef.current;
      lastTimestampRef.current = timestamp;

      if (isPlaying) {
        localElapsed += delta;
        if (localElapsed >= totalDurationMs) {
          localElapsed = 0;
          setIsPlaying(false);
          setElapsedMs(0);
          onSceneChange(0);
          return;
        }
        setElapsedMs(localElapsed);

        // Check if scene changed
        const info = getSceneInfoAtTime(localElapsed);
        if (info.sceneIndex !== activeSceneIdxRef.current) {
          onSceneChange(info.sceneIndex);
        }
      }

      const info = getSceneInfoAtTime(localElapsed);
      if (info.scene) {
        videoCompositor.renderFrame(ctx, canvas.width, canvas.height, {
          currentScene: info.scene,
          sceneElapsedMs: info.sceneElapsedMs,
          sceneDurationMs: info.sceneDurationMs,
          overallElapsedMs: localElapsed,
          totalDurationMs,
          aspectRatio: project.aspectRatio,
          subtitlePreset: project.subtitlePreset,
          showWatermark: false, // Default watermark-free!
        });
      }

      animFrameIdRef.current = requestAnimationFrame(loop);
    };

    animFrameIdRef.current = requestAnimationFrame(loop);

    return () => {
      if (animFrameIdRef.current) cancelAnimationFrame(animFrameIdRef.current);
    };
  }, [isPlaying, totalDurationMs, project.aspectRatio, project.subtitlePreset, project.scenes]);

  const togglePlay = () => {
    safeVibrate(12);
    setIsPlaying(!isPlaying);
  };

  const handleRestart = () => {
    safeVibrate(12);
    setElapsedMs(0);
    onSceneChange(0);
    if (!isPlaying) setIsPlaying(true);
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const seekTime = parseFloat(e.target.value);
    setElapsedMs(seekTime);
    const info = getSceneInfoAtTime(seekTime);
    onSceneChange(info.sceneIndex);
  };

  const formatTime = (ms: number) => {
    const totalSec = Math.floor(ms / 1000);
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Determine Aspect Ratio Dimensions for container
  const getAspectRatioClasses = () => {
    switch (project.aspectRatio) {
      case '9:16':
        return 'aspect-[9/16] max-h-[64vh] sm:max-h-[72vh]';
      case '16:9':
        return 'aspect-[16/9] w-full max-h-[50vh]';
      case '1:1':
        return 'aspect-[1/1] max-h-[55vh]';
      case '4:5':
        return 'aspect-[4/5] max-h-[62vh]';
      default:
        return 'aspect-[9/16] max-h-[64vh]';
    }
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  return (
    <div
      ref={containerRef}
      className="flex flex-col items-center justify-center bg-[#07090E] p-2 sm:p-4 rounded-3xl border border-gray-800/80 shadow-2xl relative select-none"
    >
      {/* Aspect Ratio & Format Quick Badges */}
      <div className="w-full flex items-center justify-between px-2 py-1.5 mb-2 text-xs">
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="font-semibold text-gray-300 truncate max-w-[180px] sm:max-w-xs">
            {project.title}
          </span>
        </div>

        {/* Aspect Ratio Switcher Pills */}
        <div className="flex items-center gap-1 bg-[#121622] p-1 rounded-xl border border-gray-800">
          {(['9:16', '16:9', '1:1', '4:5'] as const).map((ar) => (
            <button
              key={ar}
              onClick={() => onAspectRatioChange(ar)}
              className={`px-2 py-0.5 rounded-lg text-[11px] font-bold transition ${
                project.aspectRatio === ar
                  ? 'bg-amber-500 text-black shadow-sm'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              {ar}
            </button>
          ))}
        </div>
      </div>

      {/* Video Viewport Frame with Touch Interaction */}
      <div
        onClick={togglePlay}
        className={`relative ${getAspectRatioClasses()} w-auto rounded-2xl overflow-hidden shadow-2xl border border-amber-500/30 bg-black cursor-pointer group flex items-center justify-center`}
      >
        <canvas
          ref={canvasRef}
          width={project.aspectRatio === '9:16' ? 720 : project.aspectRatio === '16:9' ? 1280 : 800}
          height={project.aspectRatio === '9:16' ? 1280 : project.aspectRatio === '16:9' ? 720 : 800}
          className="w-full h-full object-contain pointer-events-none"
        />

        {/* Ambient Overlay when paused */}
        {!isPlaying && (
          <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] flex items-center justify-center transition">
            <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-gradient-to-tr from-amber-500 to-orange-500 text-black flex items-center justify-center shadow-xl shadow-orange-500/40 transform group-hover:scale-110 transition active:scale-95">
              <Play className="w-7 h-7 fill-black ml-1" />
            </div>
          </div>
        )}

        {/* Scene Badge Indicator */}
        <div className="absolute top-3 left-3 px-2.5 py-1 rounded-lg bg-black/60 backdrop-blur-md border border-white/10 text-[11px] font-bold text-amber-300 flex items-center gap-1.5 shadow">
          <Sparkles className="w-3 h-3 text-amber-400" />
          <span>Scene {currentSceneIndex + 1}/{project.scenes.length}</span>
        </div>

        {/* Motion Type Tag */}
        {project.scenes[currentSceneIndex] && (
          <div className="absolute top-3 right-3 px-2 py-0.5 rounded-lg bg-black/60 backdrop-blur-md border border-white/10 text-[10px] font-semibold text-gray-300 capitalize">
            {project.scenes[currentSceneIndex].cameraMotion}
          </div>
        )}
      </div>

      {/* Player Controls Bar */}
      <div className="w-full max-w-lg mt-3 px-2 sm:px-4 space-y-2">
        {/* Timeline Scrub Bar */}
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono font-medium text-amber-400 min-w-[36px]">
            {formatTime(elapsedMs)}
          </span>
          <input
            type="range"
            min={0}
            max={totalDurationMs}
            value={elapsedMs}
            onChange={handleSeek}
            className="flex-1 h-1.5 bg-gray-800 accent-amber-500 rounded-lg cursor-pointer transition"
          />
          <span className="text-[11px] font-mono font-medium text-gray-400 min-w-[36px] text-right">
            {formatTime(totalDurationMs)}
          </span>
        </div>

        {/* Playback Buttons */}
        <div className="flex items-center justify-between pt-1">
          <div className="flex items-center gap-2">
            {/* Play / Pause */}
            <button
              onClick={togglePlay}
              className="w-10 h-10 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-95 text-black flex items-center justify-center font-bold shadow-md transition"
            >
              {isPlaying ? (
                <Pause className="w-5 h-5 fill-black" />
              ) : (
                <Play className="w-5 h-5 fill-black ml-0.5" />
              )}
            </button>

            {/* Restart */}
            <button
              onClick={handleRestart}
              className="p-2 rounded-xl bg-[#151A26] border border-gray-800 text-gray-300 hover:text-white hover:bg-gray-800 transition"
              title="Restart from beginning"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            {/* Mute / Unmute */}
            <button
              onClick={() => setIsMuted(!isMuted)}
              className="p-2 rounded-xl bg-[#151A26] border border-gray-800 text-gray-300 hover:text-white hover:bg-gray-800 transition"
              title={isMuted ? 'Unmute' : 'Mute'}
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-amber-400" />}
            </button>
          </div>

          <div className="flex items-center gap-2">
            {/* Subtitle style badge */}
            <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-1 rounded-md bg-amber-500/10 text-amber-300 border border-amber-500/20">
              {project.subtitlePreset}
            </span>

            {/* Fullscreen Toggle */}
            <button
              onClick={toggleFullscreen}
              className="p-2 rounded-xl bg-[#151A26] border border-gray-800 text-gray-300 hover:text-white hover:bg-gray-800 transition"
              title="Toggle Fullscreen"
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
