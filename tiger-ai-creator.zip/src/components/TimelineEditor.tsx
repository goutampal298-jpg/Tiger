import React, { useState, useRef } from 'react';
import {
  Camera,
  Clock,
  Sparkles,
  Volume2,
  Trash2,
  Plus,
  Copy,
  Edit3,
  Sliders,
  Image as ImageIcon,
  Check,
  ShieldCheck,
  Layers,
  CheckSquare,
  Square,
  AlertCircle,
  Play,
  X,
  Loader2,
  Wand2,
  Film,
  Mic,
  ChevronDown,
} from 'lucide-react';
import { CameraMotion, Project, Scene, SoundEffectType, VisualStyle } from '../types';
import {
  createProceduralSceneCanvas,
  generateImage,
  generateTTS,
  batchFillSceneScripts,
} from '../services/geminiService';
import { safeVibrate } from '../utils/haptics';

export interface TimelineEditorProps {
  project: Project;
  activeSceneIndex: number;
  onSelectScene: (index: number) => void;
  onUpdateScene: (sceneIndex: number, updatedScene: Partial<Scene>) => void;
  onAddScene: () => void;
  onDeleteScene: (index: number) => void;
  onDuplicateScene: (index: number) => void;
  onBatchUpdateScenes?: (updates: { index: number; scene: Partial<Scene> }[]) => void;
  onAddMultipleScenes?: (count: number) => void;
}

const CAMERA_MOTIONS: { value: CameraMotion; label: string; icon: string }[] = [
  { value: 'zoom-in', label: 'Zoom In', icon: '🔍+' },
  { value: 'zoom-out', label: 'Zoom Out', icon: '🔍-' },
  { value: 'pan-left', label: 'Pan Left', icon: '⬅️' },
  { value: 'pan-right', label: 'Pan Right', icon: '➡️' },
  { value: 'tilt-up', label: 'Tilt Up', icon: '⬆️' },
  { value: 'tilt-down', label: 'Tilt Down', icon: '⬇️' },
  { value: 'cinematic-push', label: 'Cinematic Push', icon: '🎬' },
  { value: 'slow-motion', label: 'Slow Motion', icon: '⏳' },
  { value: 'camera-shake', label: 'Action Shake', icon: '⚡' },
];

const SFX_OPTIONS: { value: SoundEffectType; label: string; emoji: string }[] = [
  { value: 'temple_bell', label: 'Temple Bell', emoji: '🔔' },
  { value: 'divine_chime', label: 'Divine Chime', emoji: '✨' },
  { value: 'cinematic_hit', label: 'Cinematic Hit', emoji: '💥' },
  { value: 'whoosh', label: 'Whoosh', emoji: '💨' },
  { value: 'thunder', label: 'Thunder', emoji: '⚡' },
  { value: 'heartbeat', label: 'Heartbeat', emoji: '💓' },
  { value: 'magic_sparkle', label: 'Magic Twinkle', emoji: '🌟' },
  { value: 'nature_wind', label: 'Nature Breeze', emoji: '🍃' },
  { value: 'none', label: 'None', emoji: '🔇' },
];

const TTS_VOICES = ['Kore', 'Fenrir', 'Puck', 'Charon', 'Zephyr'];

// Helper to identify if a scene is empty or has only placeholder data
export function isSceneEmpty(scene: Scene): boolean {
  if (!scene.imageUrl || scene.imageUrl.trim() === '') return true;
  return false;
}

export function isSceneIncomplete(scene: Scene): boolean {
  const hasNoImage = !scene.imageUrl || scene.imageUrl.trim() === '';
  const hasPlaceholderPrompt =
    !scene.visualPrompt ||
    scene.visualPrompt.trim() === '' ||
    /^Scene\s+\d+(\s+visual|\s+cinematic composition)?$/i.test(scene.visualPrompt.trim());
  const hasPlaceholderNarration =
    !scene.narration ||
    scene.narration.trim() === '' ||
    /^Scene\s+\d+\s+continuation/i.test(scene.narration.trim());
  const hasNoAudio = !scene.audioBase64;

  return hasNoImage || hasPlaceholderPrompt || hasPlaceholderNarration || hasNoAudio;
}

export const TimelineEditor: React.FC<TimelineEditorProps> = ({
  project,
  activeSceneIndex,
  onSelectScene,
  onUpdateScene,
  onAddScene,
  onDeleteScene,
  onDuplicateScene,
  onBatchUpdateScenes,
  onAddMultipleScenes,
}) => {
  const currentScene = project.scenes[activeSceneIndex];
  const [isRegenerating, setIsRegenerating] = useState<boolean>(false);
  const [editPrompt, setEditPrompt] = useState<string>('');

  // Batch Selection State
  const [selectedSceneIndices, setSelectedSceneIndices] = useState<number[]>([]);
  const [showAddMenu, setShowAddMenu] = useState<boolean>(false);

  // Batch Generation Modal State
  const [isBatchModalOpen, setIsBatchModalOpen] = useState<boolean>(false);
  const [isBatchGenerating, setIsBatchGenerating] = useState<boolean>(false);
  const [batchProgress, setBatchProgress] = useState<{
    current: number;
    total: number;
    stepText: string;
    sceneStatuses: Record<number, 'pending' | 'generating' | 'done' | 'error'>;
  }>({
    current: 0,
    total: 0,
    stepText: '',
    sceneStatuses: {},
  });

  // Batch Options
  const [generateVisuals, setGenerateVisuals] = useState<boolean>(true);
  const [generateVoiceover, setGenerateVoiceover] = useState<boolean>(true);
  const [generateContinuityScript, setGenerateContinuityScript] = useState<boolean>(true);
  const [applySmartCamera, setApplySmartCamera] = useState<boolean>(true);
  const [themeGuidance, setThemeGuidance] = useState<string>('');
  const [selectedVoice, setSelectedVoice] = useState<string>(project.ttsVoice || 'Kore');

  const abortBatchRef = useRef<boolean>(false);

  // Identify empty and incomplete scenes
  const emptySceneIndices = project.scenes
    .map((s, idx) => (isSceneEmpty(s) ? idx : -1))
    .filter((idx) => idx !== -1);

  const incompleteSceneIndices = project.scenes
    .map((s, idx) => (isSceneIncomplete(s) ? idx : -1))
    .filter((idx) => idx !== -1);

  // Toggle selection for a scene
  const toggleSelectScene = (index: number) => {
    safeVibrate(10);
    setSelectedSceneIndices((prev) =>
      prev.includes(index) ? prev.filter((i) => i !== index) : [...prev, index]
    );
  };

  // Select all empty scenes
  const selectAllEmptyScenes = () => {
    safeVibrate(15);
    const target = emptySceneIndices.length > 0 ? emptySceneIndices : incompleteSceneIndices;
    setSelectedSceneIndices(target);
  };

  // Select all scenes
  const selectAllScenes = () => {
    safeVibrate(15);
    setSelectedSceneIndices(project.scenes.map((_, i) => i));
  };

  // Clear selection
  const clearSelection = () => {
    safeVibrate(10);
    setSelectedSceneIndices([]);
  };

  // Open batch modal with specified or currently selected scenes
  const openBatchModal = (indices?: number[]) => {
    safeVibrate(20);
    const targetIndices = indices && indices.length > 0 ? indices : selectedSceneIndices;
    if (targetIndices.length === 0) {
      // Default to all empty/incomplete scenes, or all if none
      const fallback =
        emptySceneIndices.length > 0
          ? emptySceneIndices
          : incompleteSceneIndices.length > 0
          ? incompleteSceneIndices
          : [activeSceneIndex];
      setSelectedSceneIndices(fallback);
    } else {
      setSelectedSceneIndices(targetIndices);
    }
    setIsBatchModalOpen(true);
  };

  // Handle adding multiple empty scenes at once
  const handleAddMultiple = (count: number) => {
    safeVibrate(20);
    setShowAddMenu(false);
    if (onAddMultipleScenes) {
      onAddMultipleScenes(count);
    } else {
      for (let i = 0; i < count; i++) {
        onAddScene();
      }
    }
  };

  // Single Scene Visual Regeneration
  const handleRegenerateVisual = async () => {
    if (!currentScene) return;
    setIsRegenerating(true);
    safeVibrate(15);

    try {
      const promptToUse = editPrompt || currentScene.visualPrompt;
      const res = await generateImage({
        prompt: promptToUse,
        aspectRatio: project.aspectRatio,
        visualStyle: project.visualStyle,
        characterReferenceBase64: project.characterReference?.imageBase64,
      });

      if (res.imageUrl) {
        onUpdateScene(activeSceneIndex, { imageUrl: res.imageUrl });
      } else {
        const procedural = await createProceduralSceneCanvas(
          project.aspectRatio === '9:16' ? 720 : 1280,
          project.aspectRatio === '9:16' ? 1280 : 720,
          project.visualStyle,
          currentScene.sceneNumber,
          project.characterReference?.imageBase64,
          promptToUse
        );
        onUpdateScene(activeSceneIndex, { imageUrl: procedural });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsRegenerating(false);
    }
  };

  // Execute Batch Generation across all selected scenes
  const runBatchGeneration = async () => {
    const targets = selectedSceneIndices.length > 0
      ? selectedSceneIndices
      : emptySceneIndices.length > 0
      ? emptySceneIndices
      : [activeSceneIndex];

    if (targets.length === 0) return;

    abortBatchRef.current = false;
    setIsBatchGenerating(true);
    safeVibrate(25);

    const initialStatuses: Record<number, 'pending' | 'generating' | 'done' | 'error'> = {};
    targets.forEach((idx) => {
      initialStatuses[idx] = 'pending';
    });

    setBatchProgress({
      current: 0,
      total: targets.length,
      stepText: `Preparing batch generation for ${targets.length} scenes...`,
      sceneStatuses: initialStatuses,
    });

    try {
      // Step 1: Intelligent Story Continuity Scripting
      let scriptedScenes: Record<number, { narration: string; visualPrompt: string; cameraMotion?: CameraMotion; soundEffect?: SoundEffectType }> = {};

      if (generateContinuityScript) {
        setBatchProgress((prev) => ({
          ...prev,
          stepText: 'Director AI: Generating coherent story narration & visual prompts...',
        }));

        // Existing scenes context
        const existingScenesSummary = project.scenes
          .filter((_, idx) => !targets.includes(idx))
          .map((s) => ({
            sceneNumber: s.sceneNumber,
            narration: s.narration,
            visualPrompt: s.visualPrompt,
          }));

        const scenesToFill = targets.map((idx) => {
          const s = project.scenes[idx];
          return {
            sceneNumber: s.sceneNumber,
            duration: s.duration,
            currentNarration: s.narration,
            currentVisualPrompt: s.visualPrompt,
          };
        });

        try {
          const filledScripts = await batchFillSceneScripts({
            storyTitle: project.title,
            language: project.language,
            storyType: project.storyType,
            visualStyle: project.visualStyle,
            existingScenesSummary,
            scenesToFill,
            guidancePrompt: themeGuidance || undefined,
            characterDescription: project.characterReference?.name
              ? `${project.characterReference.name}, ${project.characterReference.clothing || ''}`
              : undefined,
          });

          filledScripts.forEach((fs) => {
            const foundIdx = project.scenes.findIndex((s) => s.sceneNumber === fs.sceneNumber);
            if (foundIdx !== -1) {
              scriptedScenes[foundIdx] = {
                narration: fs.narration,
                visualPrompt: fs.visualPrompt,
                cameraMotion: fs.cameraMotion,
                soundEffect: fs.soundEffect,
              };
            }
          });
        } catch (scriptErr) {
          console.warn('Script generation warning:', scriptErr);
        }
      }

      // Step 2: Iterate sequentially through target scenes to produce visuals and voice
      for (let i = 0; i < targets.length; i++) {
        if (abortBatchRef.current) {
          break;
        }

        const sceneIdx = targets[i];
        const scene = project.scenes[sceneIdx];
        if (!scene) continue;

        // Mark generating
        setBatchProgress((prev) => ({
          ...prev,
          current: i + 1,
          stepText: `Scene ${scene.sceneNumber} (${i + 1}/${targets.length}): Synthesizing visuals & voice...`,
          sceneStatuses: { ...prev.sceneStatuses, [sceneIdx]: 'generating' },
        }));

        const updates: Partial<Scene> = {};

        // Use scripted narration / visual prompt if available or keep existing
        const generatedScript = scriptedScenes[sceneIdx];
        const finalNarration =
          generatedScript?.narration ||
          (scene.narration && !scene.narration.startsWith('Scene ')
            ? scene.narration
            : `${project.title}: Scene ${scene.sceneNumber} unfolded in majestic ${project.visualStyle} glory.`);

        const finalPrompt =
          generatedScript?.visualPrompt ||
          (scene.visualPrompt && !scene.visualPrompt.startsWith('Scene ')
            ? scene.visualPrompt
            : `${project.visualStyle} composition for ${project.title}, scene ${scene.sceneNumber}, cinematic lighting, 8k masterpiece`);

        updates.narration = finalNarration;
        updates.englishNarration = finalNarration;
        updates.visualPrompt = finalPrompt;

        if (applySmartCamera) {
          if (generatedScript?.cameraMotion) {
            updates.cameraMotion = generatedScript.cameraMotion;
          }
          if (generatedScript?.soundEffect) {
            updates.soundEffect = generatedScript.soundEffect;
          }
        }

        // Sub-step: Visual Generation
        if (generateVisuals) {
          try {
            const imgRes = await generateImage({
              prompt: finalPrompt,
              aspectRatio: project.aspectRatio,
              visualStyle: project.visualStyle,
              characterReferenceBase64: project.characterReference?.imageBase64,
            });

            if (imgRes.imageUrl) {
              updates.imageUrl = imgRes.imageUrl;
            } else {
              const canvasImg = await createProceduralSceneCanvas(
                project.aspectRatio === '9:16' ? 720 : 1280,
                project.aspectRatio === '9:16' ? 1280 : 720,
                project.visualStyle,
                scene.sceneNumber,
                project.characterReference?.imageBase64,
                finalPrompt
              );
              updates.imageUrl = canvasImg;
            }
          } catch (imgErr) {
            console.error('Visual frame creation error:', imgErr);
            const fallbackCanvas = await createProceduralSceneCanvas(
              project.aspectRatio === '9:16' ? 720 : 1280,
              project.aspectRatio === '9:16' ? 1280 : 720,
              project.visualStyle,
              scene.sceneNumber,
              project.characterReference?.imageBase64,
              finalPrompt
            );
            updates.imageUrl = fallbackCanvas;
          }
        }

        // Sub-step: Voice Narration (TTS)
        if (generateVoiceover && finalNarration) {
          try {
            const ttsRes = await generateTTS({
              text: finalNarration,
              voice: selectedVoice,
            });
            if (ttsRes.audioBase64) {
              updates.audioBase64 = ttsRes.audioBase64;
            }
          } catch (ttsErr) {
            console.warn('TTS error for scene:', ttsErr);
          }
        }

        // Apply immediate update to project state so user sees real-time progress
        onUpdateScene(sceneIdx, updates);
        safeVibrate(15);

        // Mark completed in status map
        setBatchProgress((prev) => ({
          ...prev,
          sceneStatuses: { ...prev.sceneStatuses, [sceneIdx]: 'done' },
        }));

        // Small breather for smooth UI rendering
        await new Promise((r) => setTimeout(r, 120));
      }

      setBatchProgress((prev) => ({
        ...prev,
        stepText: 'Batch Generation Complete! All scenes generated successfully.',
      }));

      safeVibrate([30, 50, 40]);
      setTimeout(() => {
        setIsBatchModalOpen(false);
        setIsBatchGenerating(false);
        setSelectedSceneIndices([]);
      }, 1400);
    } catch (err: any) {
      console.error('Batch generation failed:', err);
      setBatchProgress((prev) => ({
        ...prev,
        stepText: `Error: ${err.message || 'Batch generation incomplete'}`,
      }));
      setIsBatchGenerating(false);
    }
  };

  // Cancel running batch
  const handleCancelBatch = () => {
    abortBatchRef.current = true;
    setIsBatchGenerating(false);
    setIsBatchModalOpen(false);
  };

  const isCurrentSceneEmpty = currentScene ? isSceneEmpty(currentScene) : false;
  const isCurrentSceneIncomplete = currentScene ? isSceneIncomplete(currentScene) : false;

  return (
    <div className="bg-[#0E121C] border border-gray-800 rounded-3xl p-3 sm:p-5 space-y-4 shadow-xl">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-gray-800/80 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <Sliders className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm sm:text-base font-bold text-white">Scene Timeline & Director</h3>
              {emptySceneIndices.length > 0 && (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse">
                  {emptySceneIndices.length} Empty {emptySceneIndices.length === 1 ? 'Scene' : 'Scenes'}
                </span>
              )}
            </div>
            <p className="text-[11px] text-gray-400">
              {project.scenes.length} Scenes • {project.scenes.reduce((a, s) => a + s.duration, 0)}s Total • {project.visualStyle} Style
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 w-full sm:w-auto justify-end flex-wrap">
          {/* Batch Fill Button (Always accessible or prominent when empty scenes exist) */}
          <button
            onClick={() => openBatchModal()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-black font-extrabold text-xs shadow-md shadow-amber-500/20 transition transform active:scale-95"
            title="Batch generate AI visuals, voice narration, and story scripts"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>
              {selectedSceneIndices.length > 0
                ? `Batch Generate (${selectedSceneIndices.length})`
                : emptySceneIndices.length > 0
                ? `Batch Fill Empty (${emptySceneIndices.length})`
                : 'Batch Generator'}
            </span>
          </button>

          {/* Add Scene Dropdown Menu */}
          <div className="relative">
            <div className="flex items-center rounded-xl bg-gray-800/80 border border-gray-700/80 overflow-hidden">
              <button
                onClick={onAddScene}
                className="flex items-center gap-1.5 px-2.5 py-1.5 hover:bg-gray-700 text-gray-200 font-bold text-xs transition"
                title="Add 1 Scene"
              >
                <Plus className="w-3.5 h-3.5 text-amber-400" />
                <span>Add</span>
              </button>
              <button
                onClick={() => setShowAddMenu(!showAddMenu)}
                className="px-1.5 py-1.5 hover:bg-gray-700 border-l border-gray-700 text-gray-400 hover:text-white transition"
                title="Add Multiple Empty Scenes"
              >
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Dropdown Menu for Quick Scene Addition */}
            {showAddMenu && (
              <div className="absolute right-0 mt-1.5 w-44 rounded-xl bg-[#141824] border border-gray-700 shadow-2xl py-1 z-30 space-y-0.5">
                <button
                  onClick={() => handleAddMultiple(1)}
                  className="w-full text-left px-3 py-1.5 text-xs text-gray-200 hover:bg-amber-500/20 hover:text-amber-300 flex items-center justify-between"
                >
                  <span>+1 Empty Scene</span>
                </button>
                <button
                  onClick={() => handleAddMultiple(3)}
                  className="w-full text-left px-3 py-1.5 text-xs text-gray-200 hover:bg-amber-500/20 hover:text-amber-300 flex items-center justify-between font-medium"
                >
                  <span>+3 Empty Scenes</span>
                  <span className="text-[10px] text-amber-400">Storyboard</span>
                </button>
                <button
                  onClick={() => handleAddMultiple(5)}
                  className="w-full text-left px-3 py-1.5 text-xs text-gray-200 hover:bg-amber-500/20 hover:text-amber-300 flex items-center justify-between font-medium"
                >
                  <span>+5 Empty Scenes</span>
                  <span className="text-[10px] text-amber-400">Full Arc</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Batch Selection Utility Bar (Appears when scenes are selected or multiple empty scenes exist) */}
      <div className="flex items-center justify-between gap-2 px-1 text-xs">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-gray-400 font-medium text-[11px]">Select:</span>
          {emptySceneIndices.length > 0 && (
            <button
              onClick={selectAllEmptyScenes}
              className="px-2 py-0.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px] font-semibold transition"
            >
              All Empty ({emptySceneIndices.length})
            </button>
          )}
          <button
            onClick={selectAllScenes}
            className="px-2 py-0.5 rounded-lg bg-gray-800 hover:bg-gray-700 text-gray-300 text-[11px] transition"
          >
            All ({project.scenes.length})
          </button>
          {selectedSceneIndices.length > 0 && (
            <button
              onClick={clearSelection}
              className="px-2 py-0.5 rounded-lg text-gray-400 hover:text-red-400 text-[11px] transition"
            >
              Clear ({selectedSceneIndices.length})
            </button>
          )}
        </div>

        {selectedSceneIndices.length > 0 && (
          <span className="text-amber-400 font-bold text-[11px]">
            {selectedSceneIndices.length} {selectedSceneIndices.length === 1 ? 'scene' : 'scenes'} selected
          </span>
        )}
      </div>

      {/* Horizontal Thumbnails Strip (Touch friendly for Samsung & Mobile) */}
      <div className="flex items-center gap-2.5 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-gray-800">
        {project.scenes.map((scene, idx) => {
          const isActive = idx === activeSceneIndex;
          const isSelected = selectedSceneIndices.includes(idx);
          const sceneIsEmpty = isSceneEmpty(scene);
          const sceneIsIncomplete = isSceneIncomplete(scene);

          return (
            <div
              key={scene.id || idx}
              onClick={() => {
                safeVibrate(10);
                onSelectScene(idx);
              }}
              className={`flex-shrink-0 w-32 sm:w-36 rounded-2xl overflow-hidden border-2 cursor-pointer transition relative group ${
                isActive
                  ? 'border-amber-500 shadow-lg shadow-amber-500/25 scale-102 bg-[#171D2D]'
                  : isSelected
                  ? 'border-orange-400 bg-[#161B29] ring-2 ring-orange-500/40'
                  : sceneIsEmpty
                  ? 'border-dashed border-amber-500/50 bg-[#12141F]'
                  : 'border-gray-800 bg-[#121622] opacity-80 hover:opacity-100 hover:border-gray-700'
              }`}
            >
              {/* Thumbnail Image / Empty Placeholder */}
              <div className="aspect-video w-full bg-gray-950 relative overflow-hidden flex items-center justify-center">
                {scene.imageUrl ? (
                  <img
                    src={scene.imageUrl}
                    alt={`Scene ${idx + 1}`}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center p-2 bg-gradient-to-b from-[#141824] to-[#0A0D14] text-center">
                    <ImageIcon className="w-5 h-5 text-amber-500/60 mb-1 animate-pulse" />
                    <span className="text-[10px] font-bold text-amber-300 uppercase tracking-wider">
                      Empty Frame
                    </span>
                    <span className="text-[9px] text-gray-500">Ready for AI</span>
                  </div>
                )}

                {/* Checkbox for Batch Selection */}
                <div
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleSelectScene(idx);
                  }}
                  className="absolute top-1.5 right-1.5 p-1 rounded-md bg-black/70 hover:bg-amber-500/80 text-white cursor-pointer transition z-10"
                  title="Select for batch generation"
                >
                  {isSelected ? (
                    <CheckSquare className="w-3.5 h-3.5 text-amber-400" />
                  ) : (
                    <Square className="w-3.5 h-3.5 text-gray-400 hover:text-white" />
                  )}
                </div>

                {/* Scene Number Badge */}
                <span className="absolute top-1.5 left-1.5 w-5 h-5 rounded-full bg-amber-500 text-black text-[11px] font-black flex items-center justify-center shadow">
                  {idx + 1}
                </span>

                {/* Duration Badge */}
                <span className="absolute bottom-1 right-1 px-1.5 py-0.5 rounded bg-black/80 text-[10px] font-mono text-amber-300 font-bold">
                  {scene.duration}s
                </span>

                {/* Voice audio wave indicator */}
                {scene.audioBase64 && (
                  <span
                    className="absolute bottom-1 left-1 px-1 py-0.5 rounded bg-black/80 text-[9px] text-emerald-400 font-bold flex items-center gap-0.5"
                    title="AI Voiceover Ready"
                  >
                    <Mic className="w-2.5 h-2.5" />
                  </span>
                )}
              </div>

              {/* Text Snippet & Info */}
              <div className="p-2">
                <p className="text-[11px] font-medium text-gray-200 line-clamp-1">
                  {scene.narration || scene.visualPrompt || `Empty Scene ${idx + 1}`}
                </p>
                <div className="flex items-center justify-between text-[10px] text-gray-400 mt-1 capitalize">
                  <span className="truncate max-w-[70px]">{scene.cameraMotion}</span>
                  <span>{scene.soundEffect !== 'none' ? '🔔' : ''}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Empty Scene Quick Callout Banner (if active scene is empty) */}
      {currentScene && (isCurrentSceneEmpty || isCurrentSceneIncomplete) && (
        <div className="bg-gradient-to-r from-amber-500/15 via-orange-500/10 to-transparent border border-amber-500/40 rounded-2xl p-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400">
              <Wand2 className="w-4 h-4 animate-bounce" />
            </div>
            <div>
              <h5 className="text-xs sm:text-sm font-bold text-amber-300">
                Scene {activeSceneIndex + 1} is missing visual or audio content
              </h5>
              <p className="text-[11px] text-gray-300">
                Generate high-resolution visuals and AI narration individually or batch-fill all {emptySceneIndices.length} empty scenes.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={handleRegenerateVisual}
              disabled={isRegenerating}
              className="flex-1 sm:flex-initial px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs transition flex items-center justify-center gap-1.5 disabled:opacity-50"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isRegenerating ? 'Generating Frame...' : 'Generate Frame'}</span>
            </button>
            {emptySceneIndices.length > 1 && (
              <button
                onClick={() => openBatchModal(emptySceneIndices)}
                className="flex-1 sm:flex-initial px-3 py-1.5 rounded-xl bg-gray-800 hover:bg-gray-700 text-amber-300 font-bold text-xs border border-amber-500/30 transition flex items-center justify-center gap-1"
              >
                <span>Batch Fill All ({emptySceneIndices.length})</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Detailed Scene Settings Panel for Active Scene */}
      {currentScene && (
        <div className="bg-[#121724] border border-gray-800/80 rounded-2xl p-3 sm:p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-gray-800 pb-3">
            <div className="flex items-center gap-2">
              <span className="w-7 h-7 rounded-xl bg-amber-500/20 text-amber-400 font-bold text-xs flex items-center justify-center border border-amber-500/30">
                #{activeSceneIndex + 1}
              </span>
              <h4 className="text-xs sm:text-sm font-bold text-white">
                Editing Scene {activeSceneIndex + 1}
              </h4>
              {project.characterReference?.locked && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                  <ShieldCheck className="w-3 h-3 text-emerald-400" />
                  Character Locked
                </span>
              )}
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={() => onDuplicateScene(activeSceneIndex)}
                title="Duplicate Scene"
                className="p-1.5 rounded-lg bg-gray-800 text-gray-400 hover:text-white transition"
              >
                <Copy className="w-4 h-4" />
              </button>

              {project.scenes.length > 1 && (
                <button
                  onClick={() => onDeleteScene(activeSceneIndex)}
                  title="Delete Scene"
                  className="p-1.5 rounded-lg bg-red-950/40 text-red-400 hover:bg-red-900/60 transition"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {/* Narration Script Input */}
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-gray-300">
                Spoken Narration Script ({project.language})
              </label>
              {currentScene.audioBase64 && (
                <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                  <Check className="w-3 h-3" /> Voice Synthesized
                </span>
              )}
            </div>
            <textarea
              rows={2}
              value={currentScene.narration}
              placeholder={`Write or generate spoken narration in ${project.language}...`}
              onChange={(e) => onUpdateScene(activeSceneIndex, { narration: e.target.value })}
              className="w-full bg-[#0B0E16] border border-gray-700 focus:border-amber-500 rounded-xl p-2.5 text-xs sm:text-sm text-gray-100 outline-none resize-none font-medium"
            />
          </div>

          {/* Visual Prompt Input & Regenerate */}
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-gray-300">
                Visual Prompt & Composition ({project.visualStyle} Style)
              </label>
              <button
                onClick={handleRegenerateVisual}
                disabled={isRegenerating}
                className="text-[11px] font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1 transition disabled:opacity-50"
              >
                <Sparkles className="w-3.5 h-3.5" />
                {isRegenerating ? 'Generating Frame...' : 'Regenerate Frame'}
              </button>
            </div>
            <textarea
              rows={2}
              value={editPrompt || currentScene.visualPrompt}
              placeholder="Describe what appears in this scene frame (subject, action, camera angle, lighting)..."
              onChange={(e) => {
                setEditPrompt(e.target.value);
                onUpdateScene(activeSceneIndex, { visualPrompt: e.target.value });
              }}
              className="w-full bg-[#0B0E16] border border-gray-700 focus:border-amber-500 rounded-xl p-2.5 text-xs text-gray-300 outline-none resize-none"
            />
          </div>

          {/* Camera Motion & Motion Strength */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Motion Selector */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-gray-300">
                Camera Movement
              </label>
              <select
                value={currentScene.cameraMotion}
                onChange={(e) =>
                  onUpdateScene(activeSceneIndex, { cameraMotion: e.target.value as CameraMotion })
                }
                className="w-full bg-[#0B0E16] border border-gray-700 focus:border-amber-500 rounded-xl p-2.5 text-xs sm:text-sm text-white font-medium outline-none"
              >
                {CAMERA_MOTIONS.map((cm) => (
                  <option key={cm.value} value={cm.value}>
                    {cm.icon} {cm.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Motion Strength Slider */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-bold text-gray-300">
                  Motion Strength (1–10)
                </label>
                <span className="text-xs font-bold text-amber-400 font-mono">
                  {currentScene.motionStrength || 7}/10
                </span>
              </div>
              <input
                type="range"
                min={1}
                max={10}
                value={currentScene.motionStrength || 7}
                onChange={(e) =>
                  onUpdateScene(activeSceneIndex, { motionStrength: parseInt(e.target.value) })
                }
                className="w-full h-2 bg-gray-800 accent-amber-500 rounded-lg cursor-pointer"
              />
            </div>
          </div>

          {/* Scene Duration & Sound Effect */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Duration */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-bold text-gray-300">
                  Scene Duration
                </label>
                <span className="text-xs font-bold text-amber-400 font-mono">
                  {currentScene.duration} seconds
                </span>
              </div>
              <input
                type="range"
                min={2}
                max={15}
                value={currentScene.duration}
                onChange={(e) =>
                  onUpdateScene(activeSceneIndex, { duration: parseInt(e.target.value) })
                }
                className="w-full h-2 bg-gray-800 accent-amber-500 rounded-lg cursor-pointer"
              />
            </div>

            {/* Sound Effect Cue */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-gray-300">
                Scene Sound Effect (SFX)
              </label>
              <select
                value={currentScene.soundEffect}
                onChange={(e) =>
                  onUpdateScene(activeSceneIndex, {
                    soundEffect: e.target.value as SoundEffectType,
                  })
                }
                className="w-full bg-[#0B0E16] border border-gray-700 focus:border-amber-500 rounded-xl p-2.5 text-xs sm:text-sm text-white font-medium outline-none"
              >
                {SFX_OPTIONS.map((sfx) => (
                  <option key={sfx.value} value={sfx.value}>
                    {sfx.emoji} {sfx.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* BATCH GENERATION MODAL DIALOG                            */}
      {/* ======================================================== */}
      {isBatchModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-[#101420] border border-amber-500/40 rounded-3xl w-full max-w-xl max-h-[90vh] overflow-y-auto shadow-2xl p-4 sm:p-6 space-y-5">
            {/* Modal Header */}
            <div className="flex items-start justify-between border-b border-gray-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-500 text-black shadow-lg shadow-amber-500/25">
                  <Sparkles className="w-5 h-5 font-black" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-black text-white">
                    Batch Scene Generator
                  </h3>
                  <p className="text-xs text-gray-400">
                    Generate AI visuals, voice narration, and story continuity for multiple scenes at once
                  </p>
                </div>
              </div>

              {!isBatchGenerating && (
                <button
                  onClick={() => setIsBatchModalOpen(false)}
                  className="p-1.5 rounded-xl bg-gray-800/80 text-gray-400 hover:text-white hover:bg-gray-700 transition"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Target Scenes Chip Bar */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-bold text-gray-300">
                <span>
                  Target Scenes (
                  {selectedSceneIndices.length > 0
                    ? selectedSceneIndices.length
                    : emptySceneIndices.length}{' '}
                  Selected)
                </span>
                <button
                  onClick={selectAllEmptyScenes}
                  className="text-amber-400 hover:underline text-[11px]"
                >
                  Reset to All Empty
                </button>
              </div>

              <div className="flex items-center gap-1.5 flex-wrap p-2 rounded-xl bg-[#090C14] border border-gray-800 max-h-24 overflow-y-auto">
                {project.scenes.map((scene, idx) => {
                  const isTarget = selectedSceneIndices.includes(idx);
                  const isSceneEmp = isSceneEmpty(scene);

                  return (
                    <button
                      key={scene.id || idx}
                      onClick={() => !isBatchGenerating && toggleSelectScene(idx)}
                      disabled={isBatchGenerating}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1 ${
                        isTarget
                          ? 'bg-amber-500 text-black shadow'
                          : 'bg-gray-800 text-gray-400 hover:text-gray-200'
                      }`}
                    >
                      <span>Scene {scene.sceneNumber}</span>
                      {isSceneEmp && <span className="text-[10px] opacity-80">(Empty)</span>}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Batch Generation Options */}
            {!isBatchGenerating ? (
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider">
                    Content Components to Generate
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {/* Visuals Toggle */}
                    <div
                      onClick={() => setGenerateVisuals(!generateVisuals)}
                      className={`p-3 rounded-2xl border cursor-pointer transition flex items-start gap-2.5 ${
                        generateVisuals
                          ? 'bg-amber-500/10 border-amber-500/50 text-white'
                          : 'bg-[#0A0D15] border-gray-800 text-gray-400'
                      }`}
                    >
                      <div className="mt-0.5">
                        {generateVisuals ? (
                          <CheckSquare className="w-4 h-4 text-amber-400" />
                        ) : (
                          <Square className="w-4 h-4 text-gray-500" />
                        )}
                      </div>
                      <div>
                        <span className="text-xs font-bold block text-white">
                          AI Visual Frames
                        </span>
                        <span className="text-[10px] text-gray-400">
                          {project.visualStyle} style with character reference lock
                        </span>
                      </div>
                    </div>

                    {/* Voiceover TTS Toggle */}
                    <div
                      onClick={() => setGenerateVoiceover(!generateVoiceover)}
                      className={`p-3 rounded-2xl border cursor-pointer transition flex items-start gap-2.5 ${
                        generateVoiceover
                          ? 'bg-amber-500/10 border-amber-500/50 text-white'
                          : 'bg-[#0A0D15] border-gray-800 text-gray-400'
                      }`}
                    >
                      <div className="mt-0.5">
                        {generateVoiceover ? (
                          <CheckSquare className="w-4 h-4 text-amber-400" />
                        ) : (
                          <Square className="w-4 h-4 text-gray-500" />
                        )}
                      </div>
                      <div>
                        <span className="text-xs font-bold block text-white">
                          AI Voiceover (TTS)
                        </span>
                        <span className="text-[10px] text-gray-400">
                          Synthesize speech in {project.language}
                        </span>
                      </div>
                    </div>

                    {/* Story Continuity Scripting */}
                    <div
                      onClick={() => setGenerateContinuityScript(!generateContinuityScript)}
                      className={`p-3 rounded-2xl border cursor-pointer transition flex items-start gap-2.5 ${
                        generateContinuityScript
                          ? 'bg-amber-500/10 border-amber-500/50 text-white'
                          : 'bg-[#0A0D15] border-gray-800 text-gray-400'
                      }`}
                    >
                      <div className="mt-0.5">
                        {generateContinuityScript ? (
                          <CheckSquare className="w-4 h-4 text-amber-400" />
                        ) : (
                          <Square className="w-4 h-4 text-gray-500" />
                        )}
                      </div>
                      <div>
                        <span className="text-xs font-bold block text-white">
                          Story Continuity Scripting
                        </span>
                        <span className="text-[10px] text-gray-400">
                          AI writes context-aware narration for empty scenes
                        </span>
                      </div>
                    </div>

                    {/* Smart Camera & SFX */}
                    <div
                      onClick={() => setApplySmartCamera(!applySmartCamera)}
                      className={`p-3 rounded-2xl border cursor-pointer transition flex items-start gap-2.5 ${
                        applySmartCamera
                          ? 'bg-amber-500/10 border-amber-500/50 text-white'
                          : 'bg-[#0A0D15] border-gray-800 text-gray-400'
                      }`}
                    >
                      <div className="mt-0.5">
                        {applySmartCamera ? (
                          <CheckSquare className="w-4 h-4 text-amber-400" />
                        ) : (
                          <Square className="w-4 h-4 text-gray-500" />
                        )}
                      </div>
                      <div>
                        <span className="text-xs font-bold block text-white">
                          Smart Camera & SFX
                        </span>
                        <span className="text-[10px] text-gray-400">
                          Harmonize cinematic push/zoom & audio cues
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Optional Director Guidance */}
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-gray-300">
                    Story Direction / Scene Tone (Optional)
                  </label>
                  <input
                    type="text"
                    value={themeGuidance}
                    onChange={(e) => setThemeGuidance(e.target.value)}
                    placeholder="e.g. Hero enters the glowing temple courtyard, discovers divine relic"
                    className="w-full bg-[#090C14] border border-gray-700 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-white outline-none"
                  />
                </div>

                {/* Voice Selection */}
                {generateVoiceover && (
                  <div className="space-y-1">
                    <label className="block text-xs font-bold text-gray-300">
                      Narrator Voice Model
                    </label>
                    <div className="grid grid-cols-5 gap-1.5">
                      {TTS_VOICES.map((v) => (
                        <button
                          key={v}
                          type="button"
                          onClick={() => setSelectedVoice(v)}
                          className={`py-1.5 rounded-xl text-xs font-bold transition border ${
                            selectedVoice === v
                              ? 'bg-amber-500 text-black border-amber-400 shadow'
                              : 'bg-gray-800/80 text-gray-300 border-gray-700 hover:border-gray-600'
                          }`}
                        >
                          {v}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex items-center gap-2 pt-2">
                  <button
                    onClick={() => setIsBatchModalOpen(false)}
                    className="w-1/3 py-2.5 rounded-xl bg-gray-800 hover:bg-gray-700 text-gray-300 font-bold text-xs transition"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={runBatchGeneration}
                    className="w-2/3 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-black font-extrabold text-xs shadow-lg shadow-amber-500/25 transition transform active:scale-98 flex items-center justify-center gap-2"
                  >
                    <Sparkles className="w-4 h-4 font-black" />
                    <span>
                      Generate Content (
                      {selectedSceneIndices.length > 0
                        ? selectedSceneIndices.length
                        : emptySceneIndices.length}{' '}
                      Scenes)
                    </span>
                  </button>
                </div>
              </div>
            ) : (
              /* Generation In Progress Progress Display */
              <div className="space-y-4 py-2">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-gray-300">
                    <span className="flex items-center gap-2 text-amber-400">
                      <Loader2 className="w-4 h-4 animate-spin text-amber-400" />
                      <span>{batchProgress.stepText}</span>
                    </span>
                    <span className="font-mono text-amber-400">
                      {Math.round((batchProgress.current / Math.max(1, batchProgress.total)) * 100)}%
                    </span>
                  </div>

                  {/* Multi-step Progress Bar */}
                  <div className="w-full h-3 bg-gray-900 rounded-full overflow-hidden p-0.5 border border-gray-800">
                    <div
                      className="h-full bg-gradient-to-r from-amber-500 via-orange-500 to-yellow-400 rounded-full transition-all duration-300 shadow-md shadow-amber-500/50"
                      style={{
                        width: `${Math.max(
                          5,
                          (batchProgress.current / Math.max(1, batchProgress.total)) * 100
                        )}%`,
                      }}
                    />
                  </div>
                </div>

                {/* Per-scene status list */}
                <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                  {selectedSceneIndices.map((idx) => {
                    const scene = project.scenes[idx];
                    const status = batchProgress.sceneStatuses[idx] || 'pending';

                    return (
                      <div
                        key={idx}
                        className={`p-2.5 rounded-xl border flex items-center justify-between text-xs transition ${
                          status === 'done'
                            ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-300'
                            : status === 'generating'
                            ? 'bg-amber-500/10 border-amber-500/40 text-amber-300 font-bold'
                            : 'bg-[#090C14] border-gray-800/80 text-gray-400'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-gray-800 text-gray-300 text-[10px] font-bold flex items-center justify-center">
                            #{scene?.sceneNumber || idx + 1}
                          </span>
                          <span className="truncate max-w-[240px]">
                            {scene?.narration || scene?.visualPrompt || `Scene ${idx + 1}`}
                          </span>
                        </div>

                        <div>
                          {status === 'done' && (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400">
                              <Check className="w-3.5 h-3.5" /> Generated
                            </span>
                          )}
                          {status === 'generating' && (
                            <span className="inline-flex items-center gap-1 text-[11px] text-amber-400 font-bold">
                              <Loader2 className="w-3.5 h-3.5 animate-spin" /> Synthesizing...
                            </span>
                          )}
                          {status === 'pending' && (
                            <span className="text-[10px] text-gray-500">Queued</span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="pt-2">
                  <button
                    onClick={handleCancelBatch}
                    className="w-full py-2 rounded-xl bg-gray-800 hover:bg-red-950/60 hover:text-red-300 text-gray-400 font-bold text-xs transition"
                  >
                    Cancel Remaining
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
