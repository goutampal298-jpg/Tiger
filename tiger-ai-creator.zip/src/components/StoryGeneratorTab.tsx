import React, { useState, useRef } from 'react';
import {
  Sparkles,
  BookOpen,
  Image as ImageIcon,
  Film,
  Upload,
  CheckCircle,
  Copy,
  Layers,
  ArrowRight,
  Music,
  Video,
  Camera,
  Volume2,
  Subtitles,
  User,
  Loader2,
} from 'lucide-react';
import { Project, StoryLanguage, StoryType, VisualStyle, Scene, CameraMotion, SoundEffectType } from '../types';
import { STORY_LANGUAGES, STORY_TYPES, VISUAL_STYLES } from '../utils/constants';
import {
  analyzeImage,
  breakScenes,
  createProceduralSceneCanvas,
  generateImage,
  generateStory,
  generateTTS,
} from '../services/geminiService';
import { safeVibrate } from '../utils/haptics';

interface StoryGeneratorTabProps {
  project: Project;
  onApplyStoryToProject: (updatedProject: Partial<Project>) => void;
}

const STORY_IDEAS = [
  {
    label: 'বাঘ ও শিশু (Bengali)',
    prompt: 'একটি বাঘ জঙ্গলে একটি শিশুকে বাঁচালো',
    language: 'Bengali' as StoryLanguage,
    genre: 'Drama' as StoryType,
  },
  {
    label: 'Lord Krishna & Arjuna (Devotional)',
    prompt: 'Lord Krishna enlightens Arjuna on the battlefield of Kurukshetra before the Great War',
    language: 'English' as StoryLanguage,
    genre: 'Devotional' as StoryType,
  },
  {
    label: 'शिव तांडव (Hindi)',
    prompt: 'कैलाश पर्वत पर भगवान शिव का दिव्य और शक्तिशाली आनंद तांडव नृत्य',
    language: 'Hindi' as StoryLanguage,
    genre: 'Indian mythology' as StoryType,
  },
  {
    label: 'Sundarbans Tiger Legend',
    prompt: 'Royal Bengal Tiger protects the pristine mangrove river from mythical elemental spirits',
    language: 'English' as StoryLanguage,
    genre: 'Adventure' as StoryType,
  },
];

export const StoryGeneratorTab: React.FC<StoryGeneratorTabProps> = ({
  project,
  onApplyStoryToProject,
}) => {
  const [language, setLanguage] = useState<StoryLanguage>(project.language);
  const [storyType, setStoryType] = useState<StoryType>(project.storyType);
  const [duration, setDuration] = useState<number>(project.targetDuration || 30);
  const [userStory, setUserStory] = useState<string>(STORY_IDEAS[0].prompt);
  const [customNotes, setCustomNotes] = useState<string>('');

  // Auto Story From Image
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadedRefImage, setUploadedRefImage] = useState<string | null>(null);

  // Status & Results
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [generatedResult, setGeneratedResult] = useState<any | null>(null);
  const [sceneBreakdown, setSceneBreakdown] = useState<any | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const handleApplyPresetIdea = (idea: typeof STORY_IDEAS[0]) => {
    safeVibrate(10);
    setUserStory(idea.prompt);
    setLanguage(idea.language);
    setStoryType(idea.genre);
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      if (ev.target?.result) {
        setUploadedRefImage(ev.target.result as string);
        safeVibrate(15);
      }
    };
    reader.readAsDataURL(file);
  };

  const copyToClipboard = (text: string, fieldName: string) => {
    safeVibrate(10);
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleGenerateStory = async (fromImage: boolean = false) => {
    setIsLoading(true);
    setErrorMsg(null);
    setSceneBreakdown(null);
    safeVibrate(20);
    setStatusMessage('Crafting original story and directorial blueprint...');

    try {
      let imageAnalysis = null;
      if (fromImage && uploadedRefImage) {
        setStatusMessage('Analyzing character, mood & lighting from reference photo...');
        imageAnalysis = await analyzeImage(uploadedRefImage).catch(() => null);
      }

      const result = await generateStory({
        language,
        storyType,
        durationSeconds: duration,
        userStory,
        imageAnalysis,
        customNotes,
      });

      setGeneratedResult(result);

      // Immediately generate detailed scene-by-scene script breakdown with all 10 directorial elements
      setStatusMessage('Directing scene-by-scene script, prompts, dialogue & camera movements...');
      const breakdown = await breakScenes({
        story: {
          title: result.title || `${storyType} Story`,
          fullScript: result.fullScript,
        },
        language,
        storyType,
        durationSeconds: duration,
        visualStyle: project.visualStyle,
        characterReference: project.characterReference,
      });

      setSceneBreakdown(breakdown);
      safeVibrate([20, 40, 20]);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Failed to generate story');
    } finally {
      setIsLoading(false);
      setStatusMessage('');
    }
  };

  const handleApplyToProject = async () => {
    if (!generatedResult || !sceneBreakdown) return;
    setIsLoading(true);
    safeVibrate(25);
    setStatusMessage('Assembling visual frames, audio voiceover & subtitle timing...');

    try {
      // Build scenes with TTS and images
      const compiledScenes: Scene[] = await Promise.all(
        sceneBreakdown.scenes.map(async (rawScene: any, idx: number) => {
          let sceneImgUrl = '';
          if (uploadedRefImage && idx === 0) {
            sceneImgUrl = uploadedRefImage;
          } else {
            sceneImgUrl = await createProceduralSceneCanvas(
              project.aspectRatio === '9:16' ? 720 : 1280,
              project.aspectRatio === '9:16' ? 1280 : 720,
              project.visualStyle,
              idx + 1,
              uploadedRefImage || undefined,
              rawScene.visualPrompt
            );
          }

          let audioBase64: string | undefined;
          try {
            const tts = await generateTTS({
              text: rawScene.narration,
              voice: project.ttsVoice || 'Kore',
            });
            if (tts.audioBase64) audioBase64 = tts.audioBase64;
          } catch {}

          return {
            id: `sc_story_${Date.now()}_${idx + 1}`,
            sceneNumber: idx + 1,
            duration: rawScene.duration || Math.round(duration / sceneBreakdown.scenes.length),
            narration: rawScene.narration,
            englishNarration: rawScene.englishNarration,
            dialogue: rawScene.dialogue || rawScene.narration,
            visualPrompt: rawScene.visualPrompt,
            videoPrompt: `${rawScene.visualPrompt}, camera ${rawScene.cameraMotion || 'cinematic-push'}, 4k cinema quality`,
            imageUrl: sceneImgUrl,
            cameraMotion: (rawScene.cameraMotion as CameraMotion) || 'zoom-in',
            motionStrength: rawScene.motionStrength || 7,
            soundEffect: (rawScene.soundEffect as SoundEffectType) || (idx === 0 ? 'temple_bell' : 'whoosh'),
            subtitles: rawScene.subtitles || [],
            audioBase64,
          };
        })
      );

      onApplyStoryToProject({
        title: generatedResult.title || project.title,
        language,
        storyType,
        targetDuration: duration,
        scenes: compiledScenes,
        updatedAt: Date.now(),
      });

      safeVibrate([30, 50, 40]);
    } catch (err: any) {
      console.error(err);
      setErrorMsg('Failed to compile story into video scenes');
    } finally {
      setIsLoading(false);
      setStatusMessage('');
    }
  };

  return (
    <div className="bg-[#0E121C] border border-gray-800 rounded-3xl p-4 sm:p-6 space-y-6 shadow-xl max-w-5xl mx-auto">
      {/* Title */}
      <div className="flex items-center justify-between border-b border-gray-800 pb-4">
        <div className="flex items-center gap-2.5">
          <div className="p-2.5 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 text-black shadow-lg shadow-orange-500/20">
            <BookOpen className="w-5 h-5 font-black" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base sm:text-lg font-bold text-white">AI Auto Story Generator</h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                Master Scriptwriter
              </span>
            </div>
            <p className="text-xs text-gray-400">
              Create an original story, scene-by-scene script, character descriptions, image/video prompts, dialogue, narration, camera directions, BGM & SFX in Bengali, Hindi, or English.
            </p>
          </div>
        </div>
      </div>

      {/* Language Quick Selector Chips */}
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Language:</span>
        {(['Bengali', 'Hindi', 'English'] as StoryLanguage[]).map((lang) => (
          <button
            key={lang}
            type="button"
            onClick={() => {
              safeVibrate(10);
              setLanguage(lang);
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              language === lang
                ? 'bg-amber-500 text-black shadow-md shadow-amber-500/20'
                : 'bg-[#151A26] text-gray-300 border border-gray-800 hover:border-gray-700'
            }`}
          >
            <span>{lang === 'Bengali' ? '🇧🇩 বাংলা' : lang === 'Hindi' ? '🇮🇳 हिंदी' : '🇬🇧 English'}</span>
          </button>
        ))}
      </div>

      {/* Auto Story From Image Banner */}
      <div className="bg-gradient-to-r from-amber-950/30 via-orange-950/20 to-[#121622] border border-amber-500/30 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImageSelect}
            className="hidden"
          />
          <div
            onClick={() => fileInputRef.current?.click()}
            className="w-16 h-16 rounded-xl bg-[#171D2D] border border-dashed border-amber-500/50 hover:border-amber-400 flex flex-col items-center justify-center cursor-pointer transition overflow-hidden flex-shrink-0"
          >
            {uploadedRefImage ? (
              <img src={uploadedRefImage} alt="Ref" className="w-full h-full object-cover" />
            ) : (
              <Upload className="w-5 h-5 text-amber-400" />
            )}
          </div>
          <div>
            <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
              AUTO STORY FROM IMAGE
            </h4>
            <p className="text-xs text-gray-400 max-w-sm">
              Upload any photo and let Gemini AI understand the subject and craft a compelling narrative.
            </p>
          </div>
        </div>

        <button
          onClick={() => handleGenerateStory(true)}
          disabled={isLoading || !uploadedRefImage}
          className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-black font-extrabold text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition disabled:opacity-50"
        >
          <Sparkles className="w-4 h-4 text-black" />
          <span>GENERATE FROM IMAGE</span>
        </button>
      </div>

      {/* Popular 1-Click Story Prompts */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between">
          <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider">
            1-Click Story Prompts
          </label>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {STORY_IDEAS.map((idea, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleApplyPresetIdea(idea)}
              className="px-3 py-1.5 rounded-xl bg-[#141926] border border-gray-800 hover:border-amber-500/50 text-left text-xs text-gray-300 hover:text-white transition flex items-center gap-1.5"
            >
              <Sparkles className="w-3 h-3 text-amber-400" />
              <span>{idea.label}: <em>"{idea.prompt.slice(0, 30)}..."</em></span>
            </button>
          ))}
        </div>
      </div>

      {/* Story Type & Duration */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Story Type */}
        <div className="space-y-1.5">
          <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider">
            Story Genre
          </label>
          <select
            value={storyType}
            onChange={(e) => setStoryType(e.target.value as StoryType)}
            className="w-full bg-[#151A26] border border-gray-700 focus:border-amber-500 rounded-xl p-3 text-sm text-white font-medium outline-none"
          >
            {STORY_TYPES.map((t) => (
              <option key={t.value} value={t.value}>
                {t.icon} {t.value} ({t.category})
              </option>
            ))}
          </select>
        </div>

        {/* Duration */}
        <div className="space-y-1.5">
          <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider">
            Duration
          </label>
          <div className="grid grid-cols-5 gap-1.5 pt-1">
            {[10, 20, 30, 40, 60].map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => setDuration(d)}
                className={`py-2 rounded-xl text-xs font-bold border transition ${
                  duration === d
                    ? 'bg-amber-500 text-black border-amber-400 shadow-md'
                    : 'bg-[#151A26] border-gray-700 text-gray-300 hover:text-white'
                }`}
              >
                {d}s
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* User Custom Story Input */}
      <div className="space-y-1.5">
        <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider">
          Story Concept or Prompt
        </label>
        <textarea
          rows={3}
          value={userStory}
          onChange={(e) => setUserStory(e.target.value)}
          placeholder="e.g. একটি বাঘ জঙ্গলে একটি শিশুকে বাঁচালো (A tiger saves a lost child in the deep forest)..."
          className="w-full bg-[#151A26] border border-gray-700 focus:border-amber-500 rounded-xl p-3 text-xs sm:text-sm text-gray-200 outline-none resize-none"
        />
      </div>

      {/* Action Button */}
      <div className="flex justify-end">
        <button
          onClick={() => handleGenerateStory(false)}
          disabled={isLoading}
          className="w-full sm:w-auto px-8 py-3 rounded-2xl bg-gradient-to-r from-amber-400 via-orange-500 to-red-500 hover:from-amber-300 hover:to-orange-400 text-black font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-orange-500/25 active:scale-95 transition disabled:opacity-50"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-black" />
              <span>{statusMessage || 'Directing Story & Scenes...'}</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 text-black" />
              <span>GENERATE COMPLETE AI STORY & DIRECTORIAL SCRIPT</span>
            </>
          )}
        </button>
      </div>

      {/* Error Notice */}
      {errorMsg && (
        <div className="bg-red-950/40 border border-red-500/40 rounded-xl p-3 text-xs text-red-300 flex items-center gap-2">
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Generated Story & Director's Breakdown Sheet */}
      {generatedResult && (
        <div className="bg-[#121622] border border-amber-500/40 rounded-2xl p-4 sm:p-6 space-y-6 shadow-xl">
          {/* Header */}
          <div className="flex items-start justify-between border-b border-gray-800 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 uppercase">
                  {language} • {storyType} • {duration}s
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Director's Sheet Ready
                </span>
              </div>
              <h4 className="text-lg sm:text-xl font-black text-white mt-1">
                {generatedResult.title}
              </h4>
              {generatedResult.englishTitle && (
                <p className="text-xs text-gray-400 italic mt-0.5">
                  Translation: {generatedResult.englishTitle}
                </p>
              )}
            </div>

            <button
              onClick={() => copyToClipboard(generatedResult.fullScript, 'fullScript')}
              className="p-2 rounded-xl bg-gray-800 text-gray-300 hover:text-white flex items-center gap-1 text-xs"
              title="Copy Story"
            >
              <Copy className="w-4 h-4" />
              <span className="hidden sm:inline">{copiedField === 'fullScript' ? 'Copied!' : 'Copy Script'}</span>
            </button>
          </div>

          {/* 1. Full Story Script */}
          <div className="space-y-1.5">
            <span className="text-xs font-bold text-gray-300 uppercase tracking-wider block">
              1. Original Story Script
            </span>
            <div className="bg-[#0A0D14] p-4 rounded-xl border border-gray-800/80">
              <p className="text-xs sm:text-sm text-gray-200 leading-relaxed font-medium whitespace-pre-line">
                {generatedResult.fullScript}
              </p>
            </div>
          </div>

          {/* 2. Character Descriptions */}
          {generatedResult.characterDescription && (
            <div className="space-y-1.5">
              <span className="text-xs font-bold text-gray-300 uppercase tracking-wider flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-amber-400" />
                <span>2. Character Descriptions & Key Attributes</span>
              </span>
              <div className="bg-[#0A0D14] p-3 rounded-xl border border-gray-800 text-xs text-gray-300">
                {generatedResult.characterDescription}
              </div>
            </div>
          )}

          {/* 3. Scene-by-Scene Breakdown (Dialogue, Narration, Camera, SFX, Prompts) */}
          {sceneBreakdown?.scenes && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-gray-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Film className="w-3.5 h-3.5 text-amber-400" />
                  <span>3. Scene-by-Scene Directorial Breakdown ({sceneBreakdown.scenes.length} Scenes)</span>
                </span>
              </div>

              <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
                {sceneBreakdown.scenes.map((sc: any, idx: number) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-xl bg-[#0B0E16] border border-gray-800 space-y-2 text-xs"
                  >
                    <div className="flex items-center justify-between border-b border-gray-800/80 pb-1.5">
                      <span className="font-extrabold text-amber-400">
                        Scene #{idx + 1} ({sc.duration || Math.round(duration / sceneBreakdown.scenes.length)}s)
                      </span>
                      <div className="flex items-center gap-2 text-[11px]">
                        <span className="text-indigo-300 flex items-center gap-1">
                          <Camera className="w-3 h-3" /> {sc.cameraMotion || 'Cinematic Push'}
                        </span>
                        <span className="text-emerald-300 flex items-center gap-1">
                          <Volume2 className="w-3 h-3" /> {sc.soundEffect || 'Whoosh'}
                        </span>
                      </div>
                    </div>

                    {/* Dialogue & Narration */}
                    <div className="space-y-1">
                      <p className="text-gray-200 font-medium">
                        <strong className="text-amber-300">Narration / Dialogue: </strong>
                        {sc.narration}
                      </p>
                    </div>

                    {/* Image & Video Prompts */}
                    <div className="space-y-1 text-[11px] text-gray-400 bg-[#121622] p-2.5 rounded-lg border border-gray-800">
                      <div>
                        <strong className="text-indigo-300">Image Prompt: </strong>
                        {sc.visualPrompt}
                      </div>
                      <div className="mt-1">
                        <strong className="text-purple-300">Video Prompt: </strong>
                        {sc.visualPrompt}, camera {sc.cameraMotion || 'cinematic push'}, 8k volumetric light
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Action to Apply */}
          <div className="flex justify-end pt-2">
            <button
              onClick={handleApplyToProject}
              disabled={isLoading}
              className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-black font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-95 transition"
            >
              <ArrowRight className="w-4 h-4 text-black" />
              <span>APPLY COMPLETE STORY & SCENES TO STUDIO TIMELINE</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
