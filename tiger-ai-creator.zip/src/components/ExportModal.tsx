import React, { useState } from 'react';
import {
  X,
  Download,
  CheckCircle2,
  AlertCircle,
  Loader2,
  ShieldCheck,
  Film,
  Sparkles,
  Share2,
} from 'lucide-react';
import { Project } from '../types';
import { EXPORT_RESOLUTIONS } from '../utils/constants';
import { videoCompositor } from '../services/videoRenderer';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: Project;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  project,
}) => {
  const [selectedRes, setSelectedRes] = useState<(typeof EXPORT_RESOLUTIONS)[1]>(
    EXPORT_RESOLUTIONS[1] // Full HD 1080p default
  );
  const [isWatermarkFree, setIsWatermarkFree] = useState<boolean>(true);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [progressPercent, setProgressPercent] = useState<number>(0);
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [downloadFileName, setDownloadFileName] = useState<string>('');

  if (!isOpen) return null;

  // Calculate actual resolution dimensions respecting aspect ratio
  const getOutputDimensions = () => {
    const baseW = selectedRes.width;
    const baseH = selectedRes.height;

    switch (project.aspectRatio) {
      case '9:16':
        return { w: Math.min(baseW, baseH), h: Math.max(baseW, baseH) };
      case '16:9':
        return { w: Math.max(baseW, baseH), h: Math.min(baseW, baseH) };
      case '1:1':
        const side = Math.min(baseW, baseH);
        return { w: side, h: side };
      case '4:5':
        return { w: 1080, h: 1350 };
      default:
        return { w: baseW, h: baseH };
    }
  };

  const handleStartExport = async () => {
    setIsExporting(true);
    setProgressPercent(0);
    setStatusMessage('Preparing frames and audio synthesizer...');
    setDownloadUrl(null);

    const dims = getOutputDimensions();

    try {
      const blob = await videoCompositor.exportVideo(
        project,
        dims.w,
        dims.h,
        !isWatermarkFree,
        (percent, status) => {
          setProgressPercent(percent);
          setStatusMessage(status);
        }
      );

      const url = URL.createObjectURL(blob);
      const cleanTitle = (project.title || 'tiger_video')
        .toLowerCase()
        .replace(/[^a-z0-9]/g, '_');
      const ext = blob.type.includes('mp4') ? 'mp4' : 'webm';
      const filename = `${cleanTitle}_${dims.w}x${dims.h}.${ext}`;

      setDownloadUrl(url);
      setDownloadFileName(filename);
      setStatusMessage('Export Complete! Ready to save to device gallery.');

      // Auto-trigger download
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      link.click();
    } catch (err: any) {
      console.error('Export failed:', err);
      setStatusMessage(`Export Error: ${err.message || 'Rendering failed'}`);
    } finally {
      setIsExporting(false);
    }
  };

  const dims = getOutputDimensions();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-5 overflow-y-auto">
      <div className="w-full max-w-lg bg-[#0E121C] border border-amber-500/30 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-amber-950/40 via-[#131926] to-[#0E121C] border-b border-amber-500/20 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 to-orange-600 flex items-center justify-center text-black font-extrabold shadow">
              <Download className="w-5 h-5 text-black" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-white">
                Export Master Video
              </h2>
              <p className="text-xs text-amber-400">
                Samsung Android High-Definition Video Render
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isExporting}
            className="p-1.5 rounded-lg bg-gray-800 text-gray-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 sm:p-6 space-y-4 overflow-y-auto">
          {/* Project Summary Banner */}
          <div className="bg-[#141926] p-3.5 rounded-xl border border-gray-800 flex items-center justify-between text-xs">
            <div>
              <div className="font-bold text-white truncate max-w-[200px]">
                {project.title}
              </div>
              <div className="text-gray-400">
                {project.scenes.length} Scenes • {project.scenes.reduce((a, s) => a + s.duration, 0)}s • Format: {project.aspectRatio}
              </div>
            </div>
            <span className="px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 font-mono font-bold border border-amber-500/30">
              {dims.w} × {dims.h}
            </span>
          </div>

          {/* Resolution Options */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider">
              Output Resolution
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {EXPORT_RESOLUTIONS.map((res) => {
                const isSelected = selectedRes.label === res.label;
                return (
                  <button
                    key={res.label}
                    type="button"
                    onClick={() => setSelectedRes(res)}
                    className={`p-3 rounded-xl border text-left transition ${
                      isSelected
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-sm'
                        : 'bg-[#141926] border-gray-800 text-gray-300 hover:border-gray-700'
                    }`}
                  >
                    <div className="text-xs font-bold text-white">{res.label}</div>
                    <div className="text-[10px] text-gray-400 mt-0.5">{res.note}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Watermark-Free & Commercial Use Options */}
          <div className="bg-[#141926] p-3.5 rounded-xl border border-gray-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-bold text-white">Watermark-Free Export</span>
              </div>
              <input
                type="checkbox"
                checked={isWatermarkFree}
                onChange={(e) => setIsWatermarkFree(e.target.checked)}
                className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
              />
            </div>
            <p className="text-[11px] text-gray-400">
              {isWatermarkFree
                ? '✓ 100% clean video export without brand watermarks. Permitted for social media monetization.'
                : '🐅 Video will include small subtle Tiger AI corner watermark.'}
            </p>
          </div>

          {/* Commercial Use Compliance Tag */}
          <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-emerald-950/30 border border-emerald-500/30 text-emerald-300 text-[11px]">
            <CheckCircle2 className="w-4 h-4 flex-shrink-0 text-emerald-400" />
            <span>
              Royalty-free background music & synthesized voice included for commercial-use workflow.
            </span>
          </div>

          {/* Real-Time Progress Bar if exporting */}
          {isExporting && (
            <div className="space-y-2 pt-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-amber-400 animate-pulse">{statusMessage}</span>
                <span className="font-mono font-bold text-white">{progressPercent}%</span>
              </div>
              <div className="w-full bg-gray-800 rounded-full h-2.5 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-amber-500 to-yellow-400 h-full transition-all duration-200"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>
          )}

          {/* Download ready button */}
          {downloadUrl && (
            <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-center space-y-2">
              <p className="text-xs font-bold text-emerald-300">
                🎉 Video Rendered Successfully!
              </p>
              <a
                href={downloadUrl}
                download={downloadFileName}
                className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs shadow transition"
              >
                <Download className="w-4 h-4" />
                Download {downloadFileName}
              </a>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#0A0D14] border-t border-gray-800 flex items-center justify-between gap-3">
          <button
            onClick={onClose}
            disabled={isExporting}
            className="px-4 py-2.5 rounded-xl bg-gray-800 text-gray-300 font-semibold text-xs hover:text-white transition"
          >
            Close
          </button>

          <button
            onClick={handleStartExport}
            disabled={isExporting}
            className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-400 via-orange-500 to-red-500 hover:from-amber-300 hover:to-orange-400 text-black font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md active:scale-95 transition disabled:opacity-50"
          >
            {isExporting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-black" />
                <span>RENDERING ({progressPercent}%)...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-black" />
                <span>RENDER & EXPORT NOW</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
