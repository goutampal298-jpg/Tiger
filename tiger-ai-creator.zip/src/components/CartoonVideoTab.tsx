import React, { useState } from 'react';
import {
  Palette,
  Sparkles,
  Film,
  Smile,
  Volume2,
  Subtitles,
  Music,
  ArrowRight,
  Loader2,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import {
  AspectRatio,
  BgmGenre,
  CameraMotion,
  CartoonMode,
  Project,
  Scene,
  SoundEffectType,
  StoryLanguage,
  SubtitlePreset,
} from '../types';
import { CARTOON_MODES } from '../utils/constants';
import { createProceduralSceneCanvas, generateImage, generateStory, generateTTS } from '../services/geminiService';
import { safeVibrate } from '../utils/haptics';

interface CartoonVideoTabProps {
  project: Project;
  onApplyCartoonProject: (newProject: Partial<Project>) => void;
  onSwitchToStudio: () => void;
}

const CARTOON_CHARACTERS = [
  { id: 'tiger_cub', name: 'Sheru the Tiger Cub', icon: '🐯', desc: 'Brave, cheerful striped cub with sparkling curious amber eyes' },
  { id: 'baby_elephant', name: 'Gajraj Little Elephant', icon: '🐘', desc: 'Gentle, wise young calf with golden bells & lotus flower' },
  { id: 'friendly_robot', name: 'Chotu the Tiny Bot', icon: '🤖', desc: 'Bubbly helpful blue robot with glowing heart LED antenna' },
  { id: 'curious_child', name: 'Aarav/Misti Explorer', icon: '🧒', desc: 'Adventurous smiling kid in colorful sneakers & canvas backpack' },
  { id: 'magical_bird', name: 'Neelkanth Blue Wing', icon: '🦜', desc: 'Whimsical speaking parrot with rainbow tail feathers' },
];

const CARTOON_PROMPT_IDEAS = [
  {
    title: 'Sundarbans Tiger Cub Adventure',
    prompt: 'A cheerful baby tiger cub helps a lost baby monkey find its mother across a magical glowing river',
    language: 'Bengali' as StoryLanguage,
  },
  {
    title: 'Cloud Castle Festival',
    prompt: 'Friendly animal friends build a colorful balloon bridge to attend the annual star festival in the sky',
    language: 'Hindi' as StoryLanguage,
  },
  {
    title: 'The Talking Tree of Wishes',
    prompt: 'Two kind siblings discover an ancient smiling banyan tree that blooms whenever children share their toys',
    language: 'English' as StoryLanguage,
  },
];

export const CartoonVideoTab: React.FC<CartoonVideoTabProps> = ({
  project,
  onApplyCartoonProject,
  onSwitchToStudio,
}) => {
  const [cartoonMode, setCartoonMode] = useState<CartoonMode>('3D Cartoon');
  const [characterArchetype, setCharacterArchetype] = useState<string>('tiger_cub');
  const [prompt, setPrompt] = useState<string>(CARTOON_PROMPT_IDEAS[0].prompt);
  const [language, setLanguage] = useState<StoryLanguage>(project.language);
  const [duration, setDuration] = useState<number>(30);
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>(project.aspectRatio);

  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [statusText, setStatusText] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleApplyPresetIdea = (idea: typeof CARTOON_PROMPT_IDEAS[0]) => {
    safeVibrate(10);
    setPrompt(idea.prompt);
    setLanguage(idea.language);
  };

  const handleGenerateCartoonVideo = async () => {
    if (!prompt.trim()) {
      setErrorMessage('Please enter a cartoon story premise or select an idea.');
      return;
    }

    setIsGenerating(true);
    setErrorMessage(null);
    safeVibrate(25);
    setStatusText(`Directing ${cartoonMode} AI story in ${language}...`);

    try {
      const selectedChar = CARTOON_CHARACTERS.find((c) => c.id === characterArchetype);

      // Step 1: Generate Cartoon Story
      const storyRes = await generateStory({
        language,
        storyType: 'Kids',
        durationSeconds: duration,
        userStory: `${cartoonMode} Animation: ${prompt}. Featuring character: ${selectedChar?.name} (${selectedChar?.desc}). Ensure heartwarming, humorous dialogue and family-safe moral values.`,
      });

      setStatusText(`Writing scene breakdown and cartoon animation cues...`);

      const sceneCount = Math.max(3, Math.min(6, Math.round(duration / 5)));
      const rawScenes = storyRes.fullScript.split(/\n\n+/).filter((s) => s.trim().length > 10);

      const motions: CameraMotion[] = ['zoom-in', 'pan-right', 'cinematic-push', 'slow-motion', 'tilt-up'];
      const sfxList: SoundEffectType[] = ['magic_sparkle', 'whoosh', 'divine_chime', 'temple_bell'];

      const generatedScenes: Scene[] = [];

      for (let i = 0; i < sceneCount; i++) {
        const sceneNum = i + 1;
        setStatusText(`Creating cartoon frame ${sceneNum}/${sceneCount}...`);

        const narrationText = rawScenes[i] || `${storyRes.title}: Scene ${sceneNum} brings magical laughter and joy.`;
        const visualDesc = `${cartoonMode} aesthetic, ${selectedChar?.name}, ${selectedChar?.desc}, ${prompt}, whimsical vibrant colors, clean stylized contours, family-friendly cartoon film still, master lighting, 8k quality`;

        let imageUrl = '';
        try {
          const img = await generateImage({
            prompt: visualDesc,
            aspectRatio,
            visualStyle: 'Cartoon',
          });
          imageUrl = img.imageUrl || '';
        } catch {}

        if (!imageUrl) {
          imageUrl = await createProceduralSceneCanvas(
            aspectRatio === '9:16' ? 720 : 1280,
            aspectRatio === '9:16' ? 1280 : 720,
            'Cartoon',
            sceneNum,
            undefined,
            visualDesc
          );
        }

        let audioBase64: string | undefined;
        try {
          const tts = await generateTTS({
            text: narrationText,
            voice: 'Puck', // Youthful and energetic
          });
          if (tts.audioBase64) audioBase64 = tts.audioBase64;
        } catch {}

        generatedScenes.push({
          id: `sc_cartoon_${Date.now()}_${sceneNum}`,
          sceneNumber: sceneNum,
          duration: Math.round(duration / sceneCount),
          narration: narrationText,
          englishNarration: narrationText,
          visualPrompt: visualDesc,
          imageUrl,
          cameraMotion: motions[i % motions.length],
          motionStrength: 6,
          soundEffect: sfxList[i % sfxList.length],
          subtitles: [],
          audioBase64,
        });

        safeVibrate(15);
      }

      // Step 2: Apply to project
      onApplyCartoonProject({
        title: storyRes.title || 'Magical Cartoon Adventure',
        language,
        storyType: 'Kids',
        visualStyle: 'Cartoon',
        aspectRatio,
        targetDuration: duration,
        bgmGenre: 'Funny Cartoon Bouncy',
        subtitlePreset: 'comic-pop',
        ttsVoice: 'Puck',
        scenes: generatedScenes,
        characterReference: {
          id: `char_cartoon_${Date.now()}`,
          name: selectedChar?.name || 'Cartoon Hero',
          imageBase64: generatedScenes[0]?.imageUrl || '',
          genderOrForm: selectedChar?.name,
          clothing: 'Vibrant stylized animated attire',
          keyIdentifiers: selectedChar?.desc,
          locked: true,
        },
        updatedAt: Date.now(),
      });

      safeVibrate([30, 50, 40]);
      onSwitchToStudio();
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || 'Cartoon video generation failed.');
    } finally {
      setIsGenerating(false);
      setStatusText('');
    }
  };

  return (
    <div className="bg-[#0E121C] border border-gray-800 rounded-3xl p-4 sm:p-6 space-y-6 shadow-xl max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-gray-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-gradient-to-br from-pink-500 via-amber-400 to-yellow-400 text-black shadow-lg shadow-pink-500/20">
            <Palette className="w-5 h-5 font-black" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base sm:text-lg font-bold text-white">Cartoon AI Video Studio</h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-pink-500/20 text-pink-300 border border-pink-500/30">
                Original Animation
              </span>
            </div>
            <p className="text-xs text-gray-400">
              Create 2D, 3D, Anime, Kids, Comic, or Talking Cartoon videos with consistent characters and playful sound effects.
            </p>
          </div>
        </div>
      </div>

      {/* Cartoon Mode Selection Grid */}
      <div className="space-y-2">
        <label className="text-xs font-bold text-gray-300 uppercase tracking-wider">
          1. Select Cartoon Style Mode
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
          {CARTOON_MODES.map((cm) => (
            <button
              key={cm.id}
              type="button"
              onClick={() => {
                safeVibrate(10);
                setCartoonMode(cm.id as CartoonMode);
              }}
              className={`p-2.5 rounded-xl border text-left transition ${
                cartoonMode === cm.id
                  ? 'bg-gradient-to-b from-pink-500/20 to-amber-500/10 border-pink-500 text-white shadow-md'
                  : 'bg-[#121622] border-gray-800 text-gray-400 hover:border-gray-700'
              }`}
            >
              <div className="text-lg mb-1">{cm.icon}</div>
              <div className="text-xs font-bold text-white truncate">{cm.label}</div>
              <div className="text-[10px] text-gray-400 line-clamp-1 mt-0.5">{cm.desc}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Character Archetype */}
      <div className="space-y-2">
        <label className="text-xs font-bold text-gray-300 uppercase tracking-wider">
          2. Choose Lead Cartoon Character
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2">
          {CARTOON_CHARACTERS.map((char) => (
            <button
              key={char.id}
              type="button"
              onClick={() => {
                safeVibrate(10);
                setCharacterArchetype(char.id);
              }}
              className={`p-2.5 rounded-xl border text-left transition flex items-center gap-2.5 ${
                characterArchetype === char.id
                  ? 'bg-amber-500/15 border-amber-500 text-white shadow-md'
                  : 'bg-[#121622] border-gray-800 text-gray-400 hover:border-gray-700'
              }`}
            >
              <span className="text-2xl">{char.icon}</span>
              <div className="min-w-0">
                <div className="text-xs font-bold text-white truncate">{char.name}</div>
                <div className="text-[10px] text-gray-400 truncate">{char.desc}</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Story Idea / Prompt Input with Quick Chips */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-gray-300 uppercase tracking-wider">
            3. Cartoon Story Premise
          </label>
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] text-gray-400">Quick Ideas:</span>
            {CARTOON_PROMPT_IDEAS.map((idea, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleApplyPresetIdea(idea)}
                className="px-2 py-0.5 rounded-md bg-gray-800 hover:bg-gray-700 text-amber-300 text-[10px] font-semibold transition"
              >
                {idea.title.split(' ')[0]} ({idea.language})
              </button>
            ))}
          </div>
        </div>
        <textarea
          rows={3}
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Describe your cartoon story idea (e.g. Baby tiger cub learns to share mangoes with friends in a whimsical jungle)..."
          className="w-full bg-[#121622] border border-gray-700 focus:border-pink-500 rounded-2xl p-3 text-xs sm:text-sm text-white outline-none resize-none"
        />
      </div>

      {/* Configuration Settings */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Language */}
        <div className="space-y-1">
          <label className="text-xs font-bold text-gray-300">Narration Language</label>
          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value as StoryLanguage)}
            className="w-full bg-[#121622] border border-gray-700 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-white outline-none"
          >
            <option value="Bengali">Bengali (বাংলা)</option>
            <option value="Hindi">Hindi (हिंदी)</option>
            <option value="English">English</option>
          </select>
        </div>

        {/* Duration */}
        <div className="space-y-1">
          <label className="text-xs font-bold text-gray-300">Animation Duration</label>
          <select
            value={duration}
            onChange={(e) => setDuration(parseInt(e.target.value))}
            className="w-full bg-[#121622] border border-gray-700 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-white outline-none"
          >
            <option value={10}>10 Seconds (Quick Reel)</option>
            <option value={20}>20 Seconds (Short Story)</option>
            <option value={30}>30 Seconds (Standard Episode)</option>
            <option value={60}>60 Seconds (Full Cartoon Arc)</option>
          </select>
        </div>

        {/* Aspect Ratio */}
        <div className="space-y-1">
          <label className="text-xs font-bold text-gray-300">Video Aspect Ratio</label>
          <select
            value={aspectRatio}
            onChange={(e) => setAspectRatio(e.target.value as AspectRatio)}
            className="w-full bg-[#121622] border border-gray-700 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-white outline-none"
          >
            <option value="9:16">9:16 Vertical Shorts / Reels</option>
            <option value="16:9">16:9 Horizontal YouTube</option>
            <option value="1:1">1:1 Square Feed</option>
          </select>
        </div>
      </div>

      {/* Error Message */}
      {errorMessage && (
        <div className="bg-red-950/40 border border-red-500/40 rounded-xl p-3 text-xs text-red-300 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Action Button */}
      <div>
        <button
          onClick={handleGenerateCartoonVideo}
          disabled={isGenerating}
          className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-pink-500 via-amber-400 to-yellow-400 hover:from-pink-400 hover:to-yellow-300 text-black font-black text-sm shadow-xl shadow-pink-500/20 transition active:scale-98 flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {isGenerating ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-black" />
              <span>{statusText || 'Rendering Cartoon Animation...'}</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 text-black" />
              <span>Generate {cartoonMode} Video & Open Studio</span>
              <ArrowRight className="w-4 h-4 text-black ml-1" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};
