import React, { useState } from 'react';
import {
  FolderKanban,
  Play,
  Copy,
  Trash2,
  Edit2,
  Download,
  Plus,
  Clock,
  CheckCircle2,
  RotateCcw,
  AlertTriangle,
  Film,
  Layers,
  Sparkles,
} from 'lucide-react';
import { BatchQueueTask, Project } from '../types';
import { safeVibrate } from '../utils/haptics';

interface ProjectsScreenProps {
  projects: Project[];
  activeProjectId: string;
  queueTasks: BatchQueueTask[];
  appLanguage: 'bn' | 'en';
  onOpenProject: (projectId: string) => void;
  onNewProject: () => void;
  onDuplicateProject: (projectId: string) => void;
  onDeleteProject: (projectId: string) => void;
  onRenameProject: (projectId: string, newTitle: string) => void;
  onExportProject: (project: Project) => void;
  onRetryTask: (taskId: string) => void;
  onCancelTask: (taskId: string) => void;
}

export const ProjectsScreen: React.FC<ProjectsScreenProps> = ({
  projects,
  activeProjectId,
  queueTasks,
  appLanguage,
  onOpenProject,
  onNewProject,
  onDuplicateProject,
  onDeleteProject,
  onRenameProject,
  onExportProject,
  onRetryTask,
  onCancelTask,
}) => {
  const isBn = appLanguage === 'bn';
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState<string>('');

  const handleStartRename = (project: Project) => {
    safeVibrate(10);
    setEditingId(project.id);
    setEditTitle(project.title);
  };

  const handleSaveRename = (projectId: string) => {
    if (editTitle.trim()) {
      onRenameProject(projectId, editTitle.trim());
    }
    setEditingId(null);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-gray-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400">
              <FolderKanban className="w-5 h-5" />
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              {isBn ? 'প্রজেক্ট হিস্ট্রি ও ড্রাফটস' : 'Project History & Saved Drafts'}
            </h2>
          </div>
          <p className="text-xs text-gray-400 mt-1">
            {isBn
              ? 'অটো-সেভ সক্রিয় রয়েছে — আপনার সমস্ত তৈরি করা দৃশ্য এবং স্ক্রিপ্ট নিরাপদে সংরক্ষিত।'
              : 'Auto-save is active — all scenes, audio settings, and characters are stored safely.'}
          </p>
        </div>

        <button
          onClick={() => {
            safeVibrate(15);
            onNewProject();
          }}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-black font-extrabold text-xs flex items-center gap-1.5 shadow-md active:scale-95 transition"
        >
          <Plus className="w-4 h-4 text-black" />
          <span>{isBn ? 'নতুন প্রজেক্ট' : 'New Project'}</span>
        </button>
      </div>

      {/* Batch Processing Queue Banner */}
      {queueTasks.length > 0 && (
        <div className="bg-[#121724] border border-amber-500/30 rounded-2xl p-4 space-y-3 shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                {isBn ? 'ব্যাচ জেনারেশন কিউ' : 'Batch Generation Queue'} ({queueTasks.length})
              </h4>
            </div>
          </div>

          <div className="space-y-2">
            {queueTasks.map((task) => (
              <div
                key={task.id}
                className="p-2.5 rounded-xl bg-[#0B0E16] border border-gray-800 flex items-center justify-between gap-3 text-xs"
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white truncate">{task.title}</span>
                    <span
                      className={`px-1.5 py-0.2 rounded text-[9px] uppercase font-bold ${
                        task.status === 'completed'
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : task.status === 'processing'
                          ? 'bg-amber-500/20 text-amber-300 animate-pulse'
                          : task.status === 'failed'
                          ? 'bg-red-500/20 text-red-400'
                          : 'bg-gray-800 text-gray-400'
                      }`}
                    >
                      {task.status}
                    </span>
                  </div>
                  {task.status === 'processing' && (
                    <div className="w-full bg-gray-800 h-1.5 rounded-full mt-1.5 overflow-hidden">
                      <div
                        className="bg-amber-500 h-full transition-all duration-300"
                        style={{ width: `${task.progress}%` }}
                      />
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-1.5">
                  {task.status === 'failed' && (
                    <button
                      onClick={() => onRetryTask(task.id)}
                      className="p-1 rounded-lg bg-amber-500/20 text-amber-400 hover:bg-amber-500/30 text-[10px] font-bold flex items-center gap-1 px-2"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Retry</span>
                    </button>
                  )}
                  {task.status === 'processing' && (
                    <button
                      onClick={() => onCancelTask(task.id)}
                      className="p-1 rounded-lg bg-gray-800 text-gray-400 hover:text-white text-[10px] px-2"
                    >
                      Cancel
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Projects List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {projects.map((proj) => {
          const isActive = proj.id === activeProjectId;
          return (
            <div
              key={proj.id}
              className={`rounded-3xl p-5 border transition shadow-xl space-y-4 flex flex-col justify-between ${
                isActive
                  ? 'bg-[#121724] border-amber-500/60 shadow-amber-500/10'
                  : 'bg-[#0E121C] border-gray-800 hover:border-gray-700'
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">🐅</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30">
                      {proj.language} • {proj.aspectRatio}
                    </span>
                  </div>

                  {isActive && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      {isBn ? 'সক্রিয়' : 'Active'}
                    </span>
                  )}
                </div>

                {editingId === proj.id ? (
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={editTitle}
                      onChange={(e) => setEditTitle(e.target.value)}
                      className="flex-1 bg-[#151A26] border border-amber-500 rounded-xl px-2.5 py-1.5 text-xs text-white outline-none"
                    />
                    <button
                      onClick={() => handleSaveRename(proj.id)}
                      className="px-3 py-1.5 rounded-xl bg-amber-500 text-black text-xs font-bold"
                    >
                      Save
                    </button>
                  </div>
                ) : (
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center justify-between">
                      <span className="truncate">{proj.title}</span>
                      <button
                        onClick={() => handleStartRename(proj)}
                        className="p-1 rounded text-gray-500 hover:text-white"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                    </h3>
                    <p className="text-xs text-gray-400 line-clamp-2 mt-1">
                      {proj.scenes[0]?.narration || 'No scenes yet'}
                    </p>
                  </div>
                )}

                <div className="flex items-center gap-3 text-[11px] text-gray-500 font-mono">
                  <span>🎬 {proj.scenes.length} {isBn ? 'দৃশ্য' : 'scenes'}</span>
                  <span>⏱️ {proj.targetDuration}s</span>
                  <span>🎨 {proj.visualStyle}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-gray-800/80 flex items-center justify-between gap-2">
                <button
                  onClick={() => {
                    safeVibrate(15);
                    onOpenProject(proj.id);
                  }}
                  className="flex-1 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-xs flex items-center justify-center gap-1.5 transition active:scale-95"
                >
                  <Play className="w-3.5 h-3.5 fill-black" />
                  <span>{isBn ? 'খুলুন' : 'Open in Studio'}</span>
                </button>

                <button
                  onClick={() => {
                    safeVibrate(10);
                    onDuplicateProject(proj.id);
                  }}
                  title="Duplicate Project"
                  className="p-2 rounded-xl bg-[#171D2D] hover:bg-gray-800 text-gray-300 hover:text-white border border-gray-800"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => {
                    safeVibrate(10);
                    onExportProject(proj);
                  }}
                  title="Export Video"
                  className="p-2 rounded-xl bg-[#171D2D] hover:bg-gray-800 text-amber-400 hover:text-amber-300 border border-gray-800"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => {
                    safeVibrate(10);
                    onDeleteProject(proj.id);
                  }}
                  title="Delete Project"
                  disabled={projects.length <= 1}
                  className="p-2 rounded-xl bg-[#171D2D] hover:bg-red-950/40 text-gray-500 hover:text-red-400 border border-gray-800 disabled:opacity-30"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
