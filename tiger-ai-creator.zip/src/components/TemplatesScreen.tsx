import React, { useState } from 'react';
import {
  Layers,
  Sparkles,
  Clock,
  Film,
  Search,
  Check,
  Flame,
  BookOpen,
  Palette,
  Ghost,
  Gamepad2,
  Tv,
  HelpCircle,
  Lightbulb,
} from 'lucide-react';
import { TemplateCategory, VideoTemplate } from '../types';
import { TEMPLATE_LIBRARY } from '../utils/constants';
import { safeVibrate } from '../utils/haptics';

interface TemplatesScreenProps {
  appLanguage: 'bn' | 'en';
  onSelectTemplate: (template: VideoTemplate) => void;
}

const CATEGORIES: { id: TemplateCategory | 'all'; labelEn: string; labelBn: string; icon: string }[] = [
  { id: 'all', labelEn: 'All Templates', labelBn: 'সব টেমপ্লেট', icon: '✨' },
  { id: 'story', labelEn: 'Story', labelBn: 'গল্প', icon: '📖' },
  { id: 'cartoon', labelEn: 'Cartoon', labelBn: 'কার্টুন', icon: '🎨' },
  { id: 'horror', labelEn: 'Horror', labelBn: 'হরর / ভূত', icon: '👻' },
  { id: 'devotional', labelEn: 'Devotional', labelBn: 'ভক্তি / পূজা', icon: '🪔' },
  { id: 'gaming', labelEn: 'Gaming', labelBn: 'গেমিং', icon: '🎮' },
  { id: 'shorts', labelEn: 'YouTube Shorts', labelBn: 'শর্টস', icon: '📱' },
  { id: 'motivational', labelEn: 'Motivational', labelBn: 'অনুপ্রেরণা', icon: '🔥' },
  { id: 'educational', labelEn: 'Educational', labelBn: 'শিক্ষামূলক', icon: '🎓' },
];

export const TemplatesScreen: React.FC<TemplatesScreenProps> = ({
  appLanguage,
  onSelectTemplate,
}) => {
  const isBn = appLanguage === 'bn';
  const [selectedCategory, setSelectedCategory] = useState<TemplateCategory | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filtered = TEMPLATE_LIBRARY.filter((tpl) => {
    if (selectedCategory !== 'all' && tpl.category !== selectedCategory) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = tpl.title.toLowerCase().includes(q);
      const matchBn = tpl.bengaliTitle.toLowerCase().includes(q);
      const matchTags = tpl.tags.some((t) => t.toLowerCase().includes(q));
      return matchTitle || matchBn || matchTags;
    }
    return true;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-300 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-gray-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400">
              <Layers className="w-5 h-5" />
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              {isBn ? 'রেডিমেড ভিডিও টেমপ্লেট লাইব্রেরি' : 'Ready-to-Use Template Library'}
            </h2>
          </div>
          <p className="text-xs text-gray-400 mt-1">
            {isBn
              ? 'গল্প, কার্টুন, হরর, ভক্তিগীতি, গেমিং ও ভাইরাল শর্টস এর জন্য পূর্বনির্ধারিত প্রম্পট ও অডিও সেটআপ'
              : 'Curated viral presets for Bengali storytelling, animation, devotion, gaming, and shorts'}
          </p>
        </div>

        {/* Search Input */}
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isBn ? 'টেমপ্লেট খুঁজুন...' : 'Search templates...'}
            className="w-full bg-[#0E121C] border border-gray-800 focus:border-amber-500 rounded-xl pl-9 pr-3 py-2 text-xs text-white outline-none"
          />
        </div>
      </div>

      {/* Categories Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {CATEGORIES.map((cat) => {
          const isSelected = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => {
                safeVibrate(10);
                setSelectedCategory(cat.id);
              }}
              className={`px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-1.5 transition flex-shrink-0 border ${
                isSelected
                  ? 'bg-amber-500 text-black border-amber-400 shadow-md shadow-orange-500/20'
                  : 'bg-[#0E121C] border-gray-800 text-gray-400 hover:text-white'
              }`}
            >
              <span>{cat.icon}</span>
              <span>{isBn ? cat.labelBn : cat.labelEn}</span>
            </button>
          );
        })}
      </div>

      {/* Templates Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((tpl) => (
          <div
            key={tpl.id}
            className="bg-[#0E121C] border border-gray-800 hover:border-amber-500/50 rounded-3xl p-5 space-y-4 shadow-xl flex flex-col justify-between group transition"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-2xl bg-[#151B2A] border border-gray-700/80 flex items-center justify-center text-2xl shadow-inner group-hover:scale-110 transition-transform">
                  {tpl.thumbnailEmoji}
                </div>
                <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  {tpl.category}
                </span>
              </div>

              <div>
                <h3 className="text-sm sm:text-base font-bold text-white group-hover:text-amber-300 transition">
                  {isBn ? tpl.bengaliTitle : tpl.title}
                </h3>
                <p className="text-xs text-gray-300 font-tiro mt-1 line-clamp-2">
                  {tpl.bengaliPromptIdea}
                </p>
                <p className="text-[11px] text-gray-400 mt-1 line-clamp-2">
                  {tpl.description}
                </p>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-1 pt-1">
                {tpl.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-2 py-0.5 rounded-md text-[10px] bg-[#141A28] text-gray-400 border border-gray-800"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-gray-800/80 space-y-3">
              <div className="flex items-center justify-between text-[11px] text-gray-400 font-mono">
                <span>⏱️ {tpl.duration}s</span>
                <span>📐 {tpl.aspectRatio}</span>
                <span>🎨 {tpl.visualStyle}</span>
              </div>

              <button
                onClick={() => {
                  safeVibrate(15);
                  onSelectTemplate(tpl);
                }}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-black font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-md transition active:scale-95"
              >
                <Sparkles className="w-3.5 h-3.5 text-black" />
                <span>{isBn ? 'এই টেমপ্লেট নিয়ে শুরু করুন' : 'USE THIS TEMPLATE'}</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
