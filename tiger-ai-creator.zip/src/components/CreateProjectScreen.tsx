import React, { useState } from 'react';
import {
  Sparkles,
  Upload,
  User,
  Music,
  Mic,
  Subtitles,
  Maximize2,
  Clock,
  Layers,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Play,
  RotateCcw,
  Sliders,
  ChevronRight,
  Flame,
  Volume2,
  Palette,
  ShieldCheck,
} from 'lucide-react';
import {
  AspectRatio,
  BgmGenre,
  CharacterReference,
  Project,
  Scene,
  StoryLanguage,
  StoryType,
  VideoResolution,
  VisualStyle,
} from '../types';
import {
  BGM_GENRES,
  STORY_LANGUAGES,
  STORY_TYPES,
  VISUAL_STYLES,
  TTS_VOICES,
  VIDEO_RESOLUTIONS_OPTIONS,
} from '../utils/constants';
import {
  analyzeImage,
  breakScenes,
  generateImage,
  generateStory,
  generateTTS,
  createProceduralSceneCanvas,
} from '../services/geminiService';
import { safeVibrate } from '../utils/haptics';

interface CreateProjectScreenProps {
  project: Project;
  appLanguage: 'bn' | 'en';
  onCompleteProject: (newProject: Project) => void;
  onNavigateToStudio: () => void;
}

const STAGES = [
  { step: 1, nameEn: 'Creating Story', nameBn: 'গল্প রচনা' },
  { step: 2, nameEn: 'Creating Characters', nameBn: 'চরিত্র লক' },
  { step: 3, nameEn: 'Creating Scenes', nameBn: 'দৃশ্য বিন্যাস' },
  { step: 4, nameEn: 'Generating Visuals', nameBn: 'এআই ভিজ্যুয়াল' },
  { step: 5, nameEn: 'Generating Voice', nameBn: 'বাংলা ভয়েস' },
  { step: 6, nameEn: 'Adding Music', nameBn: 'ব্যাকগ্রাউন্ড মিউজিক' },
  { step: 7, nameEn: 'Syncing Lip Movement', nameBn: 'লিপ-সিঙ্ক' },
  { step: 8, nameEn: 'Creating Subtitles', nameBn: 'সাবটাইটেল' },
  { step: 9, nameEn: 'Rendering Final Video', nameBn: 'ফাইনাল রেন্ডারিং' },
];

export const CreateProjectScreen: React.FC<CreateProjectScreenProps> = ({
  project,
  appLanguage,
  onCompleteProject,
  onNavigateToStudio,
}) => {
  const isBn = appLanguage === 'bn';

  // Core Inputs
  const [promptInput, setPromptInput] = useState<string>(
    'একটি বাঘ জঙ্গলে একটি শিশুকে বাঁচালো'
  );
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);

  // Character Lock
  const [enableCharacterLock, setEnableCharacterLock] = useState<boolean>(true);
  const [charName, setCharName] = useState<string>('রয়্যাল বাঘ / সাহসি চরিত্র');
  const [charAttire, setCharAttire] = useState<string>('Golden traditional attire with spiritual glow');

  // Styles & Voice
  const [language, setLanguage] = useState<StoryLanguage>('Bengali');
  const [storyGenre, setStoryGenre] = useState<StoryType>('Moral story');
  const [visualStyle, setVisualStyle] = useState<VisualStyle>('Cinematic');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('9:16');
  const [duration, setDuration] = useState<number>(30);
  const [resolution, setResolution] = useState<VideoResolution>('1080p');

  // Audio & Subtitle
  const [selectedVoice, setSelectedVoice] = useState<string>('Kore');
  const [voiceGender, setVoiceGender] = useState<'male' | 'female'>('female');
  const [voiceStyle, setVoiceStyle] = useState<string>('storyteller');
  const [bgmGenre, setBgmGenre] = useState<BgmGenre>('Cinematic Orchestral');
  const [bgmVolume, setBgmVolume] = useState<number>(0.3);
  const [voiceVolume, setVoiceVolume] = useState<number>(1.0);
  const [subtitlesEnabled, setSubtitlesEnabled] = useState<boolean>(true);

  // Generation Progress & State
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [currentStage, setCurrentStage] = useState<number>(0);
  const [stageDetails, setStageDetails] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isDone, setIsDone] = useState<boolean>(false);

  // Bengali Prompt Suggestions
  const samplePrompts = [
    { label: 'বাঘ ও শিশু', text: 'একটি বাঘ সুন্দরবনের গভীর জঙ্গলে একটি শিশুকে খরস্রোতা নদী থেকে বাঁচালো' },
    { label: 'শ্রীকৃষ্ণের মোহন বাঁশি', text: 'বৃন্দাবনে যমুনার তীরে শ্রীকৃষ্ণের দিব্য বাঁশির সুরে বনলতা ও ময়ূরের নৃত্য' },
    { label: 'রাতের বটগাছ (হরর)', text: 'নিঝুম অমাবস্যার রাতে গ্রামের পুরনো বটগাছ থেকে ভেসে আসা রহস্যময় অচেনা কণ্ঠস্বর' },
    { label: 'বান্টু ও জাদুকরী আম', text: 'একটি চঞ্চল মিষ্টি ছেলে বাগানে একটি সোনালী জাদুকরী কথা বলা আম খুঁজে পেল' },
  ];

  // 1-Tap Complete Video Pipeline
  const handleCreateCompleteVideo = async () => {
    if (!promptInput.trim() && !uploadedImage) {
      setErrorMsg('Please enter a prompt idea or upload an image.');
      return;
    }

    setIsGenerating(true);
    setIsDone(false);
    setErrorMsg(null);
    setCurrentStage(1);
    safeVibrate(20);

    try {
      // Stage 1: Creating Story
      setStageDetails('Synthesizing narrative script with Gemini Flash in Bengali/English...');
      let imageAnalysis = null;
      if (uploadedImage) {
        setStageDetails('Analyzing character visual anchor and setting from photo...');
        try {
          imageAnalysis = await analyzeImage(uploadedImage);
        } catch (e: any) {
          console.warn('Image analysis fallback active:', e.message);
        }
      }

      const generatedStory = await generateStory({
        language,
        storyType: storyGenre,
        durationSeconds: duration,
        userStory: promptInput,
        imageAnalysis,
      });

      // Stage 2: Creating Characters (Character Lock)
      setCurrentStage(2);
      setStageDetails('Locking character facial contours, skin tone, hair & wardrobe consistency...');
      const charRef: CharacterReference = {
        id: `char_${Date.now()}`,
        name: charName,
        imageBase64: uploadedImage || '',
        clothing: charAttire,
        hairStyle: 'Consistent narrative hair styling',
        skinTone: 'Warm golden / natural skin tone',
        locked: enableCharacterLock,
      };

      // Stage 3: Creating Scenes
      setCurrentStage(3);
      setStageDetails('Breaking narrative into sequential cinematic shots with camera movements...');
      const sceneBreakdown = await breakScenes({
        story: {
          title: generatedStory.title || 'Tiger AI Story',
          fullScript: generatedStory.fullScript,
        },
        language,
        storyType: storyGenre,
        durationSeconds: duration,
        visualStyle,
        characterReference: enableCharacterLock ? charRef : null,
      });

      // Prepare Scene Objects
      const finalScenes: Scene[] = sceneBreakdown.scenes.map((s, idx) => ({
        id: `scene_${Date.now()}_${idx}`,
        sceneNumber: idx + 1,
        duration: s.duration || Math.max(4, Math.round(duration / sceneBreakdown.scenes.length)),
        narration: s.narration || '',
        englishNarration: s.englishNarration,
        visualPrompt: s.visualPrompt,
        cameraMotion: s.cameraMotion || 'zoom-in',
        motionStrength: s.motionStrength || 7,
        soundEffect: s.soundEffect || 'divine_chime',
        subtitles: s.subtitles || [
          { text: s.narration || '', startMs: 0, endMs: (s.duration || 5) * 1000 },
        ],
      }));

      // Stage 4: Generating Visuals
      setCurrentStage(4);
      setStageDetails('Synthesizing 8K ultra-detailed scene artwork for all frames...');
      for (let i = 0; i < finalScenes.length; i++) {
        setStageDetails(`Rendering Visual Layer for Scene ${i + 1} of ${finalScenes.length}...`);
        try {
          const imgRes = await generateImage({
            prompt: finalScenes[i].visualPrompt,
            aspectRatio,
            visualStyle,
            characterReferenceBase64: enableCharacterLock ? uploadedImage || undefined : undefined,
          });

          if (imgRes.imageUrl) {
            finalScenes[i].imageUrl = imgRes.imageUrl;
          } else {
            // Procedural Canvas Synthesis fallback
            const canvasData = await createProceduralSceneCanvas(
              finalScenes[i].visualPrompt,
              visualStyle,
              aspectRatio
            );
            finalScenes[i].imageUrl = canvasData;
          }
        } catch {
          const canvasData = await createProceduralSceneCanvas(
            finalScenes[i].visualPrompt,
            visualStyle,
            aspectRatio
          );
          finalScenes[i].imageUrl = canvasData;
        }
      }

      // Stage 5: Generating Voice
      setCurrentStage(5);
      setStageDetails('Synthesizing natural Bengali speech voiceover with proper cadence...');
      for (let i = 0; i < finalScenes.length; i++) {
        if (finalScenes[i].narration) {
          try {
            const ttsRes = await generateTTS({
              text: finalScenes[i].narration,
              voice: selectedVoice,
              style: `Emotional ${voiceStyle} storytelling in ${language}`,
            });
            if (ttsRes.audioBase64) {
              finalScenes[i].audioBase64 = ttsRes.audioBase64;
            }
          } catch (e: any) {
            console.warn('TTS note:', e.message);
          }
        }
      }

      // Stage 6: Adding Music
      setCurrentStage(6);
      setStageDetails(`Synchronizing ${bgmGenre} background score with dynamic mood mixing...`);

      // Stage 7: Syncing Lip Movement
      setCurrentStage(7);
      setStageDetails('Aligning mouth opening amplitude and speech phonemes...');

      // Stage 8: Creating Subtitles
      setCurrentStage(8);
      setStageDetails('Formatting synchronized karaoke-style Bengali captions...');

      // Stage 9: Rendering Final Video
      setCurrentStage(9);
      setStageDetails('Compositing visual layers, audio tracks, and camera push animations...');

      const newProject: Project = {
        ...project,
        title: generatedStory.title || 'Untitled Tiger AI Story',
        language,
        storyType: storyGenre,
        visualStyle,
        aspectRatio,
        targetDuration: duration,
        bgmGenre,
        bgmVolume,
        voiceVolume,
        ttsVoice: selectedVoice,
        voiceGender,
        subtitlePreset: 'viral-yellow',
        characterReference: enableCharacterLock ? charRef : undefined,
        scenes: finalScenes,
        updatedAt: Date.now(),
      };

      onCompleteProject(newProject);
      setIsDone(true);
      safeVibrate([30, 50, 30]);
    } catch (err: any) {
      console.error('Error during auto-video generation:', err);
      setErrorMsg(err.message || 'An error occurred during video creation.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300 max-w-4xl mx-auto pb-12">
      {/* Header */}
      <div className="border-b border-gray-800 pb-4">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 text-black">
            <Sparkles className="w-5 h-5 fill-black" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
              <span>{isBn ? 'সম্পূর্ণ এআই ভিডিও ক্রিয়েশন' : 'One-Tap AI Video Creator'}</span>
              <span className="text-xl">🐅</span>
            </h2>
            <p className="text-xs text-amber-300 font-tiro mt-0.5">
              “একটা ছবি বা একটা গল্প থেকেই সম্পূর্ণ AI ভিডিও।”
            </p>
          </div>
        </div>
      </div>

      {/* 9-Stage Progress Screen (When Generating) */}
      {isGenerating && (
        <div className="bg-[#0E121C] border-2 border-amber-500/60 rounded-3xl p-6 space-y-6 shadow-2xl animate-in zoom-in-95 duration-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Loader2 className="w-6 h-6 animate-spin text-amber-400" />
              <div>
                <h3 className="text-base font-black text-white">
                  {isBn ? 'AI ভিডিও তৈরি হচ্ছে...' : 'AI Video Generation in Progress...'}
                </h3>
                <p className="text-xs text-amber-300/90">{stageDetails}</p>
              </div>
            </div>
            <span className="text-xs font-mono font-bold text-amber-400 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/30">
              {currentStage} / 9
            </span>
          </div>

          {/* Progress Stage Tracker */}
          <div className="grid grid-cols-3 sm:grid-cols-9 gap-2">
            {STAGES.map((st) => {
              const isPassed = currentStage > st.step;
              const isCurrent = currentStage === st.step;
              return (
                <div
                  key={st.step}
                  className={`p-2 rounded-2xl border text-center transition flex flex-col items-center justify-center gap-1 ${
                    isPassed
                      ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
                      : isCurrent
                      ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-md animate-pulse'
                      : 'bg-[#141A28] border-gray-800 text-gray-500'
                  }`}
                >
                  <span className="text-xs font-black">{st.step}</span>
                  <span className="text-[9px] font-bold truncate w-full">
                    {isBn ? st.nameBn : st.nameEn}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="w-full bg-gray-800 h-2 rounded-full overflow-hidden">
            <div
              className="bg-gradient-to-r from-amber-500 to-orange-500 h-full transition-all duration-500"
              style={{ width: `${(currentStage / 9) * 100}%` }}
            />
          </div>
        </div>
      )}

      {/* Completion Success Banner */}
      {isDone && (
        <div className="p-5 rounded-3xl bg-emerald-950/40 border border-emerald-500/60 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl animate-in zoom-in-95">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500 text-black flex items-center justify-center text-2xl shadow-lg">
              ✓
            </div>
            <div>
              <h4 className="text-sm sm:text-base font-black text-white">
                {isBn ? 'ভিডিও সফলভাবে তৈরি হয়েছে!' : 'Video Master Rendered Successfully!'}
              </h4>
              <p className="text-xs text-gray-300">
                All scenes, Bengali speech, subtitles, and BGM are ready in the Studio Player.
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              safeVibrate(15);
              onNavigateToStudio();
            }}
            className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-emerald-400 hover:bg-emerald-300 text-black font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg active:scale-95 transition"
          >
            <Play className="w-4 h-4 fill-black" />
            <span>{isBn ? 'ভিডিও দেখুন ও এডিট করুন' : 'VIEW IN STUDIO PLAYER'}</span>
          </button>
        </div>
      )}

      {/* Error Alert */}
      {errorMsg && (
        <div className="p-4 rounded-2xl bg-red-950/40 border border-red-500/50 text-red-300 text-xs flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
          <button
            onClick={() => setErrorMsg(null)}
            className="text-gray-400 hover:text-white text-xs underline"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Input Configuration Form */}
      <div className="space-y-6">
        {/* Step 1: Prompt or Story Idea */}
        <div className="bg-[#0E121C] border border-gray-800 rounded-3xl p-5 sm:p-6 space-y-4 shadow-xl">
          <div className="flex items-center justify-between">
            <label className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-amber-500 text-black flex items-center justify-center text-xs font-black">
                1
              </span>
              <span>{isBn ? 'গল্পের ধারণা বা প্রম্পট লিখুন' : 'Enter Prompt or Story Idea'}</span>
            </label>
            <span className="text-[11px] text-gray-400 font-mono">Bengali / English</span>
          </div>

          <textarea
            value={promptInput}
            onChange={(e) => setPromptInput(e.target.value)}
            rows={3}
            placeholder={
              isBn
                ? 'উদাহরণ: একটি বাঘ সুন্দরবনের গভীর জঙ্গলে একটি শিশুকে বাঁচালো...'
                : 'e.g. A majestic Royal Bengal Tiger protects a lost village child...'
            }
            className="w-full bg-[#141A28] border border-gray-700/80 focus:border-amber-500 rounded-2xl p-3.5 text-xs sm:text-sm text-white outline-none resize-none font-tiro leading-relaxed"
          />

          {/* Quick Suggestion Chips */}
          <div className="flex flex-wrap gap-1.5 pt-1">
            {samplePrompts.map((p) => (
              <button
                key={p.label}
                onClick={() => {
                  safeVibrate(10);
                  setPromptInput(p.text);
                }}
                className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-[#141A28] hover:bg-amber-500/20 text-gray-300 hover:text-amber-300 border border-gray-800 hover:border-amber-500/40 transition active:scale-95"
              >
                ✨ {p.label}
              </button>
            ))}
          </div>
        </div>

        {/* Step 2: Source Photo & Character Lock */}
        <div className="bg-[#0E121C] border border-gray-800 rounded-3xl p-5 sm:p-6 space-y-4 shadow-xl">
          <div className="flex items-center justify-between">
            <label className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-amber-500 text-black flex items-center justify-center text-xs font-black">
                2
              </span>
              <span>{isBn ? 'ছবি আপলোড ও চরিত্র লক (Character Lock)' : 'Source Photo & Character Lock'}</span>
            </label>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300">
              Identity Consistency
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Upload Area */}
            <div className="relative aspect-[16/9] rounded-2xl bg-[#141A28] border-2 border-dashed border-gray-700 hover:border-amber-500/60 overflow-hidden flex flex-col items-center justify-center p-3 text-center cursor-pointer group">
              {uploadedImage ? (
                <div className="relative w-full h-full">
                  <img
                    src={uploadedImage}
                    alt="Source"
                    className="w-full h-full object-cover rounded-xl"
                  />
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setUploadedImage(null);
                    }}
                    className="absolute top-2 right-2 px-2 py-1 rounded-lg bg-black/70 text-red-400 text-xs font-bold"
                  >
                    Remove
                  </button>
                </div>
              ) : (
                <div className="space-y-1.5">
                  <Upload className="w-7 h-7 text-amber-400 mx-auto group-hover:scale-110 transition-transform" />
                  <span className="text-xs font-bold text-white block">
                    {isBn ? 'ছবি আপলোড করুন (ঐচ্ছিক)' : 'Upload Character / Scene Photo'}
                  </span>
                  <span className="text-[10px] text-gray-400 block">PNG, JPG, WebP</span>
                </div>
              )}
              <input
                type="file"
                accept="image/*"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    const reader = new FileReader();
                    reader.onload = () => setUploadedImage(reader.result as string);
                    reader.readAsDataURL(file);
                  }
                }}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
            </div>

            {/* Character Lock Fields */}
            <div className="space-y-3">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={enableCharacterLock}
                  onChange={(e) => setEnableCharacterLock(e.target.checked)}
                  className="w-4 h-4 rounded text-amber-500 focus:ring-0 accent-amber-500"
                />
                <span className="text-xs font-bold text-white">
                  {isBn ? 'সব দৃশ্যে একই মুখ ও পোশাক বজায় রাখুন' : 'Lock Character Across All Scenes'}
                </span>
              </label>

              <div>
                <label className="text-[11px] text-gray-400 font-semibold block mb-1">
                  {isBn ? 'চরিত্রের নাম' : 'Character Name'}
                </label>
                <input
                  type="text"
                  value={charName}
                  onChange={(e) => setCharName(e.target.value)}
                  className="w-full bg-[#141A28] border border-gray-700 rounded-xl px-3 py-2 text-xs text-white outline-none"
                />
              </div>

              <div>
                <label className="text-[11px] text-gray-400 font-semibold block mb-1">
                  {isBn ? 'পোশাক ও চাক্ষুষ বিবরণ' : 'Clothing & Visual Markers'}
                </label>
                <input
                  type="text"
                  value={charAttire}
                  onChange={(e) => setCharAttire(e.target.value)}
                  className="w-full bg-[#141A28] border border-gray-700 rounded-xl px-3 py-2 text-xs text-white outline-none"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Step 3: Visual Style & Genre */}
        <div className="bg-[#0E121C] border border-gray-800 rounded-3xl p-5 sm:p-6 space-y-4 shadow-xl">
          <label className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-amber-500 text-black flex items-center justify-center text-xs font-black">
              3
            </span>
            <span>{isBn ? 'ভিজ্যুয়াল স্টাইল ও জনরা' : 'Visual Style & Story Genre'}</span>
          </label>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-2">
            {(['Realistic', 'Cartoon', 'Cinematic', '3D', 'Devotional', 'Anime'] as VisualStyle[]).map(
              (style) => (
                <button
                  key={style}
                  onClick={() => {
                    safeVibrate(10);
                    setVisualStyle(style);
                  }}
                  className={`py-2.5 rounded-2xl text-xs font-bold border transition ${
                    visualStyle === style
                      ? 'bg-amber-500 text-black border-amber-400 shadow-md font-extrabold'
                      : 'bg-[#141A28] border-gray-800 text-gray-400 hover:text-white'
                  }`}
                >
                  {style}
                </button>
              )
            )}
          </div>
        </div>

        {/* Step 4: Bengali Voice & BGM Selection */}
        <div className="bg-[#0E121C] border border-gray-800 rounded-3xl p-5 sm:p-6 space-y-4 shadow-xl">
          <label className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-amber-500 text-black flex items-center justify-center text-xs font-black">
              4
            </span>
            <span>{isBn ? 'ভয়েস ওভার ও ব্যাকগ্রাউন্ড মিউজিক' : 'Voiceover & Background Music'}</span>
          </label>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-[11px] text-gray-400 font-semibold block mb-1">
                {isBn ? 'স্পিকার জেন্ডার' : 'Voice Gender'}
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                <button
                  onClick={() => setVoiceGender('female')}
                  className={`py-2 rounded-xl text-xs font-bold border ${
                    voiceGender === 'female'
                      ? 'bg-amber-500 text-black border-amber-400'
                      : 'bg-[#141A28] border-gray-800 text-gray-400'
                  }`}
                >
                  Female
                </button>
                <button
                  onClick={() => setVoiceGender('male')}
                  className={`py-2 rounded-xl text-xs font-bold border ${
                    voiceGender === 'male'
                      ? 'bg-amber-500 text-black border-amber-400'
                      : 'bg-[#141A28] border-gray-800 text-gray-400'
                  }`}
                >
                  Male
                </button>
              </div>
            </div>

            <div>
              <label className="text-[11px] text-gray-400 font-semibold block mb-1">
                {isBn ? 'ব্যাকগ্রাউন্ড মিউজিক মুড' : 'BGM Mood'}
              </label>
              <select
                value={bgmGenre}
                onChange={(e) => setBgmGenre(e.target.value as BgmGenre)}
                className="w-full bg-[#141A28] border border-gray-700 rounded-xl px-3 py-2 text-xs text-white outline-none"
              >
                {BGM_GENRES.map((g) => (
                  <option key={g} value={g}>
                    {g}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[11px] text-gray-400 font-semibold block mb-1">
                {isBn ? 'সাবটাইটেল প্রদর্শন' : 'Subtitles'}
              </label>
              <button
                onClick={() => setSubtitlesEnabled(!subtitlesEnabled)}
                className={`w-full py-2 rounded-xl text-xs font-bold border flex items-center justify-center gap-1.5 ${
                  subtitlesEnabled
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                    : 'bg-[#141A28] text-gray-500 border-gray-800'
                }`}
              >
                <Subtitles className="w-3.5 h-3.5" />
                <span>{subtitlesEnabled ? 'Auto Subtitles ON' : 'Subtitles OFF'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Step 5: Aspect Ratio, Duration & Quality */}
        <div className="bg-[#0E121C] border border-gray-800 rounded-3xl p-5 sm:p-6 space-y-4 shadow-xl">
          <label className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-amber-500 text-black flex items-center justify-center text-xs font-black">
              5
            </span>
            <span>{isBn ? 'ভিডিওর দৈর্ঘ্য ও রেজোলিউশন' : 'Aspect Ratio, Duration & Quality'}</span>
          </label>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-[11px] text-gray-400 font-semibold block mb-1">Aspect Ratio</label>
              <div className="grid grid-cols-3 gap-1">
                {(['9:16', '16:9', '1:1'] as AspectRatio[]).map((ar) => (
                  <button
                    key={ar}
                    onClick={() => setAspectRatio(ar)}
                    className={`py-2 rounded-xl text-xs font-bold border ${
                      aspectRatio === ar
                        ? 'bg-amber-500 text-black border-amber-400'
                        : 'bg-[#141A28] border-gray-800 text-gray-400'
                    }`}
                  >
                    {ar}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-[11px] text-gray-400 font-semibold block mb-1">Duration</label>
              <div className="grid grid-cols-4 gap-1">
                {[10, 20, 30, 60].map((sec) => (
                  <button
                    key={sec}
                    onClick={() => setDuration(sec)}
                    className={`py-2 rounded-xl text-xs font-bold border ${
                      duration === sec
                        ? 'bg-amber-500 text-black border-amber-400'
                        : 'bg-[#141A28] border-gray-800 text-gray-400'
                    }`}
                  >
                    {sec}s
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-[11px] text-gray-400 font-semibold block mb-1">Resolution</label>
              <div className="grid grid-cols-5 gap-1">
                {(['720p', '1080p', '2k', '4k', '8k'] as VideoResolution[]).map((res) => (
                  <button
                    key={res}
                    onClick={() => setResolution(res)}
                    className={`py-2 rounded-lg text-[10px] font-bold uppercase border ${
                      resolution === res
                        ? 'bg-amber-500 text-black border-amber-400'
                        : 'bg-[#141A28] border-gray-800 text-gray-400'
                    }`}
                  >
                    {res}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Flagship CREATE COMPLETE VIDEO Action Button */}
        <div className="pt-2">
          <button
            onClick={handleCreateCompleteVideo}
            disabled={isGenerating}
            className="w-full py-4 sm:py-5 rounded-3xl bg-gradient-to-r from-amber-400 via-orange-500 to-red-500 hover:from-amber-300 hover:to-orange-400 text-black font-black text-sm sm:text-base flex items-center justify-center gap-3 shadow-2xl shadow-orange-500/30 active:scale-98 transition transform disabled:opacity-50"
          >
            <Sparkles className="w-5 h-5 fill-black" />
            <span>
              {isBn ? 'সম্পূর্ণ এআই ভিডিও তৈরি করুন (১-ক্লিক)' : 'CREATE COMPLETE VIDEO'}
            </span>
            <ChevronRight className="w-5 h-5" />
          </button>
          <p className="text-center text-[11px] text-gray-500 mt-2 font-mono">
            Story → Characters → Scenes → Visuals → Voice → Music → Lip Sync → Subtitle → Final Video
          </p>
        </div>
      </div>
    </div>
  );
};
