import React from 'react';
import {
  Sparkles,
  Camera,
  BookOpen,
  MessageSquare,
  Mic,
  Palette,
  Wrench,
  Layers,
  FolderKanban,
  Play,
  Film,
  ArrowRight,
  Flame,
  Clock,
  CheckCircle2,
} from 'lucide-react';
import { Project, VideoTemplate } from '../types';
import { TEMPLATE_LIBRARY } from '../utils/constants';
import { safeVibrate } from '../utils/haptics';

interface HomeScreenProps {
  currentProject: Project;
  recentProjects: Project[];
  appLanguage: 'bn' | 'en';
  onNavigateTab: (tab: 'create' | 'projects' | 'templates' | 'profile' | 'studio') => void;
  onOpenAITool: (toolId: string) => void;
  onSelectTemplate: (template: VideoTemplate) => void;
  onOpenAutoCreator: () => void;
  onResumeProject: (project: Project) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  currentProject,
  recentProjects,
  appLanguage,
  onNavigateTab,
  onOpenAITool,
  onSelectTemplate,
  onOpenAutoCreator,
  onResumeProject,
}) => {
  const isBn = appLanguage === 'bn';

  const handleVibrate = () => safeVibrate(10);

  const mainTools = [
    {
      id: 'create-video',
      label: isBn ? 'ভিডিও বানান' : 'Create Video',
      icon: Sparkles,
      color: 'from-amber-500 to-orange-600',
      desc: isBn ? '১-ক্লিকে সম্পূর্ণ AI ভিডিও' : '1-Click Complete Video',
      action: () => {
        handleVibrate();
        onOpenAutoCreator();
      },
    },
    {
      id: 'image-to-video',
      label: isBn ? 'ছবি থেকে ভিডিও' : 'Image to Video',
      icon: Camera,
      color: 'from-blue-500 to-indigo-600',
      desc: isBn ? 'ছবিকে জীবন্ত চরিত্র বানান' : 'Animate any photo',
      action: () => {
        handleVibrate();
        onNavigateTab('studio');
      },
    },
    {
      id: 'story-to-video',
      label: isBn ? 'গল্প থেকে ভিডিও' : 'Story to Video',
      icon: BookOpen,
      color: 'from-emerald-500 to-teal-600',
      desc: isBn ? 'বাংলা গল্প দৃশ্যভিত্তিক ভিডিও' : 'Turn idea into scenes',
      action: () => {
        handleVibrate();
        onNavigateTab('create');
      },
    },
    {
      id: 'talking-photo',
      label: isBn ? 'টকিং ফটো' : 'Talking Photo',
      icon: MessageSquare,
      color: 'from-purple-500 to-pink-600',
      desc: isBn ? 'মুখের নড়াচড়া ও কথা' : 'Lip sync portrait',
      action: () => {
        handleVibrate();
        onOpenAITool('talking-photo');
      },
    },
    {
      id: 'voice',
      label: isBn ? 'এআই ভয়েস' : 'Voice Studio',
      icon: Mic,
      color: 'from-red-500 to-rose-600',
      desc: isBn ? 'বাংলা ভয়েস ও ক্লোন' : 'Bengali TTS & Clone',
      action: () => {
        handleVibrate();
        onOpenAITool('voice-clone');
      },
    },
    {
      id: 'ai-image',
      label: isBn ? 'এআই ছবি' : 'AI Image',
      icon: Palette,
      color: 'from-amber-400 to-yellow-600',
      desc: isBn ? 'চরিত্র লক ও ব্যাকড্রপ' : 'Consistent generation',
      action: () => {
        handleVibrate();
        onOpenAITool('bg-remover');
      },
    },
    {
      id: 'ai-tools',
      label: isBn ? 'এআই টুলস' : 'AI Tools',
      icon: Wrench,
      color: 'from-cyan-500 to-blue-600',
      desc: isBn ? 'থাম্বনেইল ও এনহ্যান্সার' : 'Thumbnail, SEO & BG',
      action: () => {
        handleVibrate();
        onOpenAITool('thumbnail-maker');
      },
    },
    {
      id: 'templates',
      label: isBn ? 'টেমপ্লেট' : 'Templates',
      icon: Layers,
      color: 'from-fuchsia-500 to-purple-600',
      desc: isBn ? 'রেডিমেড ভাইরাল ফরম্যাট' : 'Viral ready presets',
      action: () => {
        handleVibrate();
        onNavigateTab('templates');
      },
    },
    {
      id: 'my-projects',
      label: isBn ? 'আমার প্রজেক্ট' : 'My Projects',
      icon: FolderKanban,
      color: 'from-orange-500 to-amber-600',
      desc: isBn ? 'ড্রাফট ও এক্সপোর্ট' : 'Saved drafts & history',
      action: () => {
        handleVibrate();
        onNavigateTab('projects');
      },
    },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Flagship Hero Card with Bengali Tagline */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-amber-950/60 via-[#131926] to-[#0A0D14] border border-amber-500/30 p-5 sm:p-7 shadow-2xl">
        <div className="absolute -top-16 -right-16 w-52 h-52 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 space-y-4">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-full text-[11px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              TIGER AI CREATOR • BANGALORE / BENGAL EDITION
            </span>
          </div>

          <div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-2">
              <span>TIGER</span>
              <span className="bg-gradient-to-r from-amber-400 via-orange-400 to-amber-200 bg-clip-text text-transparent">
                AI CREATOR
              </span>
              <span className="text-2xl">🐅</span>
            </h1>
            <p className="text-sm sm:text-base font-semibold text-amber-300/90 mt-1 font-tiro">
              “একটা ছবি বা একটা গল্প থেকেই সম্পূর্ণ AI ভিডিও।”
            </p>
            <p className="text-xs text-gray-400 max-w-xl mt-1">
              One Photo / One Sentence → AI Story → Character Lock → Scenes → Video → Bengali Voice → Music → Subtitle → Final Video.
            </p>
          </div>

          {/* Prominent Flagship One-Tap Complete Video Button */}
          <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <button
              onClick={() => {
                handleVibrate();
                onOpenAutoCreator();
              }}
              className="flex-1 px-6 py-3.5 rounded-2xl bg-gradient-to-r from-amber-400 via-orange-500 to-red-500 hover:from-amber-300 hover:to-orange-400 text-black font-extrabold text-sm sm:text-base flex items-center justify-center gap-2.5 shadow-xl shadow-orange-500/25 active:scale-98 transition transform group"
            >
              <Sparkles className="w-5 h-5 text-black group-hover:rotate-12 transition-transform" />
              <span>{isBn ? 'সম্পূর্ণ ভিডিও তৈরি করুন (১-ট্যাপ)' : 'CREATE COMPLETE VIDEO'}</span>
              <ArrowRight className="w-4 h-4 ml-1" />
            </button>

            <button
              onClick={() => {
                handleVibrate();
                onNavigateTab('studio');
              }}
              className="px-5 py-3.5 rounded-2xl bg-[#171E2D] hover:bg-[#1E273A] border border-gray-700/80 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition"
            >
              <Film className="w-4 h-4 text-amber-400" />
              <span>{isBn ? 'স্টুডিও টাইমলাইন' : 'Studio Timeline'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main 9 Action Buttons Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>{isBn ? 'প্রধান ক্রিয়েটর টুলস' : 'Core AI Creator Tools'}</span>
          </h3>
          <span className="text-xs text-gray-400">9 Fast Actions</span>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-3 lg:grid-cols-9 gap-2.5">
          {mainTools.map((tool) => {
            const Icon = tool.icon;
            return (
              <button
                key={tool.id}
                onClick={tool.action}
                className="group relative p-3 sm:p-3.5 rounded-2xl bg-[#0E121C] hover:bg-[#141A28] border border-gray-800/80 hover:border-amber-500/40 text-center transition flex flex-col items-center justify-center gap-2 shadow-lg active:scale-95"
              >
                <div
                  className={`w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-br ${tool.color} p-[1.5px] shadow-md flex items-center justify-center`}
                >
                  <div className="w-full h-full bg-[#0E121C]/90 rounded-[14px] flex items-center justify-center group-hover:bg-transparent transition">
                    <Icon className="w-5 h-5 text-white group-hover:scale-110 transition-transform" />
                  </div>
                </div>

                <div className="min-w-0 w-full">
                  <div className="text-xs font-bold text-white truncate group-hover:text-amber-300 transition-colors">
                    {tool.label}
                  </div>
                  <div className="text-[10px] text-gray-400 truncate hidden sm:block">
                    {tool.desc}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Working Project Quick Bar */}
      <div className="bg-[#0E121C] border border-gray-800 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center flex-shrink-0 text-xl border border-amber-500/30">
            🎬
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-white truncate">{currentProject.title}</span>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300">
                {currentProject.aspectRatio} • {currentProject.scenes.length} {isBn ? 'দৃশ্য' : 'Scenes'}
              </span>
            </div>
            <p className="text-[11px] text-gray-400 truncate mt-0.5">
              {currentProject.scenes[0]?.narration || 'Ready to render and export'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <button
            onClick={() => {
              handleVibrate();
              onNavigateTab('studio');
            }}
            className="w-full sm:w-auto px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-xs flex items-center justify-center gap-1.5 transition active:scale-95"
          >
            <Play className="w-3.5 h-3.5 fill-black" />
            <span>{isBn ? 'প্লেয়ারে খুলুন' : 'Open in Player'}</span>
          </button>
        </div>
      </div>

      {/* Trending Ready-to-Use Templates Showcase */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Flame className="w-4 h-4 text-orange-400" />
            <span>{isBn ? 'জনপ্রিয় রেডিমেড টেমপ্লেট' : 'Viral Template Presets'}</span>
          </h3>
          <button
            onClick={() => {
              handleVibrate();
              onNavigateTab('templates');
            }}
            className="text-xs text-amber-400 hover:underline flex items-center gap-1 font-bold"
          >
            <span>{isBn ? 'সব দেখুন' : 'View All'}</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {TEMPLATE_LIBRARY.slice(0, 4).map((tpl) => (
            <div
              key={tpl.id}
              onClick={() => {
                handleVibrate();
                onSelectTemplate(tpl);
              }}
              className="bg-[#0E121C] hover:bg-[#131926] border border-gray-800 hover:border-amber-500/50 rounded-2xl p-4 cursor-pointer transition active:scale-98 shadow-md flex flex-col justify-between group"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-2xl">{tpl.thumbnailEmoji}</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-amber-500/15 text-amber-300 border border-amber-500/30">
                    {tpl.category}
                  </span>
                </div>

                <div>
                  <h4 className="text-xs font-bold text-white group-hover:text-amber-300 transition">
                    {isBn ? tpl.bengaliTitle : tpl.title}
                  </h4>
                  <p className="text-[11px] text-gray-400 line-clamp-2 mt-1">
                    {isBn ? tpl.bengaliPromptIdea : tpl.description}
                  </p>
                </div>
              </div>

              <div className="pt-3 mt-3 border-t border-gray-800/80 flex items-center justify-between text-[10px] text-gray-400 font-semibold">
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3 text-amber-400" />
                  <span>{tpl.duration}s • {tpl.aspectRatio}</span>
                </span>
                <span className="text-amber-400 font-bold group-hover:translate-x-1 transition-transform flex items-center gap-0.5">
                  {isBn ? 'ব্যবহার করুন' : 'Use'} →
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
