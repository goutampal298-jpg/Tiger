import React, { useState } from 'react';
import {
  Home,
  Sparkles,
  FolderKanban,
  Layers,
  User,
  Film,
  Camera,
  BookOpen,
  Palette,
  Gamepad2,
  Video,
  Music,
  UserCheck,
  Download,
  MoreHorizontal,
  X,
} from 'lucide-react';
import { safeVibrate } from '../utils/haptics';

export type NavTab =
  | 'home'
  | 'create'
  | 'projects'
  | 'templates'
  | 'profile'
  | 'studio'
  | 'text2video'
  | 'story'
  | 'cartoon'
  | 'game'
  | 'reference'
  | 'character'
  | 'image2video'
  | 'audio'
  | 'export';

interface BottomNavProps {
  activeTab: NavTab;
  appLanguage?: 'bn' | 'en';
  onTabChange: (tab: NavTab) => void;
  onOpenAutoCreator: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  appLanguage = 'bn',
  onTabChange,
  onOpenAutoCreator,
}) => {
  const [showMoreMenu, setShowMoreMenu] = useState<boolean>(false);
  const isBn = appLanguage === 'bn';

  const triggerHaptic = () => {
    safeVibrate(10);
  };

  const secondaryTools: {
    id: NavTab;
    label: string;
    icon: React.FC<{ className?: string }>;
    desc: string;
  }[] = [
    { id: 'studio', label: 'Studio Timeline', icon: Film, desc: 'Full timeline & canvas player' },
    { id: 'image2video', label: 'Image To Video', icon: Camera, desc: 'Animate photos with walking, running & expressions' },
    { id: 'cartoon', label: 'Cartoon Mode', icon: Palette, desc: '2D/3D cartoon & anime presets' },
    { id: 'game', label: 'Game Cinematic', icon: Gamepad2, desc: 'RPG, battle & trailer mode' },
    { id: 'character', label: 'Character Consistency', icon: UserCheck, desc: '7-pillar consistency vault' },
    { id: 'reference', label: 'Reference Link / Video', icon: Video, desc: 'Synthesize original story from pacing' },
    { id: 'audio', label: 'Audio & Subtitles', icon: Music, desc: 'BGM genres, TTS & custom subtitles' },
    { id: 'text2video', label: 'Text To Video', icon: Sparkles, desc: 'Generate video directly from prompt' },
    { id: 'export', label: 'Export Video', icon: Download, desc: '720p, 1080p, 2K, 4K, 8K export' },
  ];

  return (
    <>
      {/* Secondary Tools Sheet Modal */}
      {showMoreMenu && (
        <div
          onClick={() => setShowMoreMenu(false)}
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex flex-col justify-end p-3 animate-in fade-in"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-[#0E121C] border border-gray-800 rounded-3xl p-5 space-y-4 max-w-md w-full mx-auto shadow-2xl animate-in slide-in-from-bottom"
          >
            <div className="flex items-center justify-between border-b border-gray-800 pb-3">
              <div className="flex items-center gap-2">
                <span className="text-lg">🐅</span>
                <h4 className="text-sm font-bold text-white uppercase tracking-wider">
                  {isBn ? 'সব স্টুডিও টুলস' : 'All Studio Workspaces'}
                </h4>
              </div>
              <button
                onClick={() => setShowMoreMenu(false)}
                className="p-1.5 rounded-xl bg-gray-800 text-gray-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 gap-1.5 max-h-[60vh] overflow-y-auto pr-1">
              {secondaryTools.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      triggerHaptic();
                      onTabChange(item.id);
                      setShowMoreMenu(false);
                    }}
                    className={`p-3 rounded-2xl border text-left flex items-center gap-3 transition ${
                      isActive
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                        : 'bg-[#141926] border-gray-800 text-gray-300 hover:border-gray-700'
                    }`}
                  >
                    <div className="p-2 rounded-xl bg-amber-500/15 text-amber-400">
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-white">{item.label}</div>
                      <div className="text-[10px] text-gray-400 truncate">{item.desc}</div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Main 5-Item Bottom Nav Bar as requested: Home | Create | Projects | Templates | Profile */}
      <nav className="fixed bottom-0 inset-x-0 z-40 bg-[#0A0D14]/95 backdrop-blur-xl border-t border-amber-500/20 px-2 py-1.5 pb-safe sm:pb-2.5">
        <div className="max-w-lg mx-auto flex items-center justify-between gap-1">
          {/* 1. Home */}
          <button
            onClick={() => {
              triggerHaptic();
              onTabChange('home');
            }}
            className={`flex-1 flex flex-col items-center justify-center py-1 rounded-xl transition active:scale-95 ${
              activeTab === 'home'
                ? 'text-amber-400 font-black'
                : 'text-gray-400 hover:text-gray-200 font-medium'
            }`}
          >
            <Home className={`w-5 h-5 ${activeTab === 'home' ? 'text-amber-400 stroke-[2.5]' : ''}`} />
            <span className="text-[10px] mt-0.5 tracking-tight truncate">
              {isBn ? 'হোম' : 'Home'}
            </span>
          </button>

          {/* 2. Projects */}
          <button
            onClick={() => {
              triggerHaptic();
              onTabChange('projects');
            }}
            className={`flex-1 flex flex-col items-center justify-center py-1 rounded-xl transition active:scale-95 ${
              activeTab === 'projects'
                ? 'text-amber-400 font-black'
                : 'text-gray-400 hover:text-gray-200 font-medium'
            }`}
          >
            <FolderKanban className={`w-5 h-5 ${activeTab === 'projects' ? 'text-amber-400 stroke-[2.5]' : ''}`} />
            <span className="text-[10px] mt-0.5 tracking-tight truncate">
              {isBn ? 'প্রজেক্ট' : 'Projects'}
            </span>
          </button>

          {/* 3. Center Prominent CREATE Button */}
          <button
            onClick={() => {
              triggerHaptic();
              onTabChange('create');
            }}
            className="flex-shrink-0 -mt-5 mx-1 flex flex-col items-center justify-center group"
            title="Create Video"
          >
            <div className="w-13 h-13 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-tr from-amber-400 via-orange-500 to-red-500 p-[2.5px] shadow-xl shadow-orange-500/40 group-hover:scale-105 group-active:scale-95 transition">
              <div className="w-full h-full bg-[#0E121C] rounded-[13px] flex items-center justify-center group-hover:bg-[#151A26] transition">
                <Sparkles className="w-6 h-6 text-amber-300 group-hover:rotate-12 transition-transform" />
              </div>
            </div>
            <span className="text-[9px] font-black uppercase text-amber-400 mt-1 tracking-wider">
              {isBn ? 'ক্রিয়েট' : 'CREATE'}
            </span>
          </button>

          {/* 4. Templates */}
          <button
            onClick={() => {
              triggerHaptic();
              onTabChange('templates');
            }}
            className={`flex-1 flex flex-col items-center justify-center py-1 rounded-xl transition active:scale-95 ${
              activeTab === 'templates'
                ? 'text-amber-400 font-black'
                : 'text-gray-400 hover:text-gray-200 font-medium'
            }`}
          >
            <Layers className={`w-5 h-5 ${activeTab === 'templates' ? 'text-amber-400 stroke-[2.5]' : ''}`} />
            <span className="text-[10px] mt-0.5 tracking-tight truncate">
              {isBn ? 'টেমপ্লেট' : 'Templates'}
            </span>
          </button>

          {/* 5. Profile */}
          <button
            onClick={() => {
              triggerHaptic();
              onTabChange('profile');
            }}
            className={`flex-1 flex flex-col items-center justify-center py-1 rounded-xl transition active:scale-95 ${
              activeTab === 'profile'
                ? 'text-amber-400 font-black'
                : 'text-gray-400 hover:text-gray-200 font-medium'
            }`}
          >
            <User className={`w-5 h-5 ${activeTab === 'profile' ? 'text-amber-400 stroke-[2.5]' : ''}`} />
            <span className="text-[10px] mt-0.5 tracking-tight truncate">
              {isBn ? 'প্রোফাইল' : 'Profile'}
            </span>
          </button>

          {/* Quick overflow button to open Studio & all special workspaces */}
          <button
            onClick={() => {
              triggerHaptic();
              setShowMoreMenu(true);
            }}
            className={`px-1.5 py-1 rounded-xl transition active:scale-95 ${
              secondaryTools.some((t) => t.id === activeTab)
                ? 'text-amber-400 font-bold bg-amber-500/10'
                : 'text-gray-500 hover:text-gray-300'
            }`}
            title="More Studio Tools"
          >
            <MoreHorizontal className="w-4 h-4" />
          </button>
        </div>
      </nav>
    </>
  );
};
