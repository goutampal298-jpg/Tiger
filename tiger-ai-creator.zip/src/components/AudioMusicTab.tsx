import React, { useState } from 'react';
import {
  Music,
  Mic,
  Volume2,
  Play,
  Square,
  Sparkles,
  Subtitles,
  Sliders,
  Check,
  AlignVerticalJustifyStart,
  AlignVerticalJustifyCenter,
  AlignVerticalJustifyEnd,
  Type,
  Clock,
  User,
} from 'lucide-react';
import {
  BgmGenre,
  Project,
  SoundEffectType,
  StoryLanguage,
  SubtitleFontSize,
  SubtitlePosition,
  SubtitlePreset,
} from '../types';
import { BGM_GENRES, SUBTITLE_PRESETS } from '../utils/constants';
import { audioEngine } from '../services/audioEngine';
import { safeVibrate } from '../utils/haptics';

interface AudioMusicTabProps {
  project: Project;
  onUpdateAudioSettings: (settings: {
    bgmGenre?: BgmGenre;
    bgmVolume?: number;
    voiceVolume?: number;
    ttsVoice?: string;
    voiceGender?: 'male' | 'female';
    voiceNarrationStyle?: 'dramatic' | 'reverent' | 'energetic' | 'whisper' | 'storyteller';
    subtitlePreset?: SubtitlePreset;
    subtitlePosition?: SubtitlePosition;
    subtitleFontSize?: SubtitleFontSize;
    subtitleTimingOffsetMs?: number;
  }) => void;
}

const VOICE_OPTIONS = [
  { id: 'Kore', name: 'Kore', gender: 'female', desc: 'Warm, serene, reverent & deeply expressive' },
  { id: 'Zephyr', name: 'Zephyr', gender: 'female', desc: 'Smooth, gentle, soothing & meditative' },
  { id: 'Fenrir', name: 'Fenrir', gender: 'male', desc: 'Deep, resonant, commanding & cinematic' },
  { id: 'Charon', name: 'Charon', gender: 'male', desc: 'Grave, mysterious & dramatic movie trailer' },
  { id: 'Puck', name: 'Puck', gender: 'male', desc: 'Energetic, youthful, bright & cartoon-friendly' },
];

const NARRATION_STYLES: {
  id: 'dramatic' | 'reverent' | 'energetic' | 'whisper' | 'storyteller';
  label: string;
  icon: string;
  desc: string;
}[] = [
  { id: 'reverent', label: 'Reverent / Devotional', icon: '🪔', desc: 'Solemn, spiritual cadence and divine awe' },
  { id: 'dramatic', label: 'Dramatic / Cinematic', icon: '🎬', desc: 'Hollywood blockbuster tension and emotional weight' },
  { id: 'energetic', label: 'Energetic / Action', icon: '⚡', desc: 'Fast-paced, adrenaline punch and hype' },
  { id: 'storyteller', label: 'Folk Storyteller / Dadu', icon: '📖', desc: 'Captivating narrative warmth and character acting' },
  { id: 'whisper', label: 'Mysterious / Whisper', icon: '🤫', desc: 'Low atmospheric intrigue and suspense' },
];

const SFX_LIST: { id: SoundEffectType; name: string; icon: string; desc: string; category: string }[] = [
  { id: 'temple_bell', name: 'Temple Bell', icon: '🪔', desc: 'Resonant bronze temple chime', category: 'Devotional' },
  { id: 'divine_chime', name: 'Divine Chime', icon: '✨', desc: 'Cascading celestial wind chime', category: 'Devotional' },
  { id: 'cinematic_hit', name: 'Cinematic Hit', icon: '💥', desc: 'Deep sub-bass impact drop', category: 'Cinematic' },
  { id: 'whoosh', name: 'Whoosh', icon: '💨', desc: 'Filtered transition sweep', category: 'Action' },
  { id: 'thunder', name: 'Thunder', icon: '⚡', desc: 'Distant rolling thunder rumble', category: 'Horror' },
  { id: 'heartbeat', name: 'Heartbeat', icon: '💓', desc: 'Double pulse suspense thump', category: 'Horror' },
  { id: 'magic_sparkle', name: 'Magic Sparkle', icon: '🌟', desc: 'High frequency fairy shimmer', category: 'Cartoon' },
  { id: 'nature_wind', name: 'Nature Wind', icon: '🍃', desc: 'Gentle forest breeze', category: 'Emotional' },
];

export const AudioMusicTab: React.FC<AudioMusicTabProps> = ({
  project,
  onUpdateAudioSettings,
}) => {
  const [activeBgmPlaying, setActiveBgmPlaying] = useState<boolean>(false);
  const [selectedGender, setSelectedGender] = useState<'all' | 'male' | 'female'>('all');
  const [testVoiceText, setTestVoiceText] = useState<string>(
    project.scenes[0]?.narration ||
      (project.language === 'Bengali'
        ? 'একটি সুন্দর সকালে গভীর জঙ্গলে একটি অদ্ভুত ঘটনা ঘটল।'
        : project.language === 'Hindi'
        ? 'सुंदर प्रभात में घने जंगल में एक अद्भुत घटना घटित हुई।'
        : 'In the heart of the ancient forest, a magnificent story began.')
  );

  const handleToggleBgmTest = () => {
    safeVibrate(15);
    if (activeBgmPlaying) {
      audioEngine.stopBGM();
      setActiveBgmPlaying(false);
    } else {
      audioEngine.setBgmVolume(project.bgmVolume);
      audioEngine.startBGM(project.bgmGenre);
      setActiveBgmPlaying(true);
    }
  };

  const handleTestSFX = (type: SoundEffectType) => {
    audioEngine.playSFX(type);
    safeVibrate(15);
  };

  const handleTestVoice = () => {
    safeVibrate(15);
    audioEngine.setVoiceVolume(project.voiceVolume);
    audioEngine.playTTS(testVoiceText, project.language);
  };

  const filteredVoices = VOICE_OPTIONS.filter((v) => {
    if (selectedGender === 'all') return true;
    return v.gender === selectedGender;
  });

  return (
    <div className="bg-[#0E121C] border border-gray-800 rounded-3xl p-4 sm:p-6 space-y-6 shadow-xl max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-gray-800 pb-4">
        <div className="flex items-center gap-2.5">
          <div className="p-2.5 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 text-black shadow-lg shadow-orange-500/20">
            <Music className="w-5 h-5 font-black" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base sm:text-lg font-bold text-white">
                Audio, Voice & Subtitles Master Suite
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                100% Royalty-Free
              </span>
            </div>
            <p className="text-xs text-gray-400">
              Bengali, Hindi & English AI voices, simulated lip-sync timing, subtitle typography & procedural music synthesis.
            </p>
          </div>
        </div>
      </div>

      {/* 1. Background Music (BGM) */}
      <div className="bg-[#121622] p-4 sm:p-5 rounded-2xl border border-gray-800 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Music className="w-4 h-4 text-amber-400" />
              <span>1. Background Music (Cinematic, Emotional, Devotional, Horror, Cartoon, Game)</span>
            </h4>
            <p className="text-[11px] text-gray-400">Synthesized dynamically in real-time via Web Audio API stems</p>
          </div>

          <button
            onClick={handleToggleBgmTest}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition ${
              activeBgmPlaying
                ? 'bg-red-500/20 border-red-500 text-red-400 animate-pulse'
                : 'bg-amber-500/20 border-amber-500/40 text-amber-300 hover:bg-amber-500/30'
            }`}
          >
            {activeBgmPlaying ? <Square className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-amber-300" />}
            <span>{activeBgmPlaying ? 'Stop Music' : 'Audition Music'}</span>
          </button>
        </div>

        {/* Genre Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
          {BGM_GENRES.map((genre) => {
            const isSelected = project.bgmGenre === genre;
            return (
              <button
                key={genre}
                type="button"
                onClick={() => {
                  safeVibrate(10);
                  onUpdateAudioSettings({ bgmGenre: genre });
                  if (activeBgmPlaying) {
                    audioEngine.startBGM(genre);
                  }
                }}
                className={`p-3 rounded-xl border text-left transition ${
                  isSelected
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold shadow-md'
                    : 'bg-[#171D2D] border-gray-800 text-gray-300 hover:border-gray-700'
                }`}
              >
                <div className="text-xs">{genre}</div>
              </button>
            );
          })}
        </div>

        {/* Volume Slider */}
        <div className="space-y-1.5 pt-1">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-gray-400">BGM Volume Mix</span>
            <span className="text-xs font-mono font-bold text-amber-400">
              {Math.round(project.bgmVolume * 100)}%
            </span>
          </div>
          <input
            type="range"
            min={0}
            max={1}
            step={0.05}
            value={project.bgmVolume}
            onChange={(e) => {
              const val = parseFloat(e.target.value);
              onUpdateAudioSettings({ bgmVolume: val });
              audioEngine.setBgmVolume(val);
            }}
            className="w-full h-2 bg-gray-800 accent-amber-500 rounded-lg cursor-pointer"
          />
        </div>
      </div>

      {/* 2. AI Voice + Lip-Sync & Narration Style */}
      <div className="bg-[#121622] p-4 sm:p-5 rounded-2xl border border-gray-800 space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div>
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Mic className="w-4 h-4 text-amber-400" />
              <span>2. AI Voice, Narration Style & Lip-Sync (Bengali, Hindi, English)</span>
            </h4>
            <p className="text-[11px] text-gray-400">
              Active language: <strong className="text-amber-300">{project.language}</strong> • Real-time voice synthesis
            </p>
          </div>

          <div className="flex items-center gap-2">
            {/* Gender Filter */}
            <div className="flex items-center bg-[#0B0E16] p-1 rounded-xl border border-gray-800 text-xs">
              <button
                type="button"
                onClick={() => setSelectedGender('all')}
                className={`px-2 py-1 rounded-lg ${selectedGender === 'all' ? 'bg-amber-500 text-black font-bold' : 'text-gray-400'}`}
              >
                All
              </button>
              <button
                type="button"
                onClick={() => setSelectedGender('female')}
                className={`px-2 py-1 rounded-lg ${selectedGender === 'female' ? 'bg-amber-500 text-black font-bold' : 'text-gray-400'}`}
              >
                Female
              </button>
              <button
                type="button"
                onClick={() => setSelectedGender('male')}
                className={`px-2 py-1 rounded-lg ${selectedGender === 'male' ? 'bg-amber-500 text-black font-bold' : 'text-gray-400'}`}
              >
                Male
              </button>
            </div>

            <button
              onClick={handleTestVoice}
              className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-bold flex items-center gap-1.5 transition"
            >
              <Play className="w-3.5 h-3.5 fill-amber-300" />
              <span>Audition Voice</span>
            </button>
          </div>
        </div>

        {/* Voice Persona Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {filteredVoices.map((v) => {
            const isSelected = project.ttsVoice === v.id;
            return (
              <button
                key={v.id}
                type="button"
                onClick={() => {
                  safeVibrate(10);
                  onUpdateAudioSettings({ ttsVoice: v.id, voiceGender: v.gender as 'male' | 'female' });
                }}
                className={`p-3 rounded-xl border text-left transition ${
                  isSelected
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-md'
                    : 'bg-[#171D2D] border-gray-800 text-gray-300 hover:border-gray-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">{v.name}</span>
                  <span className="text-[10px] uppercase font-bold text-amber-400 px-1.5 py-0.5 rounded bg-amber-500/10">
                    {v.gender}
                  </span>
                </div>
                <div className="text-[11px] text-gray-400 line-clamp-1 mt-1">{v.desc}</div>
              </button>
            );
          })}
        </div>

        {/* Narration Styles */}
        <div className="space-y-1.5 pt-2">
          <label className="text-xs font-bold text-gray-300 uppercase tracking-wider block">
            Narration & Dialogue Acting Style
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-5 gap-2">
            {NARRATION_STYLES.map((ns) => {
              const isSelected = project.voiceNarrationStyle === ns.id || (!project.voiceNarrationStyle && ns.id === 'reverent');
              return (
                <button
                  key={ns.id}
                  type="button"
                  onClick={() => {
                    safeVibrate(10);
                    onUpdateAudioSettings({ voiceNarrationStyle: ns.id });
                  }}
                  className={`p-2.5 rounded-xl border text-left transition ${
                    isSelected
                      ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-md'
                      : 'bg-[#0B0E16] border-gray-800 text-gray-400 hover:border-gray-700'
                  }`}
                >
                  <div className="text-base mb-1">{ns.icon}</div>
                  <div className="text-xs font-bold text-white">{ns.label}</div>
                  <div className="text-[10px] text-gray-400 line-clamp-1 mt-0.5">{ns.desc}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Voice Volume Slider */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-gray-400">Voiceover Dialogue Volume</span>
            <span className="text-xs font-mono font-bold text-amber-400">
              {Math.round(project.voiceVolume * 100)}%
            </span>
          </div>
          <input
            type="range"
            min={0}
            max={1}
            step={0.05}
            value={project.voiceVolume}
            onChange={(e) => {
              const val = parseFloat(e.target.value);
              onUpdateAudioSettings({ voiceVolume: val });
              audioEngine.setVoiceVolume(val);
            }}
            className="w-full h-2 bg-gray-800 accent-amber-500 rounded-lg cursor-pointer"
          />
        </div>
      </div>

      {/* 3. Subtitle Customizer (Size, Position, Style, Timing Sync) */}
      <div className="bg-[#121622] p-4 sm:p-5 rounded-2xl border border-gray-800 space-y-4">
        <div>
          <h4 className="text-sm font-bold text-white flex items-center gap-2">
            <Subtitles className="w-4 h-4 text-amber-400" />
            <span>3. Subtitles Customizer (Font Size, Position, Style & Timing Sync)</span>
          </h4>
          <p className="text-[11px] text-gray-400">
            Automatically generates word-level captions in Bengali, Hindi, or English.
          </p>
        </div>

        {/* Style Presets Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
          {SUBTITLE_PRESETS.map((sp) => {
            const isSelected = project.subtitlePreset === sp.value;
            return (
              <button
                key={sp.value}
                type="button"
                onClick={() => {
                  safeVibrate(10);
                  onUpdateAudioSettings({ subtitlePreset: sp.value });
                }}
                className={`p-3 rounded-xl border text-left transition flex items-center justify-between ${
                  isSelected
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-md'
                    : 'bg-[#171D2D] border-gray-800 text-gray-300 hover:border-gray-700'
                }`}
              >
                <div>
                  <div className="text-xs font-bold text-white">{sp.label}</div>
                  <div className="text-[11px] font-mono text-amber-400/90 mt-1">{sp.preview}</div>
                </div>
                {isSelected && <Check className="w-4 h-4 text-amber-400" />}
              </button>
            );
          })}
        </div>

        {/* Position, Font Size & Timing Adjustments */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          {/* Subtitle Position */}
          <div className="space-y-1.5 bg-[#0B0E16] p-3 rounded-xl border border-gray-800">
            <label className="text-xs font-bold text-gray-300 block">Position on Canvas</label>
            <div className="grid grid-cols-3 gap-1">
              {(['top', 'center', 'bottom'] as SubtitlePosition[]).map((pos) => {
                const isSelected = (project.subtitlePosition || 'bottom') === pos;
                return (
                  <button
                    key={pos}
                    type="button"
                    onClick={() => {
                      safeVibrate(10);
                      onUpdateAudioSettings({ subtitlePosition: pos });
                    }}
                    className={`py-1.5 rounded-lg text-xs font-bold capitalize transition flex items-center justify-center gap-1 ${
                      isSelected
                        ? 'bg-amber-500 text-black shadow-md'
                        : 'bg-[#151A26] text-gray-400 hover:text-white'
                    }`}
                  >
                    {pos === 'top' && <AlignVerticalJustifyStart className="w-3.5 h-3.5" />}
                    {pos === 'center' && <AlignVerticalJustifyCenter className="w-3.5 h-3.5" />}
                    {pos === 'bottom' && <AlignVerticalJustifyEnd className="w-3.5 h-3.5" />}
                    <span>{pos}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Subtitle Font Size */}
          <div className="space-y-1.5 bg-[#0B0E16] p-3 rounded-xl border border-gray-800">
            <label className="text-xs font-bold text-gray-300 block">Font Size</label>
            <div className="grid grid-cols-4 gap-1">
              {(['small', 'medium', 'large', 'xlarge'] as SubtitleFontSize[]).map((fs) => {
                const isSelected = (project.subtitleFontSize || 'medium') === fs;
                return (
                  <button
                    key={fs}
                    type="button"
                    onClick={() => {
                      safeVibrate(10);
                      onUpdateAudioSettings({ subtitleFontSize: fs });
                    }}
                    className={`py-1.5 rounded-lg text-[11px] font-bold uppercase transition ${
                      isSelected
                        ? 'bg-amber-500 text-black shadow-md'
                        : 'bg-[#151A26] text-gray-400 hover:text-white'
                    }`}
                  >
                    {fs === 'xlarge' ? 'XL' : fs.charAt(0)}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Timing Synchronization Lead/Lag */}
          <div className="space-y-1.5 bg-[#0B0E16] p-3 rounded-xl border border-gray-800">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-gray-300 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span>Sync Offset</span>
              </label>
              <span className="text-[11px] font-mono text-amber-400">
                {project.subtitleTimingOffsetMs || 0} ms
              </span>
            </div>
            <input
              type="range"
              min={-500}
              max={500}
              step={50}
              value={project.subtitleTimingOffsetMs || 0}
              onChange={(e) => {
                const val = parseInt(e.target.value);
                onUpdateAudioSettings({ subtitleTimingOffsetMs: val });
              }}
              className="w-full h-2 bg-gray-800 accent-amber-500 rounded-lg cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* 4. Sound Effects (SFX) Interactive Library */}
      <div className="bg-[#121622] p-4 sm:p-5 rounded-2xl border border-gray-800 space-y-3">
        <h4 className="text-sm font-bold text-white flex items-center gap-2">
          <Volume2 className="w-4 h-4 text-amber-400" />
          <span>4. Sound Effects (SFX) Library (Tap to Audition)</span>
        </h4>
        <p className="text-xs text-gray-400">
          Built-in synthesizers calibrated for Indian temple bells, celestial chimes, cinematic impacts, cartoon magic & atmospheric thunder.
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
          {SFX_LIST.map((sfx) => (
            <button
              key={sfx.id}
              type="button"
              onClick={() => handleTestSFX(sfx.id)}
              className="p-2.5 rounded-xl bg-[#171D2D] hover:bg-[#20273c] border border-gray-800 hover:border-amber-500/40 text-left transition active:scale-95 group flex items-center gap-2"
            >
              <span className="text-xl group-hover:scale-110 transition">{sfx.icon}</span>
              <div className="min-w-0">
                <div className="text-xs font-bold text-white truncate">{sfx.name}</div>
                <div className="text-[10px] text-amber-400 truncate">{sfx.category}</div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
