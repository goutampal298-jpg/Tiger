import React, { useState } from 'react';
import {
  User,
  Settings,
  Globe,
  Moon,
  Sun,
  Shield,
  Trash2,
  HardDrive,
  CheckCircle2,
  Smartphone,
  ExternalLink,
  Award,
  FileText,
  AlertCircle,
} from 'lucide-react';
import { AppSettings, VideoResolution, AspectRatio } from '../types';
import { safeVibrate } from '../utils/haptics';

interface ProfileSettingsScreenProps {
  settings: AppSettings;
  appLanguage: 'bn' | 'en';
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  onClearCache: () => void;
  onOpenApkModal: () => void;
}

export const ProfileSettingsScreen: React.FC<ProfileSettingsScreenProps> = ({
  settings,
  appLanguage,
  onUpdateSettings,
  onClearCache,
  onOpenApkModal,
}) => {
  const isBn = appLanguage === 'bn';
  const [showConsentTerms, setShowConsentTerms] = useState(false);
  const [showPrivacyPolicy, setShowPrivacyPolicy] = useState(false);

  return (
    <div className="space-y-6 animate-in fade-in duration-300 max-w-4xl mx-auto pb-12">
      {/* User Creator Profile Header */}
      <div className="bg-[#0E121C] border border-gray-800 rounded-3xl p-5 sm:p-6 shadow-xl flex flex-col sm:flex-row items-center gap-5">
        <div className="relative">
          <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-amber-500 via-orange-500 to-amber-200 p-[3px] shadow-xl">
            <div className="w-full h-full rounded-full bg-[#0E121C] flex items-center justify-center text-3xl">
              🐅
            </div>
          </div>
          <div className="absolute bottom-0 right-0 p-1.5 rounded-full bg-emerald-500 text-black shadow-md">
            <CheckCircle2 className="w-3.5 h-3.5" />
          </div>
        </div>

        <div className="space-y-1 text-center sm:text-left flex-1">
          <div className="flex items-center justify-center sm:justify-start gap-2">
            <h2 className="text-xl font-black text-white">TIGER AI VIP CREATOR</h2>
            <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-amber-500/20 text-amber-300 border border-amber-500/30">
              PRO STUDIO
            </span>
          </div>
          <p className="text-xs text-gray-400">
            {isBn ? 'বাংলাভাষী কনটেন্ট নির্মাতাদের জন্য আধুনিক এআই স্টুডিও' : 'AI Video Platform for Bengali & Global Creators'}
          </p>
          <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 pt-2 text-[11px] text-amber-400/90 font-mono">
            <span>⚡ Ultra 4K/8K Video Pipeline</span>
            <span>•</span>
            <span>🎙️ Bengali Neural TTS</span>
          </div>
        </div>

        <button
          onClick={() => {
            safeVibrate(15);
            onOpenApkModal();
          }}
          className="px-4 py-2.5 rounded-2xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 font-bold text-xs flex items-center gap-2 transition active:scale-95"
        >
          <Smartphone className="w-4 h-4 text-amber-400" />
          <span>{isBn ? 'অ্যান্ড্রয়েড APK প্যাকেজ' : 'Android APK Setup'}</span>
        </button>
      </div>

      {/* Settings Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Language & Regional Settings */}
        <div className="bg-[#0E121C] border border-gray-800 rounded-3xl p-5 space-y-4 shadow-xl">
          <div className="flex items-center gap-2 text-white font-bold text-sm">
            <Globe className="w-4 h-4 text-amber-400" />
            <span>{isBn ? 'ভাষা ও আঞ্চলিক নির্বাচন' : 'App Language & Region'}</span>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                safeVibrate(10);
                onUpdateSettings({ appLanguage: 'bn' });
              }}
              className={`p-3 rounded-2xl border text-xs font-bold transition flex items-center justify-center gap-2 ${
                settings.appLanguage === 'bn'
                  ? 'bg-amber-500 text-black border-amber-400 shadow-md'
                  : 'bg-[#141A28] border-gray-800 text-gray-400 hover:text-white'
              }`}
            >
              <span>🇧🇩 বাংলা (Bengali)</span>
            </button>

            <button
              onClick={() => {
                safeVibrate(10);
                onUpdateSettings({ appLanguage: 'en' });
              }}
              className={`p-3 rounded-2xl border text-xs font-bold transition flex items-center justify-center gap-2 ${
                settings.appLanguage === 'en'
                  ? 'bg-amber-500 text-black border-amber-400 shadow-md'
                  : 'bg-[#141A28] border-gray-800 text-gray-400 hover:text-white'
              }`}
            >
              <span>🌐 English (US)</span>
            </button>
          </div>
          <p className="text-[11px] text-gray-400">
            {isBn
              ? 'অ্যাপ্লিকেশন ইন্টারফেস এবং প্রাথমিক গল্প তৈরির ভাষা নির্ধারণ করে।'
              : 'Sets default interface language and narrative synthesis preference.'}
          </p>
        </div>

        {/* Video Defaults */}
        <div className="bg-[#0E121C] border border-gray-800 rounded-3xl p-5 space-y-4 shadow-xl">
          <div className="flex items-center gap-2 text-white font-bold text-sm">
            <Settings className="w-4 h-4 text-amber-400" />
            <span>{isBn ? 'ডিফল্ট ভিডিও মান ও অনুপাত' : 'Default Video Settings'}</span>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-[11px] text-gray-400 font-semibold block mb-1.5">
                {isBn ? 'ডিফল্ট অ্যাসপেক্ট রেশিও' : 'Default Aspect Ratio'}
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                {(['9:16', '16:9', '1:1'] as AspectRatio[]).map((ar) => (
                  <button
                    key={ar}
                    onClick={() => {
                      safeVibrate(10);
                      onUpdateSettings({ defaultAspectRatio: ar });
                    }}
                    className={`py-1.5 rounded-xl text-xs font-bold border transition ${
                      settings.defaultAspectRatio === ar
                        ? 'bg-amber-500 text-black border-amber-400'
                        : 'bg-[#141A28] border-gray-800 text-gray-400 hover:text-white'
                    }`}
                  >
                    {ar}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-[11px] text-gray-400 font-semibold block mb-1.5">
                {isBn ? 'ডিফল্ট রেজোলিউশন' : 'Default Video Quality'}
              </label>
              <div className="grid grid-cols-5 gap-1">
                {(['720p', '1080p', '2k', '4k', '8k'] as VideoResolution[]).map((res) => (
                  <button
                    key={res}
                    onClick={() => {
                      safeVibrate(10);
                      onUpdateSettings({ defaultResolution: res });
                    }}
                    className={`py-1.5 rounded-lg text-[11px] font-bold uppercase border transition ${
                      settings.defaultResolution === res
                        ? 'bg-amber-500 text-black border-amber-400'
                        : 'bg-[#141A28] border-gray-800 text-gray-400 hover:text-white'
                    }`}
                  >
                    {res}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Storage & Legal Safety */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Storage Management */}
        <div className="bg-[#0E121C] border border-gray-800 rounded-3xl p-5 space-y-3 shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-white font-bold text-sm">
              <HardDrive className="w-4 h-4 text-amber-400" />
              <span>{isBn ? 'স্টোরেজ ও ক্যাশ ম্যানেজমেন্ট' : 'Storage & Cache Management'}</span>
            </div>
          </div>
          <p className="text-xs text-gray-400">
            {isBn
              ? 'লোকালস্টোরেজে ড্রাফটস ও তৈরি করা সিন সংরক্ষিত থাকে। প্রয়োজনে ক্যাশ খালি করুন।'
              : 'Project drafts and rendered scene textures are cached locally in your browser/app.'}
          </p>

          <button
            onClick={() => {
              safeVibrate(20);
              onClearCache();
            }}
            className="w-full py-2.5 rounded-xl bg-red-950/40 hover:bg-red-900/40 border border-red-500/40 text-red-300 font-bold text-xs flex items-center justify-center gap-2 transition active:scale-95"
          >
            <Trash2 className="w-4 h-4 text-red-400" />
            <span>{isBn ? 'ক্যাশ ও টেম্পোরারি ফাইল মুছুন' : 'Clear Temporary Cache'}</span>
          </button>
        </div>

        {/* Legal Consent & Likeness Protection */}
        <div className="bg-[#0E121C] border border-gray-800 rounded-3xl p-5 space-y-3 shadow-xl">
          <div className="flex items-center gap-2 text-white font-bold text-sm">
            <Shield className="w-4 h-4 text-emerald-400" />
            <span>{isBn ? 'ভয়েস ক্লোন ও নীতি নির্দেশিকা' : 'Voice Consent & AI Ethics'}</span>
          </div>
          <p className="text-xs text-gray-400">
            {isBn
              ? 'ব্যক্তিগত ভয়েস ক্লোন করার ক্ষেত্রে ব্যবহারকারীর বৈধ সম্মতি ও অনুমতি বাধ্যতামূলক।'
              : 'Explicit legal consent is required before cloning voice or animating realistic likeness.'}
          </p>

          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={() => setShowConsentTerms(true)}
              className="flex-1 py-2 rounded-xl bg-[#141A28] hover:bg-[#1A2234] border border-gray-800 text-gray-300 text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <FileText className="w-3.5 h-3.5 text-amber-400" />
              <span>{isBn ? 'সম্মতি চুক্তি' : 'Consent Agreement'}</span>
            </button>
            <button
              onClick={() => setShowPrivacyPolicy(true)}
              className="flex-1 py-2 rounded-xl bg-[#141A28] hover:bg-[#1A2234] border border-gray-800 text-gray-300 text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <FileText className="w-3.5 h-3.5 text-blue-400" />
              <span>{isBn ? 'প্রাইভেসি পলিসি' : 'Privacy Policy'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Consent Modal */}
      {showConsentTerms && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0E121C] border border-amber-500/40 rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-2xl">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-base">
              <Shield className="w-5 h-5" />
              <h3>Voice Clone Legal Authorization & Consent</h3>
            </div>
            <div className="text-xs text-gray-300 space-y-2 max-h-60 overflow-y-auto pr-2 leading-relaxed">
              <p>
                By using the Voice Clone or Personal Likeness features in TIGER AI CREATOR, you
                explicitly confirm and warrant that:
              </p>
              <ul className="list-disc pl-5 space-y-1 text-gray-400">
                <li>You are the rightful owner of the voice sample, or hold explicit written permission from the speaker.</li>
                <li>The synthesized voice will never be used for impersonation, fraud, defamation, or political deception.</li>
                <li>All processing respects local privacy laws and content creation guidelines.</li>
              </ul>
            </div>
            <button
              onClick={() => setShowConsentTerms(false)}
              className="w-full py-2.5 rounded-xl bg-amber-500 text-black font-extrabold text-xs"
            >
              I Understand & Agree
            </button>
          </div>
        </div>
      )}

      {/* Privacy Modal */}
      {showPrivacyPolicy && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0E121C] border border-gray-700 rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-2xl">
            <div className="flex items-center gap-2 text-white font-bold text-base">
              <FileText className="w-5 h-5 text-blue-400" />
              <h3>Privacy Policy & Data Processing</h3>
            </div>
            <div className="text-xs text-gray-300 space-y-2 max-h-60 overflow-y-auto pr-2 leading-relaxed">
              <p>
                TIGER AI CREATOR processes prompts and media through secure, server-side Google Gemini
                and Veo APIs. No secret keys or unencrypted audio recordings are ever exposed on the
                client device.
              </p>
              <p>
                User projects are persisted in client LocalStorage and can be exported as MP4 files
                at any time.
              </p>
            </div>
            <button
              onClick={() => setShowPrivacyPolicy(false)}
              className="w-full py-2.5 rounded-xl bg-gray-800 text-white font-bold text-xs"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
