import {
  AspectRatio,
  CameraMotion,
  CharacterReference,
  Project,
  Scene,
  SoundEffectType,
  StoryLanguage,
  StoryType,
  VisualStyle,
} from '../types';

export interface ImageAnalysisResult {
  subjectType: string;
  title: string;
  summary: string;
  character?: {
    isHumanoid: boolean;
    genderOrForm?: string;
    estimatedAge?: string;
    faceFeatures?: string;
    skinTone?: string;
    hair?: string;
    facialHair?: string;
    clothingAndAttire?: string;
    bodyBuild?: string;
    keyIdentifiers?: string;
  };
  environment?: {
    setting?: string;
    lighting?: string;
    colorPalette?: string[];
    mood?: string;
  };
  recommendedStoryTypes?: string[];
  recommendedStyles?: string[];
}

export async function analyzeImage(
  imageBase64: string,
  mimeType: string = 'image/jpeg'
): Promise<ImageAnalysisResult> {
  const response = await fetch('/api/analyze-image', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ imageBase64, mimeType }),
  });

  if (!response.ok) {
    const errData = await response.json().catch(() => ({}));
    throw new Error(errData.error || 'Failed to analyze image');
  }

  const data = await response.json();
  return data.analysis;
}

export async function generateStory(params: {
  language: StoryLanguage;
  storyType: StoryType;
  durationSeconds: number;
  userStory?: string;
  imageAnalysis?: ImageAnalysisResult | null;
  customNotes?: string;
}): Promise<{
  title: string;
  englishTitle?: string;
  logline: string;
  fullScript: string;
  emotionalTone?: string;
  suggestedBgm?: string;
  pacing?: string;
  keyTakeawayOrMoral?: string;
}> {
  const response = await fetch('/api/generate-story', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!response.ok) {
    const errData = await response.json().catch(() => ({}));
    throw new Error(errData.error || 'Failed to generate story');
  }

  const data = await response.json();
  return data.story;
}

export async function breakScenes(params: {
  story: { title: string; fullScript: string };
  language: StoryLanguage;
  storyType: StoryType;
  durationSeconds: number;
  visualStyle: VisualStyle;
  characterReference?: CharacterReference | null;
}): Promise<{
  totalDuration: number;
  characterPromptAnchor?: string;
  scenes: Array<{
    sceneNumber: number;
    duration: number;
    narration: string;
    englishNarration?: string;
    visualPrompt: string;
    cameraMotion: any;
    motionStrength: number;
    soundEffect: any;
    subtitles: Array<{ text: string; startMs: number; endMs: number }>;
  }>;
}> {
  const response = await fetch('/api/break-scenes', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!response.ok) {
    const errData = await response.json().catch(() => ({}));
    throw new Error(errData.error || 'Failed to break story into scenes');
  }

  const data = await response.json();
  return data.breakdown;
}

export async function batchFillSceneScripts(params: {
  storyTitle: string;
  language: StoryLanguage;
  storyType: StoryType;
  visualStyle: VisualStyle;
  existingScenesSummary: Array<{
    sceneNumber: number;
    narration: string;
    visualPrompt: string;
  }>;
  scenesToFill: Array<{
    sceneNumber: number;
    duration: number;
    currentNarration?: string;
    currentVisualPrompt?: string;
  }>;
  guidancePrompt?: string;
  characterDescription?: string;
}): Promise<
  Array<{
    sceneNumber: number;
    narration: string;
    englishNarration?: string;
    visualPrompt: string;
    cameraMotion: CameraMotion;
    motionStrength: number;
    soundEffect: SoundEffectType;
  }>
> {
  try {
    const response = await fetch('/api/batch-fill-scenes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });

    if (response.ok) {
      const data = await response.json();
      if (Array.isArray(data.scenes) && data.scenes.length > 0) {
        return data.scenes;
      }
    }
  } catch (err) {
    console.warn('Batch scene fill API failed, generating contextual fallback scripts:', err);
  }

  // Graceful high-quality client fallback if server endpoint is unavailable
  const fallbackMotions: CameraMotion[] = [
    'cinematic-push',
    'slow-motion',
    'zoom-in',
    'pan-left',
    'tilt-up',
    'pan-right',
  ];
  const fallbackSFX: SoundEffectType[] = [
    'temple_bell',
    'whoosh',
    'divine_chime',
    'nature_wind',
    'cinematic_hit',
  ];

  return params.scenesToFill.map((scene, i) => {
    const prevContext =
      params.existingScenesSummary[params.existingScenesSummary.length - 1]?.narration ||
      params.storyTitle;
    const motion = fallbackMotions[i % fallbackMotions.length];
    const sfx = fallbackSFX[i % fallbackSFX.length];

    const narration =
      scene.currentNarration && !scene.currentNarration.startsWith('Scene ')
        ? scene.currentNarration
        : `${params.storyTitle} continues with intense revelation in scene ${scene.sceneNumber}.`;

    const visualPrompt =
      scene.currentVisualPrompt && !scene.currentVisualPrompt.startsWith('Scene ')
        ? scene.currentVisualPrompt
        : `${params.visualStyle} scene depicting key moment of ${params.storyTitle}, ultra detailed, cinematic atmosphere, 8k resolution, dramatic lighting`;

    return {
      sceneNumber: scene.sceneNumber,
      narration,
      englishNarration: narration,
      visualPrompt,
      cameraMotion: motion,
      motionStrength: 7,
      soundEffect: sfx,
    };
  });
}

export async function generateTTS(params: {
  text: string;
  voice?: string;
  style?: string;
}): Promise<{
  audioBase64: string | null;
  mimeType?: string;
  fallbackWebSpeech?: boolean;
}> {
  try {
    const response = await fetch('/api/generate-tts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });

    if (response.ok) {
      const data = await response.json();
      return data;
    }
  } catch (err) {
    console.warn('Network TTS unavailable, falling back to client synthesis', err);
  }

  return { audioBase64: null, fallbackWebSpeech: true };
}

export async function generateImage(params: {
  prompt: string;
  aspectRatio: string;
  visualStyle: VisualStyle;
  characterReferenceBase64?: string;
}): Promise<{
  imageUrl: string | null;
  source?: string;
  needsSynthesis?: boolean;
}> {
  try {
    const response = await fetch('/api/generate-image', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });

    if (response.ok) {
      const data = await response.json();
      return data;
    }
  } catch (err) {
    console.warn('AI Image Generation remote call failed, using high-res visual synthesizer', err);
  }

  return { imageUrl: null, needsSynthesis: true };
}

// Client-side high-fidelity procedural canvas visual generator
// when remote image API is unavailable or for instant responsive scene rendering
export function createProceduralSceneCanvas(
  arg1: number | string,
  arg2?: number | VisualStyle,
  arg3?: VisualStyle | AspectRatio,
  arg4?: number,
  arg5?: string,
  arg6?: string
): Promise<string> {
  let width = 720;
  let height = 1280;
  let style: VisualStyle = 'Cinematic';
  let sceneNumber = 1;
  let baseImage: string | undefined = undefined;
  let promptText = '';

  if (typeof arg1 === 'number') {
    width = arg1;
    height = (arg2 as number) || 1280;
    style = (arg3 as VisualStyle) || 'Cinematic';
    sceneNumber = arg4 || 1;
    baseImage = arg5;
    promptText = arg6 || '';
  } else {
    // polymorphic: arg1 is promptText, arg2 is style, arg3 is aspectRatio
    promptText = arg1;
    style = (arg2 as VisualStyle) || 'Cinematic';
    const ratio = (arg3 as AspectRatio) || '9:16';
    if (ratio === '16:9') {
      width = 1280;
      height = 720;
    } else if (ratio === '1:1') {
      width = 1080;
      height = 1080;
    } else {
      width = 720;
      height = 1280;
    }
    sceneNumber = arg4 || 1;
    baseImage = arg5;
  }

  return new Promise((resolve) => {
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return resolve('');

    if (baseImage) {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        // Draw image covering the canvas
        const hRatio = canvas.width / img.width;
        const vRatio = canvas.height / img.height;
        const ratio = Math.max(hRatio, vRatio);
        const centerShiftX = (canvas.width - img.width * ratio) / 2;
        const centerShiftY = (canvas.height - img.height * ratio) / 2;
        ctx.drawImage(
          img,
          0,
          0,
          img.width,
          img.height,
          centerShiftX,
          centerShiftY,
          img.width * ratio,
          img.height * ratio
        );

        // Apply cinematic visual styling overlay
        applyCinematicGrade(ctx, canvas.width, canvas.height, style, sceneNumber);
        resolve(canvas.toDataURL('image/jpeg', 0.92));
      };
      img.onerror = () => {
        drawFallbackGradientScene(ctx, canvas.width, canvas.height, style, sceneNumber, promptText);
        resolve(canvas.toDataURL('image/jpeg', 0.92));
      };
      img.src = baseImage;
    } else {
      drawFallbackGradientScene(ctx, canvas.width, canvas.height, style, sceneNumber, promptText);
      resolve(canvas.toDataURL('image/jpeg', 0.92));
    }
  });
}

function applyCinematicGrade(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  style: VisualStyle,
  sceneNum: number
) {
  // Vignette
  const vignette = ctx.createRadialGradient(w / 2, h / 2, w * 0.3, w / 2, h / 2, w * 0.85);
  vignette.addColorStop(0, 'rgba(0,0,0,0)');
  vignette.addColorStop(1, 'rgba(5, 7, 12, 0.7)');
  ctx.fillStyle = vignette;
  ctx.fillRect(0, 0, w, h);

  // Style-specific lighting accents
  if (style === 'Devotional' || style === 'Indian mythology') {
    // Golden divine aura
    const aura = ctx.createRadialGradient(w * 0.5, h * 0.3, 10, w * 0.5, h * 0.3, w * 0.7);
    aura.addColorStop(0, 'rgba(255, 215, 0, 0.35)');
    aura.addColorStop(0.5, 'rgba(255, 140, 0, 0.15)');
    aura.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = aura;
    ctx.fillRect(0, 0, w, h);

    // Divine shimmer particles
    ctx.fillStyle = 'rgba(255, 235, 150, 0.8)';
    for (let i = 0; i < 24; i++) {
      const px = (Math.sin(i * 13 + sceneNum) * 0.5 + 0.5) * w;
      const py = (Math.cos(i * 17 + sceneNum) * 0.5 + 0.5) * h;
      const pr = 2 + (i % 3);
      ctx.beginPath();
      ctx.arc(px, py, pr, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (style === 'Cinematic' || style === 'Film style') {
    // Teal and orange grading
    ctx.fillStyle = 'rgba(0, 150, 200, 0.08)';
    ctx.fillRect(0, 0, w, h);
    const grad = ctx.createLinearGradient(0, h * 0.7, 0, h);
    grad.addColorStop(0, 'rgba(0,0,0,0)');
    grad.addColorStop(1, 'rgba(255, 110, 20, 0.12)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);
  }
}

function drawFallbackGradientScene(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  style: VisualStyle,
  sceneNum: number,
  promptText: string
) {
  // Rich atmospheric background based on style
  const grad = ctx.createLinearGradient(0, 0, w, h);
  if (style === 'Devotional' || style === 'Indian mythology') {
    grad.addColorStop(0, '#1a0b2e');
    grad.addColorStop(0.4, '#4a154b');
    grad.addColorStop(0.8, '#b84a14');
    grad.addColorStop(1, '#ff9e00');
  } else if (style === 'Horror' as any) {
    grad.addColorStop(0, '#05070a');
    grad.addColorStop(0.5, '#121824');
    grad.addColorStop(1, '#000000');
  } else {
    grad.addColorStop(0, '#0d1322');
    grad.addColorStop(0.4, '#1b2a47');
    grad.addColorStop(0.8, '#2d4059');
    grad.addColorStop(1, '#ff5722');
  }
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  // Celestial aura / light rays
  const sunGrad = ctx.createRadialGradient(w * 0.5, h * 0.4, 30, w * 0.5, h * 0.4, w * 0.6);
  sunGrad.addColorStop(0, 'rgba(255, 230, 150, 0.5)');
  sunGrad.addColorStop(0.3, 'rgba(255, 150, 50, 0.2)');
  sunGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = sunGrad;
  ctx.beginPath();
  ctx.arc(w * 0.5, h * 0.4, w * 0.6, 0, Math.PI * 2);
  ctx.fill();

  // Subtle decorative scene graphic
  ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
  ctx.beginPath();
  ctx.arc(w / 2, h / 2, Math.min(w, h) * 0.35, 0, Math.PI * 2);
  ctx.fill();

  // Scene label tag
  ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
  ctx.font = 'bold 28px "Plus Jakarta Sans", sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(`SCENE ${sceneNum}`, w / 2, h * 0.45);

  ctx.fillStyle = 'rgba(255, 215, 0, 0.9)';
  ctx.font = '600 20px "Plus Jakarta Sans", sans-serif';
  ctx.fillText(style.toUpperCase(), w / 2, h * 0.5);

  // Prompt excerpt
  if (promptText) {
    ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
    ctx.font = '16px "Plus Jakarta Sans", sans-serif';
    const cleanP = promptText.length > 65 ? promptText.slice(0, 62) + '...' : promptText;
    ctx.fillText(cleanP, w / 2, h * 0.56);
  }

  applyCinematicGrade(ctx, w, h, style, sceneNum);
}

export async function expandStory(params: {
  idea: string;
  language?: StoryLanguage;
  videoStyle?: string;
  durationSeconds?: number;
}): Promise<{
  title: string;
  englishTitle?: string;
  logline: string;
  expandedPrompt: string;
  narrationScript: string;
  soundEffect?: string;
  suggestedBgm?: string;
  aspectRatio?: string;
}> {
  const response = await fetch('/api/expand-story', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!response.ok) {
    const errData = await response.json().catch(() => ({}));
    throw new Error(errData.error || 'Failed to expand story idea');
  }

  const data = await response.json();
  return data.expansion;
}

export async function requestVideoGeneration(params: {
  prompt: string;
  aspectRatio?: string;
  resolution?: string;
  videoStyle?: string;
  durationSeconds?: number;
  imageBytes?: string;
}): Promise<{
  success: boolean;
  operationName: string | null;
  mode: 'veo-api' | 'studio-compositor';
  message?: string;
}> {
  const response = await fetch('/api/generate-video', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Video generation request failed');
  }

  return await response.json();
}

export async function checkVideoStatus(operationName: string): Promise<{
  done: boolean;
  error?: any;
  response?: any;
}> {
  const response = await fetch('/api/video-status', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ operationName }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to check video status');
  }

  return await response.json();
}

export async function downloadGeneratedVideo(operationName: string): Promise<Blob> {
  const response = await fetch('/api/video-download', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ operationName }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to download video stream');
  }

  return await response.blob();
}

export async function generateTalkingPhoto(params: {
  imageBase64: string;
  dialogue: string;
  language?: string;
  voice?: string;
}): Promise<{
  facialDynamics: any;
  dialogue: string;
  language: string;
  voice: string;
}> {
  const response = await fetch('/api/talking-photo', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to generate talking photo');
  }
  return await response.json();
}

export async function cloneVoiceWithConsent(params: {
  voiceSampleBase64: string;
  speakerName: string;
  consentConfirmed: boolean;
}): Promise<{
  profile: any;
}> {
  const response = await fetch('/api/voice-clone', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to clone voice');
  }
  return await response.json();
}

export async function removeBackground(params: {
  imageBase64: string;
  replacementType?: 'transparent' | 'color' | 'ai-prompt';
  aiPrompt?: string;
  bgColor?: string;
}): Promise<{
  segmentation: any;
  replacementType: string;
}> {
  const response = await fetch('/api/remove-bg', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to remove background');
  }
  return await response.json();
}

export async function generateThumbnail(params: {
  title: string;
  topic?: string;
  visualPrompt?: string;
  aspectRatio?: '16:9' | '9:16';
  style?: string;
  language?: string;
}): Promise<{
  thumbnail: any;
}> {
  const response = await fetch('/api/generate-thumbnail', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to generate thumbnail');
  }
  return await response.json();
}

export async function generateYouTubeMetadata(params: {
  title: string;
  topic?: string;
  language?: string;
}): Promise<{
  metadata: any;
}> {
  const response = await fetch('/api/generate-metadata', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to generate metadata');
  }
  return await response.json();
}

export async function enhanceVideoProfile(params: {
  mode: string;
  sharpness?: number;
  denoise?: number;
}): Promise<{
  appliedFilters: any;
  message: string;
}> {
  const response = await fetch('/api/enhance-video', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to apply video enhancement');
  }
  return await response.json();
}

