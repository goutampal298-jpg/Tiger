import { BgmGenre, SoundEffectType } from '../types';

class AudioEngine {
  private ctx: AudioContext | null = null;
  private bgmGain: GainNode | null = null;
  private voiceGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private masterGain: GainNode | null = null;
  private streamDestination: MediaStreamAudioDestinationNode | null = null;

  private isBgmPlaying: boolean = false;
  private currentGenre: BgmGenre = 'None';
  private activeOscillators: (OscillatorNode | AudioBufferSourceNode)[] = [];
  private loopTimer: any = null;

  private speechSynthUtterance: SpeechSynthesisUtterance | null = null;
  private currentTtsSource: AudioBufferSourceNode | null = null;

  public init() {
    if (!this.ctx) {
      try {
        const AudioContextClass =
          typeof window !== 'undefined'
            ? window.AudioContext || (window as any).webkitAudioContext
            : null;

        if (!AudioContextClass) {
          console.warn('Web Audio API not supported in this environment');
          return;
        }

        this.ctx = new AudioContextClass();

        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.value = 1.0;

        this.bgmGain = this.ctx.createGain();
        this.bgmGain.gain.value = 0.4;

        this.voiceGain = this.ctx.createGain();
        this.voiceGain.gain.value = 1.0;

        this.sfxGain = this.ctx.createGain();
        this.sfxGain.gain.value = 0.8;

        this.bgmGain.connect(this.masterGain);
        this.voiceGain.connect(this.masterGain);
        this.sfxGain.connect(this.masterGain);

        // Connect to hardware speakers
        this.masterGain.connect(this.ctx.destination);

        // Connect to stream destination for canvas video recording!
        if (typeof this.ctx.createMediaStreamDestination === 'function') {
          this.streamDestination = this.ctx.createMediaStreamDestination();
          this.masterGain.connect(this.streamDestination);
        }
      } catch (err) {
        console.warn('Web Audio API initialization failed:', err);
      }
    }

    if (this.ctx && this.ctx.state === 'suspended') {
      try {
        this.ctx.resume().catch(() => {});
      } catch {
        // ignore resume error
      }
    }
  }

  public getAudioStream(): MediaStream | null {
    this.init();
    return this.streamDestination ? this.streamDestination.stream : null;
  }

  public setBgmVolume(volume: number) {
    if (this.bgmGain && this.ctx) {
      this.bgmGain.gain.setTargetAtTime(Math.max(0, Math.min(1, volume)), this.ctx.currentTime, 0.05);
    }
  }

  public setVoiceVolume(volume: number) {
    if (this.voiceGain && this.ctx) {
      this.voiceGain.gain.setTargetAtTime(Math.max(0, Math.min(1, volume)), this.ctx.currentTime, 0.05);
    }
  }

  // ----------------------------------------------------
  // Sound Effects (SFX) Synthesizer
  // ----------------------------------------------------
  public playSFX(type: SoundEffectType) {
    if (type === 'none') return;
    this.init();
    if (!this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;

    switch (type) {
      case 'temple_bell': {
        // Indian Temple Bell: rich fundamental (440Hz + 880Hz + 1320Hz + 2200Hz) with metal resonance
        [440, 880, 1320, 2200, 3100].forEach((freq, idx) => {
          const osc = this.ctx!.createOscillator();
          const gain = this.ctx!.createGain();
          osc.type = idx === 0 ? 'sine' : 'triangle';
          osc.frequency.setValueAtTime(freq, t);

          const decay = 3.5 / (idx * 0.5 + 1);
          gain.gain.setValueAtTime(0.3 / (idx + 1), t);
          gain.gain.exponentialRampToValueAtTime(0.0001, t + decay);

          osc.connect(gain);
          gain.connect(this.sfxGain!);
          osc.start(t);
          osc.stop(t + decay);
        });
        break;
      }

      case 'divine_chime': {
        // Celestial wind chime cascade
        [784, 988, 1175, 1318, 1568, 1975].forEach((freq, idx) => {
          const osc = this.ctx!.createOscillator();
          const gain = this.ctx!.createGain();
          osc.type = 'sine';
          const startTime = t + idx * 0.08;
          osc.frequency.setValueAtTime(freq, startTime);

          gain.gain.setValueAtTime(0.2, startTime);
          gain.gain.exponentialRampToValueAtTime(0.0001, startTime + 2.0);

          osc.connect(gain);
          gain.connect(this.sfxGain!);
          osc.start(startTime);
          osc.stop(startTime + 2.0);
        });
        break;
      }

      case 'cinematic_hit': {
        // Deep cinematic impact with sub drop and noise transient
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(140, t);
        osc.frequency.exponentialRampToValueAtTime(32, t + 0.6);

        gain.gain.setValueAtTime(0.8, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 1.2);

        osc.connect(gain);
        gain.connect(this.sfxGain);
        osc.start(t);
        osc.stop(t + 1.2);
        break;
      }

      case 'whoosh': {
        // Filtered noise sweep
        const bufferSize = this.ctx.sampleRate * 0.5;
        const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          data[i] = Math.random() * 2 - 1;
        }

        const noise = this.ctx.createBufferSource();
        noise.buffer = buffer;

        const filter = this.ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(200, t);
        filter.frequency.exponentialRampToValueAtTime(3000, t + 0.25);
        filter.frequency.exponentialRampToValueAtTime(300, t + 0.5);
        filter.Q.value = 3.0;

        const gain = this.ctx.createGain();
        gain.gain.setValueAtTime(0.01, t);
        gain.gain.linearRampToValueAtTime(0.5, t + 0.25);
        gain.gain.linearRampToValueAtTime(0.001, t + 0.5);

        noise.connect(filter);
        filter.connect(gain);
        gain.connect(this.sfxGain);

        noise.start(t);
        noise.stop(t + 0.5);
        break;
      }

      case 'thunder': {
        // Low rumble thunder
        const bufferSize = this.ctx.sampleRate * 1.5;
        const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          data[i] = (Math.random() * 2 - 1) * 0.8;
        }

        const noise = this.ctx.createBufferSource();
        noise.buffer = buffer;

        const filter = this.ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(180, t);
        filter.frequency.linearRampToValueAtTime(80, t + 1.5);

        const gain = this.ctx.createGain();
        gain.gain.setValueAtTime(0.6, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 1.5);

        noise.connect(filter);
        filter.connect(gain);
        gain.connect(this.sfxGain);

        noise.start(t);
        noise.stop(t + 1.5);
        break;
      }

      case 'heartbeat': {
        // Double pulse thump
        [0, 0.22].forEach((offset) => {
          const osc = this.ctx!.createOscillator();
          const gain = this.ctx!.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(65, t + offset);
          osc.frequency.exponentialRampToValueAtTime(35, t + offset + 0.15);

          gain.gain.setValueAtTime(0.7, t + offset);
          gain.gain.exponentialRampToValueAtTime(0.001, t + offset + 0.15);

          osc.connect(gain);
          gain.connect(this.sfxGain!);
          osc.start(t + offset);
          osc.stop(t + offset + 0.15);
        });
        break;
      }

      case 'magic_sparkle': {
        // Fast ascending twinkle
        [523.25, 659.25, 783.99, 1046.5, 1318.5, 1567.98, 2093.0].forEach((freq, idx) => {
          const osc = this.ctx!.createOscillator();
          const gain = this.ctx!.createGain();
          osc.type = 'triangle';
          const startTime = t + idx * 0.05;
          osc.frequency.setValueAtTime(freq, startTime);

          gain.gain.setValueAtTime(0.2, startTime);
          gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.4);

          osc.connect(gain);
          gain.connect(this.sfxGain!);
          osc.start(startTime);
          osc.stop(startTime + 0.4);
        });
        break;
      }

      case 'nature_wind': {
        // Gentle soothing breeze
        const bufferSize = this.ctx.sampleRate * 2.0;
        const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          data[i] = Math.random() * 2 - 1;
        }

        const noise = this.ctx.createBufferSource();
        noise.buffer = buffer;

        const filter = this.ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(400, t);
        filter.Q.value = 1.2;

        const gain = this.ctx.createGain();
        gain.gain.setValueAtTime(0.01, t);
        gain.gain.linearRampToValueAtTime(0.25, t + 0.8);
        gain.gain.linearRampToValueAtTime(0.01, t + 2.0);

        noise.connect(filter);
        filter.connect(gain);
        gain.connect(this.sfxGain);

        noise.start(t);
        noise.stop(t + 2.0);
        break;
      }
    }
  }

  // ----------------------------------------------------
  // Royalty-Free Background Music Synthesizer
  // ----------------------------------------------------
  public startBGM(genre: BgmGenre) {
    if (genre === 'None') {
      this.stopBGM();
      return;
    }

    this.init();
    if (this.isBgmPlaying && this.currentGenre === genre) return;
    this.stopBGM();

    this.isBgmPlaying = true;
    this.currentGenre = genre;

    this.scheduleBgmLoop(genre);
  }

  public stopBGM() {
    this.isBgmPlaying = false;
    if (this.loopTimer) {
      clearTimeout(this.loopTimer);
      this.loopTimer = null;
    }
    this.activeOscillators.forEach((osc) => {
      try {
        osc.stop();
        osc.disconnect();
      } catch {}
    });
    this.activeOscillators = [];
  }

  private scheduleBgmLoop(genre: BgmGenre) {
    if (!this.isBgmPlaying || !this.ctx || !this.bgmGain) return;

    const loopLengthSeconds = 6.0;
    const t = this.ctx.currentTime;

    if (genre === 'Devotional (Flute & Sitar)') {
      // Raag Yaman / Bhupali drone in D (D3 = 146.83, A3 = 220, D4 = 293.66, F#4 = 369.99)
      const droneFreqs = [146.83, 220.0, 293.66];
      droneFreqs.forEach((freq) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, t);

        // Lowpass filter for warm tanpura resonance
        const filter = this.ctx!.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(550, t);

        gain.gain.setValueAtTime(0.08, t);
        gain.gain.linearRampToValueAtTime(0.12, t + 3.0);
        gain.gain.linearRampToValueAtTime(0.08, t + loopLengthSeconds);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.bgmGain!);

        osc.start(t);
        osc.stop(t + loopLengthSeconds);
        this.activeOscillators.push(osc);
      });

      // Melodic Bansuri (Flute) Phrase: D4, E4, F#4, A4, B4, D5
      const fluteNotes = [
        { f: 293.66, at: 0.2, dur: 1.2 },
        { f: 369.99, at: 1.5, dur: 1.0 },
        { f: 440.00, at: 2.6, dur: 1.4 },
        { f: 493.88, at: 4.1, dur: 0.8 },
        { f: 587.33, at: 5.0, dur: 0.9 },
      ];

      fluteNotes.forEach((n) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(n.f, t + n.at);

        // Gentle breath vibrato
        const vibrato = this.ctx!.createOscillator();
        vibrato.frequency.value = 5.0; // 5 Hz
        const vibGain = this.ctx!.createGain();
        vibGain.gain.value = 4.0;
        vibrato.connect(osc.frequency);
        vibrato.start(t + n.at);
        vibrato.stop(t + n.at + n.dur);

        gain.gain.setValueAtTime(0.001, t + n.at);
        gain.gain.linearRampToValueAtTime(0.15, t + n.at + 0.15);
        gain.gain.exponentialRampToValueAtTime(0.001, t + n.at + n.dur);

        osc.connect(gain);
        gain.connect(this.bgmGain!);
        osc.start(t + n.at);
        osc.stop(t + n.at + n.dur);
        this.activeOscillators.push(osc);
      });
    } else if (genre === 'Cinematic Orchestral') {
      // Dramatic C minor / Eb progression
      const chords = [
        { freqs: [130.81, 155.56, 196.00], start: 0, dur: 3.0 }, // Cm
        { freqs: [116.54, 155.56, 174.61], start: 3.0, dur: 3.0 }, // Bb
      ];

      chords.forEach((c) => {
        c.freqs.forEach((freq) => {
          const osc = this.ctx!.createOscillator();
          const gain = this.ctx!.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(freq, t + c.start);

          gain.gain.setValueAtTime(0.01, t + c.start);
          gain.gain.linearRampToValueAtTime(0.15, t + c.start + 0.8);
          gain.gain.linearRampToValueAtTime(0.01, t + c.start + c.dur);

          osc.connect(gain);
          gain.connect(this.bgmGain!);
          osc.start(t + c.start);
          osc.stop(t + c.start + c.dur);
          this.activeOscillators.push(osc);
        });
      });
    } else if (genre === 'Emotional Piano') {
      // Gentle arpeggio
      const notes = [
        { f: 261.63, at: 0 },
        { f: 329.63, at: 0.6 },
        { f: 392.00, at: 1.2 },
        { f: 523.25, at: 1.8 },
        { f: 220.00, at: 3.0 },
        { f: 261.63, at: 3.6 },
        { f: 329.63, at: 4.2 },
        { f: 440.00, at: 4.8 },
      ];

      notes.forEach((n) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(n.f, t + n.at);

        gain.gain.setValueAtTime(0.2, t + n.at);
        gain.gain.exponentialRampToValueAtTime(0.001, t + n.at + 1.2);

        osc.connect(gain);
        gain.connect(this.bgmGain!);
        osc.start(t + n.at);
        osc.stop(t + n.at + 1.2);
        this.activeOscillators.push(osc);
      });
    } else if (genre === 'Funny Cartoon Bouncy') {
      // Playful bouncy marimba / pizzicato notes: C5, E5, G5, A5, G5, E5, C5, bouncy rhythm
      const notes = [
        { f: 523.25, at: 0.0, dur: 0.2 },
        { f: 659.25, at: 0.4, dur: 0.2 },
        { f: 783.99, at: 0.8, dur: 0.25 },
        { f: 880.00, at: 1.2, dur: 0.3 },
        { f: 783.99, at: 1.8, dur: 0.2 },
        { f: 659.25, at: 2.2, dur: 0.2 },
        { f: 587.33, at: 2.6, dur: 0.3 },
        { f: 523.25, at: 3.2, dur: 0.4 },
        { f: 659.25, at: 4.0, dur: 0.2 },
        { f: 783.99, at: 4.5, dur: 0.25 },
        { f: 1046.5, at: 5.0, dur: 0.4 },
      ];

      notes.forEach((n) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(n.f, t + n.at);

        gain.gain.setValueAtTime(0.25, t + n.at);
        gain.gain.exponentialRampToValueAtTime(0.001, t + n.at + n.dur);

        osc.connect(gain);
        gain.connect(this.bgmGain!);
        osc.start(t + n.at);
        osc.stop(t + n.at + n.dur);
        this.activeOscillators.push(osc);
      });
    } else if (genre === 'Game Synthwave Battle') {
      // 80s Cyberpunk Synthwave pumping eighth-note bass (110Hz, 130Hz)
      const bassNotes = [110, 110, 130.8, 110, 146.8, 130.8, 110, 98];
      bassNotes.forEach((f, idx) => {
        const at = (idx * loopLengthSeconds) / bassNotes.length;
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        const filter = this.ctx!.createBiquadFilter();

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(f, t + at);
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(450, t + at);
        filter.frequency.exponentialRampToValueAtTime(150, t + at + 0.3);

        gain.gain.setValueAtTime(0.2, t + at);
        gain.gain.exponentialRampToValueAtTime(0.01, t + at + 0.35);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.bgmGain!);
        osc.start(t + at);
        osc.stop(t + at + 0.38);
        this.activeOscillators.push(osc);
      });
    } else if (genre === 'Adventure Heroic') {
      // Epic brass fanfare chords (D major / G major / A major)
      const fanfareChords = [
        { freqs: [146.83, 220.0, 293.66, 369.99], at: 0.0, dur: 1.8 },
        { freqs: [196.00, 246.94, 293.66, 392.00], at: 2.0, dur: 1.8 },
        { freqs: [220.00, 277.18, 329.63, 440.00], at: 4.0, dur: 1.8 },
      ];

      fanfareChords.forEach((chord) => {
        chord.freqs.forEach((freq) => {
          const osc = this.ctx!.createOscillator();
          const gain = this.ctx!.createGain();
          osc.type = 'sawtooth';
          osc.frequency.setValueAtTime(freq, t + chord.at);

          const filter = this.ctx!.createBiquadFilter();
          filter.type = 'lowpass';
          filter.frequency.setValueAtTime(900, t + chord.at);

          gain.gain.setValueAtTime(0.01, t + chord.at);
          gain.gain.linearRampToValueAtTime(0.12, t + chord.at + 0.3);
          gain.gain.linearRampToValueAtTime(0.01, t + chord.at + chord.dur);

          osc.connect(filter);
          filter.connect(gain);
          gain.connect(this.bgmGain!);
          osc.start(t + chord.at);
          osc.stop(t + chord.at + chord.dur);
          this.activeOscillators.push(osc);
        });
      });
    } else {
      // Motivational / Lo-Fi ambient warm pad
      const freqs = [174.61, 220.0, 261.63, 329.63]; // Fmaj7
      freqs.forEach((freq) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, t);

        gain.gain.setValueAtTime(0.08, t);
        gain.gain.linearRampToValueAtTime(0.12, t + 3.0);
        gain.gain.linearRampToValueAtTime(0.08, t + loopLengthSeconds);

        osc.connect(gain);
        gain.connect(this.bgmGain!);
        osc.start(t);
        osc.stop(t + loopLengthSeconds);
        this.activeOscillators.push(osc);
      });
    }

    // Schedule next loop iteration
    this.loopTimer = setTimeout(() => {
      this.scheduleBgmLoop(genre);
    }, (loopLengthSeconds - 0.1) * 1000);
  }

  // ----------------------------------------------------
  // Text-To-Speech (Gemini TTS base64 or Web Speech fallback)
  // ----------------------------------------------------
  public playTTS(
    text: string,
    language: string = 'English',
    audioBase64?: string,
    onEnd?: () => void
  ) {
    this.init();
    this.stopTTS();

    // 1. If base64 audio is provided from Gemini TTS API
    if (audioBase64 && this.ctx) {
      try {
        const cleanB64 = audioBase64.replace(/^data:audio\/[a-zA-Z+]+;base64,/, '');
        const binary = atob(cleanB64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
          bytes[i] = binary.charCodeAt(i);
        }

        this.ctx.decodeAudioData(
          bytes.buffer,
          (buffer) => {
            if (this.currentTtsSource) {
              try {
                this.currentTtsSource.stop();
              } catch {}
              this.currentTtsSource = null;
            }
            const source = this.ctx!.createBufferSource();
            source.buffer = buffer;
            source.connect(this.voiceGain!);
            this.currentTtsSource = source;
            source.onended = () => {
              if (this.currentTtsSource === source) {
                this.currentTtsSource = null;
              }
              if (onEnd) onEnd();
            };
            source.start();
          },
          () => {
            // Fallback to Web Speech if decode fails
            this.speakWebSpeech(text, language, onEnd);
          }
        );
        return;
      } catch (err) {
        console.warn('Audio decode fallback:', err);
      }
    }

    // 2. High Quality Web Speech API fallback (Native on Android Samsung devices)
    this.speakWebSpeech(text, language, onEnd);
  }

  private speakWebSpeech(text: string, language: string, onEnd?: () => void) {
    try {
      if (
        typeof window === 'undefined' ||
        !('speechSynthesis' in window) ||
        !window.speechSynthesis ||
        typeof SpeechSynthesisUtterance === 'undefined'
      ) {
        if (onEnd) onEnd();
        return;
      }

      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);

      // Match Indic language BCP-47 codes
      const langMap: Record<string, string> = {
        Bengali: 'bn-IN',
        Hindi: 'hi-IN',
        English: 'en-US',
        Tamil: 'ta-IN',
        Telugu: 'te-IN',
        Marathi: 'mr-IN',
        Gujarati: 'gu-IN',
        Kannada: 'kn-IN',
        Malayalam: 'ml-IN',
        Punjabi: 'pa-IN',
        Urdu: 'ur-PK',
      };

      utterance.lang = langMap[language] || 'en-US';
      utterance.rate = 0.96; // clear storytelling cadence
      utterance.pitch = 1.0;

      // Try finding matched installed voice
      if (typeof window.speechSynthesis.getVoices === 'function') {
        const voices = window.speechSynthesis.getVoices() || [];
        const matchedVoice = voices.find((v) => v.lang && v.lang.startsWith(utterance.lang.slice(0, 2)));
        if (matchedVoice) {
          utterance.voice = matchedVoice;
        }
      }

      utterance.onend = () => {
        if (onEnd) onEnd();
      };
      utterance.onerror = () => {
        if (onEnd) onEnd();
      };

      this.speechSynthUtterance = utterance;
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn('Speech synthesis playback error:', e);
      if (onEnd) onEnd();
    }
  }

  public stopTTS() {
    if (this.currentTtsSource) {
      try {
        this.currentTtsSource.stop();
      } catch {}
      this.currentTtsSource = null;
    }

    try {
      if (
        typeof window !== 'undefined' &&
        'speechSynthesis' in window &&
        window.speechSynthesis &&
        typeof window.speechSynthesis.cancel === 'function'
      ) {
        window.speechSynthesis.cancel();
      }
    } catch (e) {
      console.warn('Speech synthesis cancel error:', e);
    }
  }
}

export const audioEngine = new AudioEngine();
