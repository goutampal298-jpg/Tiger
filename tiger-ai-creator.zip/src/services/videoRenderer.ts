import {
  AspectRatio,
  CameraMotion,
  Project,
  Scene,
  SubtitleFontSize,
  SubtitlePosition,
  SubtitlePreset,
  SubtitleWord,
} from '../types';
import { audioEngine } from './audioEngine';

export interface RenderFrameState {
  currentScene: Scene;
  sceneElapsedMs: number;
  sceneDurationMs: number;
  overallElapsedMs: number;
  totalDurationMs: number;
  aspectRatio: AspectRatio;
  subtitlePreset: SubtitlePreset;
  subtitlePosition?: SubtitlePosition;
  subtitleFontSize?: SubtitleFontSize;
  subtitleTimingOffsetMs?: number;
  showWatermark?: boolean;
}

export class VideoCompositor {
  private imageCache: Map<string, HTMLImageElement> = new Map();

  public async preloadImages(scenes: Scene[]) {
    for (const scene of scenes) {
      if (scene.imageUrl && !this.imageCache.has(scene.imageUrl)) {
        await new Promise((resolve) => {
          const img = new Image();
          img.crossOrigin = 'anonymous';
          img.onload = () => {
            this.imageCache.set(scene.imageUrl!, img);
            resolve(true);
          };
          img.onerror = () => resolve(false);
          img.src = scene.imageUrl!;
        });
      }
    }
  }

  public renderFrame(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    state: RenderFrameState
  ) {
    const { currentScene, sceneElapsedMs, sceneDurationMs, subtitlePreset, showWatermark } =
      state;
    const progress = Math.min(1, Math.max(0, sceneElapsedMs / Math.max(1, sceneDurationMs)));

    // Clear canvas
    ctx.fillStyle = '#05070A';
    ctx.fillRect(0, 0, width, height);

    ctx.save();

    // 1. Calculate Camera Motion Transformation Matrix
    const { scale, translateX, translateY, rotation } = this.calculateMotionTransform(
      currentScene.cameraMotion,
      currentScene.motionStrength || 5,
      progress,
      width,
      height
    );

    // Apply motion transform centered
    ctx.translate(width / 2 + translateX, height / 2 + translateY);
    ctx.scale(scale, scale);
    if (rotation !== 0) {
      ctx.rotate(rotation);
    }
    ctx.translate(-width / 2, -height / 2);

    // 2. Draw Scene Visual / Base Image
    const cachedImg = currentScene.imageUrl ? this.imageCache.get(currentScene.imageUrl) : null;
    if (cachedImg) {
      this.drawImageCover(ctx, cachedImg, width, height);
    } else {
      // Procedural background fallback if image not cached
      this.drawProceduralBackground(ctx, width, height, currentScene.sceneNumber);
    }

    ctx.restore();

    // 3. Cinematic Atmospheric Effects Layer
    this.renderAtmosphereEffects(ctx, width, height, progress, currentScene.sceneNumber);

    // 4. Render Synchronized Animated Subtitles
    this.renderSubtitles(ctx, width, height, currentScene, sceneElapsedMs, state);

    // 5. Watermark (if requested, else 100% watermark-free!)
    if (showWatermark) {
      this.renderWatermark(ctx, width, height);
    }
  }

  private calculateMotionTransform(
    motion: CameraMotion,
    strength: number,
    progress: number,
    w: number,
    h: number
  ) {
    const factor = (strength / 5) * 0.12; // normalized strength 0.02 - 0.24
    let scale = 1.05;
    let translateX = 0;
    let translateY = 0;
    let rotation = 0;

    switch (motion) {
      case 'zoom-in':
        scale = 1.02 + progress * factor * 1.5;
        break;

      case 'zoom-out':
        scale = 1.02 + (1 - progress) * factor * 1.5;
        break;

      case 'pan-left':
        scale = 1.1;
        translateX = (1 - progress * 2) * (w * factor * 0.5);
        break;

      case 'pan-right':
        scale = 1.1;
        translateX = (progress * 2 - 1) * (w * factor * 0.5);
        break;

      case 'tilt-up':
        scale = 1.12;
        translateY = (1 - progress * 2) * (h * factor * 0.5);
        break;

      case 'tilt-down':
        scale = 1.12;
        translateY = (progress * 2 - 1) * (h * factor * 0.5);
        break;

      case 'cinematic-push':
        scale = 1.02 + progress * factor * 1.4;
        translateX = Math.sin(progress * Math.PI) * (w * factor * 0.2);
        rotation = Math.sin(progress * Math.PI * 0.5) * 0.015;
        break;

      case 'slow-motion':
        scale = 1.05 + progress * (factor * 0.4);
        translateX = (progress - 0.5) * (w * factor * 0.2);
        break;

      case 'camera-shake': {
        scale = 1.12;
        const shakeSeed = progress * 40;
        translateX = (Math.sin(shakeSeed * 7) * factor * 0.5 + Math.cos(shakeSeed * 11) * 0.3) * w * 0.08;
        translateY = (Math.cos(shakeSeed * 5) * factor * 0.5) * h * 0.08;
        rotation = Math.sin(shakeSeed * 9) * 0.012;
        break;
      }

      default:
        scale = 1.05;
        break;
    }

    return { scale, translateX, translateY, rotation };
  }

  private drawImageCover(
    ctx: CanvasRenderingContext2D,
    img: HTMLImageElement,
    cw: number,
    ch: number
  ) {
    const iw = img.naturalWidth || img.width;
    const ih = img.naturalHeight || img.height;
    if (!iw || !ih) return;

    const hRatio = cw / iw;
    const vRatio = ch / ih;
    const ratio = Math.max(hRatio, vRatio);

    const destW = iw * ratio;
    const destH = ih * ratio;
    const destX = (cw - destW) / 2;
    const destY = (ch - destH) / 2;

    ctx.drawImage(img, 0, 0, iw, ih, destX, destY, destW, destH);
  }

  private drawProceduralBackground(
    ctx: CanvasRenderingContext2D,
    w: number,
    h: number,
    sceneNum: number
  ) {
    const grad = ctx.createLinearGradient(0, 0, 0, h);
    grad.addColorStop(0, '#101626');
    grad.addColorStop(0.5, '#1e293b');
    grad.addColorStop(1, '#090d16');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);

    // Glowing circle in center
    const radial = ctx.createRadialGradient(w / 2, h / 2, 20, w / 2, h / 2, w * 0.45);
    radial.addColorStop(0, 'rgba(255, 174, 25, 0.3)');
    radial.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = radial;
    ctx.fillRect(0, 0, w, h);
  }

  private renderAtmosphereEffects(
    ctx: CanvasRenderingContext2D,
    w: number,
    h: number,
    progress: number,
    sceneNum: number
  ) {
    // 1. Cinematic Vignette
    const vignette = ctx.createRadialGradient(w / 2, h / 2, w * 0.35, w / 2, h / 2, w * 0.85);
    vignette.addColorStop(0, 'rgba(0,0,0,0)');
    vignette.addColorStop(1, 'rgba(4, 6, 12, 0.65)');
    ctx.fillStyle = vignette;
    ctx.fillRect(0, 0, w, h);

    // 2. Divine / Ambient light rays in upper area
    const sunGlow = ctx.createRadialGradient(w * 0.5, h * 0.15, 10, w * 0.5, h * 0.15, w * 0.7);
    sunGlow.addColorStop(0, 'rgba(255, 215, 0, 0.25)');
    sunGlow.addColorStop(0.5, 'rgba(255, 140, 0, 0.08)');
    sunGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = sunGlow;
    ctx.fillRect(0, 0, w, h);

    // 3. Floating shimmer sparks (gentle upward drift)
    ctx.fillStyle = 'rgba(255, 235, 160, 0.75)';
    for (let i = 0; i < 20; i++) {
      const seedX = (i * 137.5) % w;
      const seedSpeed = 0.2 + (i % 5) * 0.15;
      const py = (h - ((progress * seedSpeed * h + i * 45) % h));
      const px = seedX + Math.sin(progress * 4 + i) * 15;
      const radius = 1.2 + (i % 3) * 0.8;

      ctx.beginPath();
      ctx.arc(px, py, radius, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  private renderSubtitles(
    ctx: CanvasRenderingContext2D,
    w: number,
    h: number,
    scene: Scene,
    sceneElapsedMs: number,
    state: RenderFrameState
  ) {
    const text = scene.narration || '';
    if (!text.trim()) return;

    const {
      subtitlePreset = 'viral-yellow',
      subtitlePosition = 'bottom',
      subtitleFontSize = 'medium',
      subtitleTimingOffsetMs = 0,
    } = state;

    // Apply timing offset for synchronization
    const effectiveElapsedMs = Math.max(0, sceneElapsedMs + subtitleTimingOffsetMs);

    // Calculate Y position
    const posY =
      subtitlePosition === 'top'
        ? h * 0.16
        : subtitlePosition === 'center'
        ? h * 0.5
        : h * 0.84;

    // Calculate Font Size
    const sizeMultiplier =
      subtitleFontSize === 'small'
        ? 0.8
        : subtitleFontSize === 'large'
        ? 1.25
        : subtitleFontSize === 'xlarge'
        ? 1.55
        : 1.0;

    const baseFontSize = Math.max(16, Math.min(48, Math.floor(w * 0.052 * sizeMultiplier)));

    // Extract active words from timed subtitles if available
    const words =
      scene.subtitles && scene.subtitles.length > 0
        ? scene.subtitles
        : this.autoGenerateWordTimings(text, scene.duration * 1000);

    const activeWordIndex = words.findIndex(
      (item) => effectiveElapsedMs >= item.startMs && effectiveElapsedMs <= item.endMs
    );

    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    // Style presets
    if (subtitlePreset === 'viral-yellow') {
      ctx.font = `800 ${baseFontSize}px "Plus Jakarta Sans", sans-serif`;
      this.drawViralSubtitles(ctx, words, activeWordIndex, w, posY, baseFontSize);
    } else if (subtitlePreset === 'devotional-gold') {
      ctx.font = `900 ${baseFontSize + 2}px "Cinzel", "Rozha One", "Tiro Bangla", serif`;
      this.drawDevotionalSubtitles(ctx, words, activeWordIndex, w, posY);
    } else if (subtitlePreset === 'neon-cyber') {
      ctx.font = `800 ${baseFontSize}px "Plus Jakarta Sans", sans-serif`;
      this.drawNeonSubtitles(ctx, words, activeWordIndex, w, posY);
    } else if (subtitlePreset === 'comic-pop') {
      ctx.font = `900 ${baseFontSize + 3}px "Plus Jakarta Sans", Impact, sans-serif`;
      this.drawComicPopSubtitles(ctx, words, activeWordIndex, w, posY, baseFontSize);
    } else if (subtitlePreset === 'bengali-calligraphic') {
      ctx.font = `800 ${baseFontSize + 1}px "Tiro Bangla", "Rozha One", serif`;
      this.drawBengaliCalligraphicSubtitles(ctx, words, activeWordIndex, w, posY, baseFontSize);
    } else {
      ctx.font = `600 ${baseFontSize - 2}px "Plus Jakarta Sans", sans-serif`;
      this.drawCleanSubtitles(ctx, text, w, posY, baseFontSize);
    }
  }

  private drawComicPopSubtitles(
    ctx: CanvasRenderingContext2D,
    words: SubtitleWord[],
    activeIdx: number,
    w: number,
    y: number,
    fontSize: number
  ) {
    const chunkSize = 4;
    const currentChunkIdx = activeIdx >= 0 ? Math.floor(activeIdx / chunkSize) : 0;
    const chunkWords = words.slice(currentChunkIdx * chunkSize, (currentChunkIdx + 1) * chunkSize);
    if (chunkWords.length === 0) return;

    const fullLine = chunkWords.map((cw) => cw.text.toUpperCase()).join(' ');
    const metrics = ctx.measureText(fullLine);
    const boxWidth = metrics.width + 36;
    const boxHeight = fontSize * 2.2;

    // Pop Comic Bubble with black border and offset drop shadow
    ctx.save();
    ctx.fillStyle = '#000000';
    ctx.fillRect(w / 2 - boxWidth / 2 + 6, y - boxHeight / 2 + 6, boxWidth, boxHeight);

    ctx.fillStyle = '#FFE600';
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 4;
    ctx.fillRect(w / 2 - boxWidth / 2, y - boxHeight / 2, boxWidth, boxHeight);
    ctx.strokeRect(w / 2 - boxWidth / 2, y - boxHeight / 2, boxWidth, boxHeight);

    // Render Words with outline
    ctx.lineWidth = 6;
    ctx.strokeStyle = '#000000';
    ctx.strokeText(fullLine, w / 2, y);

    ctx.fillStyle = '#FF0055';
    ctx.fillText(fullLine, w / 2, y);
    ctx.restore();
  }

  private drawBengaliCalligraphicSubtitles(
    ctx: CanvasRenderingContext2D,
    words: SubtitleWord[],
    activeIdx: number,
    w: number,
    y: number,
    fontSize: number
  ) {
    const chunkSize = 5;
    const currentChunkIdx = activeIdx >= 0 ? Math.floor(activeIdx / chunkSize) : 0;
    const chunkWords = words.slice(currentChunkIdx * chunkSize, (currentChunkIdx + 1) * chunkSize);
    if (chunkWords.length === 0) return;

    const fullLine = chunkWords.map((cw) => cw.text).join(' ');
    const metrics = ctx.measureText(fullLine);
    const boxWidth = metrics.width + 40;
    const boxHeight = fontSize * 2.0;

    ctx.save();
    // Crimson translucent calligraphic ribbon
    const grad = ctx.createLinearGradient(w / 2 - boxWidth / 2, y, w / 2 + boxWidth / 2, y);
    grad.addColorStop(0, 'rgba(80, 0, 20, 0)');
    grad.addColorStop(0.2, 'rgba(120, 10, 30, 0.85)');
    grad.addColorStop(0.8, 'rgba(120, 10, 30, 0.85)');
    grad.addColorStop(1, 'rgba(80, 0, 20, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(w / 2 - boxWidth / 2, y - boxHeight / 2, boxWidth, boxHeight);

    // Gold borders
    ctx.strokeStyle = 'rgba(255, 215, 0, 0.6)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(w / 2 - boxWidth * 0.4, y + boxHeight / 2 - 2);
    ctx.lineTo(w / 2 + boxWidth * 0.4, y + boxHeight / 2 - 2);
    ctx.stroke();

    // Bengali Gold Text with slight glow
    ctx.shadowColor = '#FFA500';
    ctx.shadowBlur = 12;
    ctx.fillStyle = '#FFEAA7';
    ctx.fillText(fullLine, w / 2, y);
    ctx.restore();
  }

  private autoGenerateWordTimings(fullText: string, totalMs: number): SubtitleWord[] {
    const words = fullText.trim().split(/\s+/);
    if (words.length === 0) return [];
    const msPerWord = totalMs / words.length;

    return words.map((w, idx) => ({
      text: w,
      startMs: idx * msPerWord,
      endMs: (idx + 1) * msPerWord,
    }));
  }

  private drawViralSubtitles(
    ctx: CanvasRenderingContext2D,
    words: SubtitleWord[],
    activeIdx: number,
    w: number,
    y: number,
    fontSize: number
  ) {
    // Break words into chunks of 3-4 words for mobile shorts readability
    const chunkSize = 4;
    const currentChunkIdx = activeIdx >= 0 ? Math.floor(activeIdx / chunkSize) : 0;
    const chunkWords = words.slice(
      currentChunkIdx * chunkSize,
      (currentChunkIdx + 1) * chunkSize
    );

    const chunkText = chunkWords.map((w) => w.text.toUpperCase()).join(' ');

    // Measure and draw background pill
    const metrics = ctx.measureText(chunkText);
    const pillW = metrics.width + 36;
    const pillH = fontSize * 1.8;

    ctx.fillStyle = 'rgba(0, 0, 0, 0.72)';
    this.roundRect(ctx, w / 2 - pillW / 2, y - pillH / 2, pillW, pillH, 12);
    ctx.fill();

    // Render words with active highlighting
    let currentX = w / 2 - metrics.width / 2;

    chunkWords.forEach((wordObj, i) => {
      const globalIdx = currentChunkIdx * chunkSize + i;
      const isActive = globalIdx === activeIdx;
      const wordText = wordObj.text.toUpperCase() + ' ';
      const wordMetrics = ctx.measureText(wordText);

      ctx.save();
      if (isActive) {
        // Active word in radiant Yellow + neon glow
        ctx.fillStyle = '#FFE600';
        ctx.shadowColor = '#FFA500';
        ctx.shadowBlur = 14;
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 4;
        ctx.strokeText(wordText, currentX + wordMetrics.width / 2, y);
        ctx.fillText(wordText, currentX + wordMetrics.width / 2, y);
      } else {
        // Normal word in crisp white
        ctx.fillStyle = '#FFFFFF';
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 3;
        ctx.strokeText(wordText, currentX + wordMetrics.width / 2, y);
        ctx.fillText(wordText, currentX + wordMetrics.width / 2, y);
      }
      ctx.restore();

      currentX += wordMetrics.width;
    });
  }

  private drawDevotionalSubtitles(
    ctx: CanvasRenderingContext2D,
    words: SubtitleWord[],
    activeIdx: number,
    w: number,
    y: number
  ) {
    const chunkSize = 4;
    const currentChunkIdx = activeIdx >= 0 ? Math.floor(activeIdx / chunkSize) : 0;
    const chunkWords = words.slice(
      currentChunkIdx * chunkSize,
      (currentChunkIdx + 1) * chunkSize
    );
    const text = chunkWords.map((w) => w.text).join(' ');

    ctx.save();
    // Golden gradient fill
    const grad = ctx.createLinearGradient(w / 2 - 150, y - 20, w / 2 + 150, y + 20);
    grad.addColorStop(0, '#FFE873');
    grad.addColorStop(0.5, '#FFD700');
    grad.addColorStop(1, '#FFA500');

    ctx.shadowColor = '#FF8C00';
    ctx.shadowBlur = 12;
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#220800';
    ctx.strokeText(text, w / 2, y);

    ctx.fillStyle = grad;
    ctx.fillText(text, w / 2, y);
    ctx.restore();
  }

  private drawNeonSubtitles(
    ctx: CanvasRenderingContext2D,
    words: SubtitleWord[],
    activeIdx: number,
    w: number,
    y: number
  ) {
    const chunkSize = 4;
    const currentChunkIdx = activeIdx >= 0 ? Math.floor(activeIdx / chunkSize) : 0;
    const chunkWords = words.slice(
      currentChunkIdx * chunkSize,
      (currentChunkIdx + 1) * chunkSize
    );
    const text = chunkWords.map((w) => w.text.toUpperCase()).join(' ');

    ctx.save();
    ctx.shadowColor = '#00E5FF';
    ctx.shadowBlur = 16;
    ctx.strokeStyle = '#000';
    ctx.lineWidth = 3;
    ctx.strokeText(text, w / 2, y);
    ctx.fillStyle = '#00F0FF';
    ctx.fillText(text, w / 2, y);
    ctx.restore();
  }

  private drawCleanSubtitles(
    ctx: CanvasRenderingContext2D,
    fullText: string,
    w: number,
    y: number,
    fontSize: number
  ) {
    const text = fullText.length > 55 ? fullText.slice(0, 52) + '...' : fullText;
    const metrics = ctx.measureText(text);
    const pillW = metrics.width + 30;
    const pillH = fontSize * 1.8;

    ctx.fillStyle = 'rgba(10, 15, 25, 0.85)';
    this.roundRect(ctx, w / 2 - pillW / 2, y - pillH / 2, pillW, pillH, 8);
    ctx.fill();

    ctx.fillStyle = '#FFFFFF';
    ctx.fillText(text, w / 2, y);
  }

  private renderWatermark(ctx: CanvasRenderingContext2D, w: number, h: number) {
    ctx.save();
    ctx.textAlign = 'right';
    ctx.font = '700 14px "Plus Jakarta Sans", sans-serif';
    ctx.fillStyle = 'rgba(255, 174, 25, 0.75)';
    ctx.fillText('🐅 TIGER AI', w - 24, 34);
    ctx.restore();
  }

  private roundRect(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    w: number,
    h: number,
    r: number
  ) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  // ----------------------------------------------------
  // Export Recording Engine (Real MP4 / WebM with Audio!)
  // ----------------------------------------------------
  public async exportVideo(
    project: Project,
    qualityWidth: number,
    qualityHeight: number,
    showWatermark: boolean,
    onProgress: (percent: number, status: string) => void
  ): Promise<Blob> {
    await this.preloadImages(project.scenes);
    audioEngine.init();

    const canvas = document.createElement('canvas');
    canvas.width = qualityWidth;
    canvas.height = qualityHeight;
    const ctx = canvas.getContext('2d', { alpha: false })!;

    const totalDurationMs = project.scenes.reduce((acc, s) => acc + s.duration * 1000, 0);

    // Canvas video stream
    const canvasStream = canvas.captureStream(30);

    // Audio stream from synthesized background music + voice
    const audioStream = audioEngine.getAudioStream();
    const combinedTracks: MediaStreamTrack[] = [...canvasStream.getVideoTracks()];

    if (audioStream && audioStream.getAudioTracks().length > 0) {
      combinedTracks.push(...audioStream.getAudioTracks());
    }

    const combinedStream = new MediaStream(combinedTracks);

    let mimeType = 'video/webm';
    if (typeof MediaRecorder !== 'undefined' && typeof MediaRecorder.isTypeSupported === 'function') {
      if (MediaRecorder.isTypeSupported('video/mp4;codecs=avc1')) {
        mimeType = 'video/mp4;codecs=avc1';
      } else if (MediaRecorder.isTypeSupported('video/mp4')) {
        mimeType = 'video/mp4';
      } else if (MediaRecorder.isTypeSupported('video/webm;codecs=vp9')) {
        mimeType = 'video/webm;codecs=vp9';
      } else if (MediaRecorder.isTypeSupported('video/webm')) {
        mimeType = 'video/webm';
      }
    }

    let recorder: MediaRecorder;
    try {
      recorder = new MediaRecorder(combinedStream, {
        mimeType: mimeType || undefined,
        videoBitsPerSecond: qualityWidth >= 3840 ? 40_000_000 : 12_000_000,
      });
    } catch {
      // Fallback with default options
      recorder = new MediaRecorder(combinedStream);
    }

    const recordedChunks: Blob[] = [];
    recorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) {
        recordedChunks.push(e.data);
      }
    };

    return new Promise((resolve, reject) => {
      recorder.onstop = () => {
        audioEngine.stopBGM();
        audioEngine.stopTTS();
        const finalBlob = new Blob(recordedChunks, { type: mimeType });
        resolve(finalBlob);
      };

      recorder.onerror = (e) => {
        audioEngine.stopBGM();
        audioEngine.stopTTS();
        reject(e);
      };

      recorder.start();

      // Start BGM
      audioEngine.startBGM(project.bgmGenre);

      const fps = 30;
      const frameIntervalMs = 1000 / fps;
      let elapsedMs = 0;
      let currentSceneIdx = 0;
      let sceneStartMs = 0;

      // Play voiceover for initial scene
      if (project.scenes[0]) {
        audioEngine.playTTS(
          project.scenes[0].narration,
          project.language,
          project.scenes[0].audioBase64
        );
        audioEngine.playSFX(project.scenes[0].soundEffect);
      }

      const renderInterval = setInterval(() => {
        elapsedMs += frameIntervalMs;

        // Check if scene transition
        const scene = project.scenes[currentSceneIdx];
        const sceneDurationMs = scene.duration * 1000;
        const sceneElapsedMs = elapsedMs - sceneStartMs;

        if (sceneElapsedMs >= sceneDurationMs) {
          currentSceneIdx++;
          if (currentSceneIdx >= project.scenes.length) {
            clearInterval(renderInterval);
            recorder.stop();
            return;
          }
          sceneStartMs = elapsedMs;
          const nextScene = project.scenes[currentSceneIdx];
          audioEngine.playTTS(
            nextScene.narration,
            project.language,
            nextScene.audioBase64
          );
          audioEngine.playSFX(nextScene.soundEffect);
        }

        // Render frame
        const currentActiveScene = project.scenes[currentSceneIdx];
        this.renderFrame(ctx, qualityWidth, qualityHeight, {
          currentScene: currentActiveScene,
          sceneElapsedMs: elapsedMs - sceneStartMs,
          sceneDurationMs: currentActiveScene.duration * 1000,
          overallElapsedMs: elapsedMs,
          totalDurationMs,
          aspectRatio: project.aspectRatio,
          subtitlePreset: project.subtitlePreset,
          showWatermark,
        });

        const percent = Math.min(100, Math.round((elapsedMs / totalDurationMs) * 100));
        onProgress(percent, `Rendering scene ${currentSceneIdx + 1}/${project.scenes.length}...`);
      }, frameIntervalMs);
    });
  }
}

export const videoCompositor = new VideoCompositor();
