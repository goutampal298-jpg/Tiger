export type AspectRatio = '9:16' | '16:9' | '1:1' | '4:5';

export type TextVideoStyle =
  | 'cinematic'
  | 'realistic'
  | 'animation'
  | 'devotional'
  | 'story'
  | 'social-media';

export type VideoResolution = '720p' | '1080p' | '2k' | '4k' | '8k';

export type StandardDuration = 5 | 10 | 20 | 30 | 40 | 50 | 60;

export type StoryLanguage =
  | 'Bengali'
  | 'Hindi'
  | 'English'
  | 'Tamil'
  | 'Telugu'
  | 'Marathi'
  | 'Gujarati'
  | 'Kannada'
  | 'Malayalam'
  | 'Punjabi'
  | 'Urdu';

export type StoryType =
  | 'Devotional'
  | 'Krishna story'
  | 'Radha Krishna'
  | 'Bhagavad Gita'
  | 'Motivational'
  | 'Emotional'
  | 'Horror'
  | 'Mystery'
  | 'Thriller'
  | 'Love'
  | 'Family'
  | 'Kids'
  | 'Moral story'
  | 'Historical'
  | 'Mythological'
  | 'Funny'
  | 'Action'
  | 'Adventure'
  | 'Cinematic'
  | 'Documentary'
  | 'Product advertisement'
  | 'Business promotion';

export type VisualStyle =
  | 'Devotional'
  | 'Indian mythology'
  | 'Cinematic'
  | 'Realistic'
  | 'Photorealistic'
  | '3D'
  | 'Anime'
  | 'Cartoon'
  | 'Fantasy'
  | 'Film style'
  | 'Portrait'
  | 'Product photography'
  | 'Professional advertisement';

export type CameraMotion =
  | 'zoom-in'
  | 'zoom-out'
  | 'pan-left'
  | 'pan-right'
  | 'tilt-up'
  | 'tilt-down'
  | 'cinematic-push'
  | 'slow-motion'
  | 'camera-shake';

export type SoundEffectType =
  | 'temple_bell'
  | 'divine_chime'
  | 'cinematic_hit'
  | 'whoosh'
  | 'thunder'
  | 'heartbeat'
  | 'magic_sparkle'
  | 'nature_wind'
  | 'none';

export type BgmGenre =
  | 'Devotional (Flute & Sitar)'
  | 'Cinematic Orchestral'
  | 'Emotional Piano'
  | 'Motivational Epic'
  | 'Horror Ambient Drone'
  | 'Action Beats'
  | 'Lo-Fi Chill'
  | 'Funny Cartoon Bouncy'
  | 'Game Synthwave Battle'
  | 'Adventure Heroic'
  | 'None';

export type SubtitlePreset =
  | 'viral-yellow'
  | 'devotional-gold'
  | 'cinematic-clean'
  | 'neon-cyber'
  | 'comic-pop'
  | 'bengali-calligraphic';

export type SubtitlePosition = 'top' | 'center' | 'bottom';
export type SubtitleFontSize = 'small' | 'medium' | 'large' | 'xlarge';

export type CartoonMode =
  | '2D Cartoon'
  | '3D Cartoon'
  | 'Anime-inspired'
  | 'Kids Cartoon'
  | 'Comic'
  | 'Fantasy'
  | 'Cute Cartoon'
  | 'Talking Cartoon'
  | 'Cartoon Story';

export type GameCinematicMode =
  | '3D cinematic'
  | 'RPG fantasy'
  | 'Adventure'
  | 'Racing'
  | 'Battle'
  | 'Sci-fi'
  | 'Horror'
  | 'Sports'
  | 'Game trailer';

export interface SubtitleWord {
  text: string;
  startMs: number;
  endMs: number;
}

export interface CharacterReference {
  id: string;
  name: string;
  imageBase64: string;
  genderOrForm?: string;
  ageAppearance?: string;
  skinTone?: string;
  hairStyle?: string;
  facialHair?: string;
  clothing?: string;
  bodyProportions?: string;
  accessories?: string;
  colorPalette?: string;
  keyIdentifiers?: string;
  locked: boolean;
}

export interface Scene {
  id: string;
  sceneNumber: number;
  duration: number; // in seconds
  narration: string;
  englishNarration?: string;
  dialogue?: string;
  visualPrompt: string;
  videoPrompt?: string;
  imageUrl?: string;
  cameraMotion: CameraMotion;
  motionStrength: number; // 1 to 10
  soundEffect: SoundEffectType;
  subtitles: SubtitleWord[];
  audioBase64?: string;
  isGenerating?: boolean;
}

export interface Project {
  id: string;
  title: string;
  language: StoryLanguage;
  storyType: StoryType;
  visualStyle: VisualStyle;
  aspectRatio: AspectRatio;
  targetDuration: number;
  bgmGenre: BgmGenre;
  bgmVolume: number; // 0 to 1
  voiceVolume: number; // 0 to 1
  ttsVoice: string; // 'Kore' | 'Fenrir' | 'Puck' | 'Charon' | 'Zephyr'
  voiceGender?: 'male' | 'female';
  voiceNarrationStyle?: 'dramatic' | 'reverent' | 'energetic' | 'whisper' | 'storyteller';
  subtitlePreset: SubtitlePreset;
  subtitlePosition?: SubtitlePosition;
  subtitleFontSize?: SubtitleFontSize;
  subtitleTimingOffsetMs?: number;
  characterReference?: CharacterReference;
  scenes: Scene[];
  createdAt: number;
  updatedAt: number;
}

export interface AutoCreateProgress {
  currentStep: number;
  totalSteps: number;
  stepName: string;
  details: string;
  isComplete: boolean;
  error?: string;
}

export interface ExportQuality {
  label: string;
  width: number;
  height: number;
  bitrate: number;
}

export type AppNavTab = 'home' | 'create' | 'projects' | 'templates' | 'profile' | 'studio';

export type TemplateCategory =
  | 'story'
  | 'cartoon'
  | 'horror'
  | 'devotional'
  | 'gaming'
  | 'shorts'
  | 'motivational'
  | 'educational';

export interface VideoTemplate {
  id: string;
  title: string;
  bengaliTitle: string;
  category: TemplateCategory;
  description: string;
  duration: number;
  aspectRatio: AspectRatio;
  visualStyle: VisualStyle;
  promptIdea: string;
  bengaliPromptIdea: string;
  bgmGenre: BgmGenre;
  tags: string[];
  thumbnailEmoji: string;
}

export interface VoiceCloneProfile {
  id: string;
  name: string;
  audioSampleDataUri?: string;
  consentConfirmed: boolean;
  createdAt: number;
  status: 'trained' | 'ready';
}

export interface BatchQueueTask {
  id: string;
  title: string;
  type: 'video' | 'scene' | 'thumbnail' | 'voice' | 'enhancement';
  status: 'pending' | 'processing' | 'completed' | 'failed';
  progress: number;
  details?: string;
  createdAt: number;
  error?: string;
}

export interface AppSettings {
  appLanguage: 'bn' | 'en';
  theme: 'dark' | 'light';
  defaultResolution: VideoResolution;
  defaultAspectRatio: AspectRatio;
  notificationsEnabled: boolean;
}

export type AIToolId =
  | 'talking-photo'
  | 'voice-clone'
  | 'bg-remover'
  | 'video-enhancer'
  | 'thumbnail-maker'
  | 'youtube-metadata'
  | 'batch-queue'
  | 'lip-sync';

