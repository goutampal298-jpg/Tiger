import React, { useState, useEffect } from 'react';
import {
  Project,
  Scene,
  AspectRatio,
  CharacterReference,
  BgmGenre,
  SubtitlePreset,
  SubtitlePosition,
  SubtitleFontSize,
  VideoTemplate,
  BatchQueueTask,
  AppSettings,
  AIToolId,
} from './types';
import { INITIAL_PROJECT, TEMPLATE_LIBRARY } from './utils/constants';
import { createProceduralSceneCanvas } from './services/geminiService';
import { Navbar } from './components/Navbar';
import { BottomNav, NavTab } from './components/BottomNav';
import { HomeScreen } from './components/HomeScreen';
import { CreateProjectScreen } from './components/CreateProjectScreen';
import { ProjectsScreen } from './components/ProjectsScreen';
import { TemplatesScreen } from './components/TemplatesScreen';
import { ProfileSettingsScreen } from './components/ProfileSettingsScreen';
import { AIToolsModal } from './components/AIToolsModal';
import { VideoPlayer } from './components/VideoPlayer';
import { TimelineEditor } from './components/TimelineEditor';
import { AutoCreatorModal } from './components/AutoCreatorModal';
import { StoryGeneratorTab } from './components/StoryGeneratorTab';
import { CharacterConsistencyTab } from './components/CharacterConsistencyTab';
import { ImageToVideoTab } from './components/ImageToVideoTab';
import { TextToVideoTab } from './components/TextToVideoTab';
import { AudioMusicTab } from './components/AudioMusicTab';
import { CartoonVideoTab } from './components/CartoonVideoTab';
import { GameCinematicTab } from './components/GameCinematicTab';
import { ReferenceVideoTab } from './components/ReferenceVideoTab';
import { ExportModal } from './components/ExportModal';
import { ApkPackagingModal } from './components/ApkPackagingModal';
import {
  Sparkles,
  Film,
  UserCheck,
  Smartphone,
  ShieldCheck,
  Share2,
  Palette,
  Gamepad2,
  Video,
  Camera,
  Music,
  BookOpen,
} from 'lucide-react';
import { safeVibrate } from './utils/haptics';

const STORAGE_PROJECTS_KEY = 'tiger_ai_projects_v2';
const STORAGE_ACTIVE_ID_KEY = 'tiger_ai_active_project_id';
const STORAGE_SETTINGS_KEY = 'tiger_ai_app_settings';

export default function App() {
  // App Settings
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_SETTINGS_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      appLanguage: 'bn',
      theme: 'dark',
      defaultResolution: '1080p',
      defaultAspectRatio: '9:16',
      notificationsEnabled: true,
    };
  });

  // Projects list in persistent storage
  const [projects, setProjects] = useState<Project[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PROJECTS_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return [INITIAL_PROJECT];
  });

  const [activeProjectId, setActiveProjectId] = useState<string>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_ACTIVE_ID_KEY);
      if (saved) return saved;
    } catch {}
    return INITIAL_PROJECT.id;
  });

  // Active Project reference
  const currentProject =
    projects.find((p) => p.id === activeProjectId) || projects[0] || INITIAL_PROJECT;

  // Active Scene in Studio
  const [currentSceneIndex, setCurrentSceneIndex] = useState<number>(0);

  // Active Navigation Tab
  const [activeTab, setActiveTab] = useState<NavTab>('home');

  // Batch Queue Tasks
  const [queueTasks, setQueueTasks] = useState<BatchQueueTask[]>([]);

  // Modals & Tools
  const [activeAITool, setActiveAITool] = useState<AIToolId | null>(null);
  const [isAutoCreatorOpen, setIsAutoCreatorOpen] = useState<boolean>(false);
  const [isApkModalOpen, setIsApkModalOpen] = useState<boolean>(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Persist Settings
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_SETTINGS_KEY, JSON.stringify(settings));
    } catch {}
  }, [settings]);

  // Persist Projects & Active ID (Draft + Auto Save)
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_PROJECTS_KEY, JSON.stringify(projects));
      localStorage.setItem(STORAGE_ACTIVE_ID_KEY, activeProjectId);
    } catch {}
  }, [projects, activeProjectId]);

  // Initialize demo visual canvases if empty on first load
  useEffect(() => {
    const initVisuals = async () => {
      let needsUpdate = false;
      const updatedScenes = await Promise.all(
        currentProject.scenes.map(async (s) => {
          if (!s.imageUrl) {
            needsUpdate = true;
            const img = await createProceduralSceneCanvas(
              s.visualPrompt || `Scene ${s.sceneNumber}`,
              currentProject.visualStyle,
              currentProject.aspectRatio
            );
            return { ...s, imageUrl: img };
          }
          return s;
        })
      );

      if (needsUpdate) {
        setProjects((prev) =>
          prev.map((p) => (p.id === currentProject.id ? { ...p, scenes: updatedScenes } : p))
        );
      }
    };

    initVisuals();
  }, [currentProject.id]);

  // Mutate Current Project Helper
  const updateCurrentProject = (updater: (prev: Project) => Project) => {
    setProjects((prev) =>
      prev.map((p) => {
        if (p.id === currentProject.id) {
          const updated = updater(p);
          return { ...updated, updatedAt: Date.now() };
        }
        return p;
      })
    );
  };

  // Update specific scene
  const handleUpdateScene = (sceneIndex: number, updatedProps: Partial<Scene>) => {
    updateCurrentProject((prev) => {
      const newScenes = [...prev.scenes];
      if (newScenes[sceneIndex]) {
        newScenes[sceneIndex] = { ...newScenes[sceneIndex], ...updatedProps };
      }
      return { ...prev, scenes: newScenes };
    });
  };

  // Add new scene
  const handleAddScene = async () => {
    const nextNum = currentProject.scenes.length + 1;
    const placeholderImg = await createProceduralSceneCanvas(
      `Scene ${nextNum} visual composition`,
      currentProject.visualStyle,
      currentProject.aspectRatio
    );

    const newScene: Scene = {
      id: `sc_${Date.now()}_${nextNum}`,
      sceneNumber: nextNum,
      duration: 5,
      narration: `Scene ${nextNum} continuation of the story.`,
      englishNarration: `Scene ${nextNum} continuation of the story.`,
      visualPrompt: `Scene ${nextNum} cinematic composition`,
      imageUrl: placeholderImg,
      cameraMotion: 'cinematic-push',
      motionStrength: 7,
      soundEffect: 'whoosh',
      subtitles: [],
    };

    updateCurrentProject((prev) => ({
      ...prev,
      scenes: [...prev.scenes, newScene],
    }));
    setCurrentSceneIndex(currentProject.scenes.length);
  };

  // Add multiple empty scenes at once
  const handleAddMultipleScenes = (count: number) => {
    updateCurrentProject((prev) => {
      const startNum = prev.scenes.length + 1;
      const newScenes: Scene[] = [];
      for (let i = 0; i < count; i++) {
        const num = startNum + i;
        newScenes.push({
          id: `sc_empty_${Date.now()}_${num}`,
          sceneNumber: num,
          duration: 5,
          narration: '',
          englishNarration: '',
          visualPrompt: '',
          imageUrl: '',
          cameraMotion: i % 2 === 0 ? 'cinematic-push' : 'slow-motion',
          motionStrength: 7,
          soundEffect: i === 0 ? 'temple_bell' : 'whoosh',
          subtitles: [],
        });
      }
      return {
        ...prev,
        scenes: [...prev.scenes, ...newScenes],
      };
    });
  };

  // Batch update multiple scenes at once
  const handleBatchUpdateScenes = (updates: { index: number; scene: Partial<Scene> }[]) => {
    updateCurrentProject((prev) => {
      const nextScenes = [...prev.scenes];
      updates.forEach(({ index, scene }) => {
        if (nextScenes[index]) {
          nextScenes[index] = { ...nextScenes[index], ...scene };
        }
      });
      return { ...prev, scenes: nextScenes };
    });
  };

  // Delete scene
  const handleDeleteScene = (index: number) => {
    if (currentProject.scenes.length <= 1) return;
    updateCurrentProject((prev) => {
      const filtered = prev.scenes.filter((_, i) => i !== index);
      const renumbered = filtered.map((s, i) => ({ ...s, sceneNumber: i + 1 }));
      return { ...prev, scenes: renumbered };
    });
    setCurrentSceneIndex(Math.max(0, index - 1));
  };

  // Duplicate scene
  const handleDuplicateScene = (index: number) => {
    const target = currentProject.scenes[index];
    if (!target) return;

    const copy: Scene = {
      ...target,
      id: `sc_copy_${Date.now()}`,
      sceneNumber: target.sceneNumber + 1,
    };

    updateCurrentProject((prev) => {
      const nextScenes = [...prev.scenes];
      nextScenes.splice(index + 1, 0, copy);
      const renumbered = nextScenes.map((s, i) => ({ ...s, sceneNumber: i + 1 }));
      return { ...prev, scenes: renumbered };
    });
    setCurrentSceneIndex(index + 1);
  };

  // Aspect ratio change
  const handleAspectRatioChange = (aspectRatio: AspectRatio) => {
    updateCurrentProject((prev) => ({ ...prev, aspectRatio }));
  };

  // Character Reference Update
  const handleUpdateCharacter = (charRef: CharacterReference | undefined) => {
    updateCurrentProject((prev) => ({ ...prev, characterReference: charRef }));
  };

  // Audio & Subtitle settings
  const handleUpdateAudio = (audioSettings: {
    bgmGenre?: BgmGenre;
    bgmVolume?: number;
    voiceVolume?: number;
    ttsVoice?: string;
    voiceGender?: 'male' | 'female';
    voiceNarrationStyle?: 'dramatic' | 'reverent' | 'energetic' | 'whisper' | 'storyteller';
    subtitlePreset?: SubtitlePreset;
    subtitlePosition?: SubtitlePosition;
    subtitleFontSize?: SubtitleFontSize;
    subtitleTimingOffsetMs?: number;
  }) => {
    updateCurrentProject((prev) => ({ ...prev, ...audioSettings }));
  };

  // New Project Action
  const handleNewProject = () => {
    const newP: Project = {
      ...INITIAL_PROJECT,
      id: `proj_${Date.now()}`,
      title: `Tiger Story #${projects.length + 1}`,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    setProjects((prev) => [newP, ...prev]);
    setActiveProjectId(newP.id);
    setCurrentSceneIndex(0);
    setActiveTab('create');
    showToast('Created new project!');
  };

  // Duplicate Project Action
  const handleDuplicateProject = (projId: string) => {
    const target = projects.find((p) => p.id === projId);
    if (!target) return;
    const duplicated: Project = {
      ...target,
      id: `proj_${Date.now()}`,
      title: `${target.title} (Copy)`,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    setProjects((prev) => [duplicated, ...prev]);
    setActiveProjectId(duplicated.id);
    showToast('Project duplicated!');
  };

  // Delete Project Action
  const handleDeleteProject = (projId: string) => {
    if (projects.length <= 1) return;
    setProjects((prev) => prev.filter((p) => p.id !== projId));
    if (activeProjectId === projId) {
      const remaining = projects.filter((p) => p.id !== projId);
      setActiveProjectId(remaining[0]?.id || INITIAL_PROJECT.id);
    }
    showToast('Project deleted.');
  };

  // Rename Project Action
  const handleRenameProject = (projId: string, newTitle: string) => {
    setProjects((prev) =>
      prev.map((p) => (p.id === projId ? { ...p, title: newTitle, updatedAt: Date.now() } : p))
    );
    showToast('Project renamed.');
  };

  // Select Template Action
  const handleSelectTemplate = (template: VideoTemplate) => {
    const newP: Project = {
      ...INITIAL_PROJECT,
      id: `proj_${Date.now()}`,
      title: settings.appLanguage === 'bn' ? template.bengaliTitle : template.title,
      aspectRatio: template.aspectRatio,
      visualStyle: template.visualStyle,
      targetDuration: template.duration,
      bgmGenre: template.bgmGenre,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    setProjects((prev) => [newP, ...prev]);
    setActiveProjectId(newP.id);
    setActiveTab('create');
    showToast(`Loaded template: ${template.title}`);
  };

  // Completed Project from Create Screen
  const handleCompleteFromCreate = (newProj: Project) => {
    setProjects((prev) => {
      const exists = prev.some((p) => p.id === newProj.id);
      if (exists) {
        return prev.map((p) => (p.id === newProj.id ? newProj : p));
      }
      return [newProj, ...prev];
    });
    setActiveProjectId(newProj.id);
    setActiveTab('studio');
    setCurrentSceneIndex(0);
    showToast('AI Video ready in Studio Player!');
  };

  const navRibbonItems: { id: NavTab; label: string; icon: any; badge?: string }[] = [
    { id: 'home', label: 'Home', icon: Sparkles },
    { id: 'create', label: 'Create', icon: Film, badge: 'Auto' },
    { id: 'studio', label: 'Studio Timeline', icon: Film },
    { id: 'text2video', label: 'Text to Video', icon: Sparkles },
    { id: 'story', label: 'AI Story Script', icon: BookOpen },
    { id: 'cartoon', label: 'Cartoon AI', icon: Palette },
    { id: 'game', label: 'Game Cinematic', icon: Gamepad2 },
    { id: 'reference', label: 'Reference Video', icon: Video },
    { id: 'character', label: 'Character Identity', icon: UserCheck },
    { id: 'image2video', label: 'Image to Video', icon: Camera },
    { id: 'audio', label: 'Voice & Subtitles', icon: Music },
  ];

  return (
    <div className="min-h-screen bg-[#07090E] text-white flex flex-col selection:bg-amber-500 selection:text-black">
      {/* Top App Header */}
      <Navbar
        onOpenAutoCreator={() => setIsAutoCreatorOpen(true)}
        onOpenApkModal={() => setIsApkModalOpen(true)}
        onNewProject={handleNewProject}
        onExport={() => setIsExportModalOpen(true)}
        projectTitle={currentProject.title}
      />

      {/* Main App Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-6 pb-24 sm:pb-28 space-y-5">
        {/* Workspace Quick Sub-Nav Ribbon */}
        {activeTab !== 'home' && activeTab !== 'profile' && (
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {navRibbonItems.map((nav) => {
              const Icon = nav.icon;
              const isActive = activeTab === nav.id;
              return (
                <button
                  key={nav.id}
                  type="button"
                  onClick={() => {
                    safeVibrate(10);
                    setActiveTab(nav.id);
                  }}
                  className={`px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-1.5 transition flex-shrink-0 border ${
                    isActive
                      ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-black border-amber-400 shadow-md shadow-orange-500/20'
                      : 'bg-[#0E121C] border-gray-800 text-gray-300 hover:text-white hover:border-gray-700'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-black' : 'text-amber-400'}`} />
                  <span>{nav.label}</span>
                  {nav.badge && !isActive && (
                    <span className="px-1.5 py-0.2 rounded text-[9px] font-black uppercase bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      {nav.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        )}

        {/* 1. HOME SCREEN */}
        {activeTab === 'home' && (
          <HomeScreen
            currentProject={currentProject}
            recentProjects={projects}
            appLanguage={settings.appLanguage}
            onNavigateTab={(tab) => setActiveTab(tab)}
            onOpenAITool={(toolId) => setActiveAITool(toolId as AIToolId)}
            onSelectTemplate={handleSelectTemplate}
            onOpenAutoCreator={() => setActiveTab('create')}
            onResumeProject={(p) => {
              setActiveProjectId(p.id);
              setActiveTab('studio');
            }}
          />
        )}

        {/* 2. CREATE PROJECT SCREEN (One Photo / One Sentence → Complete Video) */}
        {activeTab === 'create' && (
          <CreateProjectScreen
            project={currentProject}
            appLanguage={settings.appLanguage}
            onCompleteProject={handleCompleteFromCreate}
            onNavigateToStudio={() => setActiveTab('studio')}
          />
        )}

        {/* 3. PROJECTS SCREEN (History, Drafts, Auto-save) */}
        {activeTab === 'projects' && (
          <ProjectsScreen
            projects={projects}
            activeProjectId={activeProjectId}
            queueTasks={queueTasks}
            appLanguage={settings.appLanguage}
            onOpenProject={(pId) => {
              setActiveProjectId(pId);
              setActiveTab('studio');
              showToast('Opened project in Studio');
            }}
            onNewProject={handleNewProject}
            onDuplicateProject={handleDuplicateProject}
            onDeleteProject={handleDeleteProject}
            onRenameProject={handleRenameProject}
            onExportProject={(p) => {
              setActiveProjectId(p.id);
              setIsExportModalOpen(true);
            }}
            onRetryTask={(taskId) => {
              showToast('Retrying task...');
            }}
            onCancelTask={(taskId) => {
              setQueueTasks((prev) => prev.filter((t) => t.id !== taskId));
            }}
          />
        )}

        {/* 4. TEMPLATES SCREEN */}
        {activeTab === 'templates' && (
          <TemplatesScreen
            appLanguage={settings.appLanguage}
            onSelectTemplate={handleSelectTemplate}
          />
        )}

        {/* 5. PROFILE & SETTINGS SCREEN */}
        {activeTab === 'profile' && (
          <ProfileSettingsScreen
            settings={settings}
            appLanguage={settings.appLanguage}
            onUpdateSettings={(newSet) => setSettings((prev) => ({ ...prev, ...newSet }))}
            onClearCache={() => {
              localStorage.removeItem(STORAGE_PROJECTS_KEY);
              setProjects([INITIAL_PROJECT]);
              setActiveProjectId(INITIAL_PROJECT.id);
              showToast('Cache cleared. Default restored.');
            }}
            onOpenApkModal={() => setIsApkModalOpen(true)}
          />
        )}

        {/* 6. STUDIO TIMELINE & LIVE CANVAS PLAYER */}
        {activeTab === 'studio' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Left Column: Live Canvas Video Player */}
              <div className="lg:col-span-5 flex flex-col items-center">
                <VideoPlayer
                  project={currentProject}
                  currentSceneIndex={currentSceneIndex}
                  onSceneChange={(idx) => setCurrentSceneIndex(idx)}
                  onAspectRatioChange={handleAspectRatioChange}
                />
              </div>

              {/* Right Column: Scene Timeline & Director */}
              <div className="lg:col-span-7">
                <TimelineEditor
                  project={currentProject}
                  activeSceneIndex={currentSceneIndex}
                  onSelectScene={(idx) => setCurrentSceneIndex(idx)}
                  onUpdateScene={handleUpdateScene}
                  onAddScene={handleAddScene}
                  onDeleteScene={handleDeleteScene}
                  onDuplicateScene={handleDuplicateScene}
                  onBatchUpdateScenes={handleBatchUpdateScenes}
                  onAddMultipleScenes={handleAddMultipleScenes}
                />
              </div>
            </div>
          </div>
        )}

        {/* 7. TEXT TO VIDEO AI */}
        {activeTab === 'text2video' && (
          <TextToVideoTab
            project={currentProject}
            onApplyProject={(updated) => {
              updateCurrentProject((prev) => ({ ...prev, ...updated }));
              showToast('AI Video generated and applied to project!');
            }}
            onSwitchToStudio={() => {
              setActiveTab('studio');
              setCurrentSceneIndex(0);
            }}
          />
        )}

        {/* 8. AI AUTO STORY GENERATOR */}
        {activeTab === 'story' && (
          <StoryGeneratorTab
            project={currentProject}
            onApplyStoryToProject={(partialProj) => {
              updateCurrentProject((prev) => ({ ...prev, ...partialProj }));
              setActiveTab('studio');
              setCurrentSceneIndex(0);
              showToast('AI Story converted into scenes and applied!');
            }}
          />
        )}

        {/* 9. CARTOON AI VIDEO */}
        {activeTab === 'cartoon' && (
          <CartoonVideoTab
            project={currentProject}
            onApplyCartoonProject={(partialProj) => {
              updateCurrentProject((prev) => ({ ...prev, ...partialProj }));
              showToast('Cartoon animation created and loaded into Studio!');
            }}
            onSwitchToStudio={() => {
              setActiveTab('studio');
              setCurrentSceneIndex(0);
            }}
          />
        )}

        {/* 10. GAME CINEMATIC VIDEO */}
        {activeTab === 'game' && (
          <GameCinematicTab
            project={currentProject}
            onApplyGameProject={(partialProj) => {
              updateCurrentProject((prev) => ({ ...prev, ...partialProj }));
              showToast('Game Cinematic trailer created and loaded into Studio!');
            }}
            onSwitchToStudio={() => {
              setActiveTab('studio');
              setCurrentSceneIndex(0);
            }}
          />
        )}

        {/* 11. REFERENCE VIDEO / LINK */}
        {activeTab === 'reference' && (
          <ReferenceVideoTab
            project={currentProject}
            onApplyReferenceProject={(partialProj) => {
              updateCurrentProject((prev) => ({ ...prev, ...partialProj }));
              showToast('Original story generated from reference pacing!');
            }}
            onSwitchToStudio={() => {
              setActiveTab('studio');
              setCurrentSceneIndex(0);
            }}
          />
        )}

        {/* 12. CHARACTER CONSISTENCY */}
        {activeTab === 'character' && (
          <CharacterConsistencyTab
            project={currentProject}
            onUpdateCharacterReference={handleUpdateCharacter}
            onApplyToAllScenes={() => {
              showToast('Character consistency locked across all project scenes!');
            }}
          />
        )}

        {/* 13. IMAGE TO VIDEO STUDIO */}
        {activeTab === 'image2video' && (
          <ImageToVideoTab
            project={currentProject}
            onAddGeneratedClipToProject={(clip) => {
              updateCurrentProject((prev) => ({
                ...prev,
                scenes: [...prev.scenes, clip],
              }));
              setActiveTab('studio');
              setCurrentSceneIndex(currentProject.scenes.length);
              showToast('Animated clip added to Studio timeline!');
            }}
          />
        )}

        {/* 14. AUDIO, VOICE & SUBTITLES SUITE */}
        {activeTab === 'audio' && (
          <AudioMusicTab
            project={currentProject}
            onUpdateAudioSettings={handleUpdateAudio}
          />
        )}

        {/* 15. EXPORT VIEW */}
        {activeTab === 'export' && (
          <div className="max-w-2xl mx-auto space-y-4">
            <div className="bg-[#0E121C] border border-gray-800 rounded-3xl p-6 text-center space-y-3 shadow-xl">
              <div className="w-14 h-14 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto">
                <Film className="w-7 h-7" />
              </div>
              <h3 className="text-lg font-bold text-white">Export Video</h3>
              <p className="text-xs text-gray-400 max-w-md mx-auto">
                Export 9:16 Shorts, 16:9 YouTube, or 1:1 Social video in 720p, 1080p, 2K, 4K, or 8K master with synced subtitles, voices & background music.
              </p>
              <button
                onClick={() => setIsExportModalOpen(true)}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-black font-extrabold text-sm shadow-md transition active:scale-95 inline-flex items-center gap-2"
              >
                Open Export Dialog
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Production 5-Tab Bottom Navigation Bar */}
      <BottomNav
        activeTab={activeTab}
        appLanguage={settings.appLanguage}
        onTabChange={(tab) => {
          if (tab === 'export') {
            setIsExportModalOpen(true);
          } else {
            setActiveTab(tab);
          }
        }}
        onOpenAutoCreator={() => setActiveTab('create')}
      />

      {/* Flagship AI Auto Creator Modal */}
      <AutoCreatorModal
        isOpen={isAutoCreatorOpen}
        onClose={() => setIsAutoCreatorOpen(false)}
        onProjectCreated={(newProj) => {
          handleCompleteFromCreate(newProj);
        }}
      />

      {/* AI Tools Suite Modal (Talking Photo, Voice Clone, BG Remover, Video Enhancer, Thumbnail, SEO) */}
      {activeAITool && (
        <AIToolsModal
          toolId={activeAITool}
          project={currentProject}
          appLanguage={settings.appLanguage}
          onClose={() => setActiveAITool(null)}
          onApplyToProject={(partial) => updateCurrentProject((prev) => ({ ...prev, ...partial }))}
        />
      )}

      {/* Android APK Packaging Modal */}
      <ApkPackagingModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />

      {/* Master Video Export Modal */}
      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        project={currentProject}
      />

      {/* In-app Toast Banner */}
      {toastMessage && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-[#161D2E] border border-amber-500/50 text-amber-300 px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 text-xs font-bold animate-in fade-in slide-in-from-top duration-200">
          <span>🐅</span>
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
